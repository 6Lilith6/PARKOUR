-- (see README for usage info)
--$lint: python, shrinko, string, rommemcpy

#include parens8_src/serializers/generic.lua
#include parens8_src/compilers/vmgen.lua
#include parens8_src/compilers/core.lua
#include parens8_src/compilers/platform/crescent_p8.lua
#include parens8_src/compilers/crescent.lua
#include parens8_src/util/lzw.lua

local pico_process = python.import("pico_process")
local pico_output = python.import("pico_output")
local module = {}
local ROM_ENDADDR = 0x4300

Parens8Compiler = python.class(pico_process.CompilerBase)

-- TODO: consider moving all the ROM-related logic to shrinko itself? it's likely common across all compilers...

function split_args(args_str)
    local args = {}
    for arg in all(split(args_str, ' ', false)) do
        arg = split(arg, '=')
        args[arg[1]] = arg[2] or true
    end
    return args
end

function copy(tbl)
    local copy = {}
    for k,v in pairs(tbl) do copy[k] = v end
    return copy
end
function tohex(v)
    return sub(tostr(v, 1), 1, 6)
end
function isbigstr(v)
    local len = select(3, bigstring(v));
    return mid(len, 0x.7fff) != len
end

function get_parens8_data(ctxt)
    return ctxt.get_field("parens8_data", function()
        return {num_compilers=0, results={}, rom_ranges={}}
    end)
end

function fixup_rom_range(ranges, addr, endaddr)
    for range in all(ranges) do -- sorted!
        local raddr, rendaddr = unpack(range)
        if (addr >= raddr and addr < rendaddr) addr = rendaddr
        if (endaddr > raddr and endaddr <= rendaddr) endaddr = raddr
    end
    return addr, endaddr
end

function add_rom_range(ranges, addr, endaddr)
    for i, range in ipairs(ranges) do
        if addr < range[1] then
            add(ranges, {addr, endaddr}, i)
            return ranges
        end
    end
    add(ranges, {addr, endaddr})
end

function reset(opts)
    -- called once done with cart (e.g. important in the webapp and in test runs)
    opidx, opcodes, vm_ops = unpack(get_parens8_data(opts.ctxt).reset_data)
    -- we don't copy here - they'll be copied in their initial state again next compilation
end

function rename(ctxt, name)
    if ctxt.global_renames then
        name = python.attrs(ctxt.global_renames).get(name, name)
    end
    return name
end

function Parens8Compiler:__init(opts)
    self.raw_args = opts.args
    self.cl_args = split_args(self.raw_args)
    self.ctxt = opts.ctxt
    self.src = opts.src
    self.id = tostr(self, 1) -- used to identify this compiler instance inside strings

    get_parens8_data(self.ctxt).num_compilers += 1
end

function Parens8Compiler:get_dynamic_includes()
    local data = get_parens8_data(self.ctxt)

    local includes = {}
    if not data.has_interpreter then
        add(includes, "parens8.interpreter " .. self.raw_args)
        -- (guaranteed to set parens8.interpreter before next compilation)
    end

    if self.cl_args.dest then
        data.disable_cleanup = true
        add(includes, "parens8.assign " .. self.cl_args.dest .. " " .. self.id)
    else
        add(includes, "parens8.run " .. self.id)
    end
    
    return python.list(includes)
end

function Parens8Compiler:compile(root, opts)
    local code = pico_output.output_node(root, self.ctxt, --[[minify=]]false)
    local data = get_parens8_data(self.ctxt)

    -- save initial data to allow resetting it later
    if not data.needs_reset then
        data.reset_data = {opidx, copy(opcodes), copy(vm_ops)}
        python.attrs(self.ctxt.at_finish).append(reset)
        data.needs_reset = true
    end
    
    -- extract our options
    local parens_args = copy(self.cl_args)
    
    local rom_addr = self.cl_args.rom; parens_args.rom = nil
    if (rom_addr and type(rom_addr) != "number") rom_addr = 0

    local rom_endaddr = self.cl_args.rom_end; parens_args.rom_end = nil
    if (type(rom_endaddr) != "number" or rom_endaddr > ROM_ENDADDR) rom_endaddr = ROM_ENDADDR

    local compress = self.cl_args.compress; parens_args.compress = nil
    if (compress and type(compress) != "string") compress = "lzw"
    
    parens_args.dest = nil; parens_args.bigstring = nil; parens_args.deserialize = nil

    -- modify non-string options
    data.num_compilers -= 1 -- to go...
    if not parens_args.vm_cleanup and data.num_compilers == 0 and not data.disable_cleanup then
        parens_args.vm_cleanup = "full"
    end
    parens_args.vm_cleanup = parens_args.vm_cleanup == "full" and vm_cleanup_full -- else empty
    
    if self.ctxt.global_renames and parens_args.vm_cleanup then -- need to rename cleanups in tandem...
        parens_args.vm_cleanup = copy(parens_args.vm_cleanup)
        for i, cleanup in pairs(parens_args.vm_cleanup) do
            parens_args.vm_cleanup[i] = rename(self.ctxt, cleanup)
        end
    end

    local byte_code = compile_crescent(parens_args, code)
    
    local compressed_dict
    if compress then
        -- (triggers if has multiple compiler instances and the first [which is used to build the interpreter] didn't request compression)
        if (not data.has_decompressor) stop("you must explicitly add '--$dynamic-include: parens8.interpreter compress' before the compiler switchings")

        -- TODO: removeme once parens8 fixes lzw_compress to supports bigstring
        if (isbigstr(byte_code)) stop("large inputs currently cannot be compressed via parens8 - try splitting into multiple compilation blocks")

        local compressed_code = ""
	    compressed_dict = lzw_compress(byte_code, bit_writer(function(byte) compressed_code..=chr(byte) end))
        byte_code = compressed_code
    end
    
    if self.cl_args.deserialize and not data.deserialize_kind then
        stop("the `deserialize` option should be supplied on the first `--$switch-compiler:`, or on the `--$dynamic-include:` if it exists")
    end
    if self.cl_args.bigstring != data.is_bigstring then
        stop("all parens8 comments ('--$switch-compiler:' and '--$dynamic-include:') should either have 'bigstring' as an option or not have it as an option")
    end
    if isbigstr(byte_code) and not data.is_bigstring then
        stop("input too large - add 'bigstring' to *all* parens8 comments to support large inputs (e.g. '--$switch-compiler: parens8 bigstring')")
    end

    byte_code = shrinko.to_memory(byte_code)
    assert(#byte_code != 0, "empty parens8 bytecode")

    local results = data.results
    results[self.id] = ""

    if rom_addr then
        rom_addr, rom_endaddr = fixup_rom_range(data.rom_ranges, rom_addr, rom_endaddr)
        if rom_addr != rom_endaddr then
            local max_len = python.builtins.min(rom_endaddr - rom_addr, #byte_code) -- #byte_code may be a python int
            rommemcpy(self.src.cart.rom, rom_addr, byte_code, 0, max_len)
            results[self.id] ..= format("chr(peek(`1`, `2`))", {rom_addr, max_len})
            byte_code = byte_code.get_block(max_len, #byte_code - max_len)
            add_rom_range(data.rom_ranges, rom_addr, rom_addr + max_len)

            -- TODO: move this to a separate count report?
            printh(format("parens8 - used `1` out of `2` rom bytes",
                          {max_len, rom_endaddr - rom_addr}))

            if (#byte_code != 0) results[self.id] ..= ".."
        end
    end

    if #byte_code != 0 then
        results[self.id] ..= pico_output.format_string_literal(shrinko.from_memory(byte_code))
    end

    if compress then
        local compressed_dict_lit = pico_output.format_string_literal(compressed_dict)
        results[self.id] = format("`1`(`2`, `3`)", {rename(self.ctxt, "_ps8_decompress"), results[self.id], compressed_dict_lit})
    end
end

function checked_gsub(tmpl, find, replace)
    local result = string.gsub(tmpl, find, replace)
    if (result == tmpl) stop("template changed - gsub no longer has effect")
    return result
end

function get_parens8_interpreter(opts)
    local data = get_parens8_data(opts.ctxt)
    if data.has_interpreter then
        printh("error - interpreter already written out, can't write it again") -- or could we?
    else
        data.has_interpreter = true

        printh("This cart is licensed via AGPLv3 and its source code & the license must be made available when distributing it")
        
        local decompressor = ""
        local cl_args = split_args(opts.args)
        if cl_args.compress then
            decompressor = checked_gsub(lzw_decompressor_native, '^function', 'function _ps8_decompress') -- _ for lint
            data.has_decompressor = true
        end
        if cl_args.bigstring then
            data.is_bigstring = true
        end
        if cl_args.deserialize then
            data.deserialize_kind = cl_args.deserialize
        end

        local const_name = 'ps8_const'
        local deserializer_name = 'ps8_decode'

        local hints = "--[[$lint: ps8_inst, ps8_val, ps8_binder]]"

        local template = checked_gsub(vm_template, '"`compiled_args`"', '--[[$placeholder-expr::parens8.interp_args]] ""')
        template = checked_gsub(template, '"`argcounts`"', '--[[$placeholder-expr::parens8.interp_argcounts]] ""')
        template = checked_gsub(template, 'return `runtime_ops`', '--[[$placeholder-stmt::parens8.interp_ops]] do end')
        -- 'preserve' locals used by vm ops. ideally we'd use ctxt.local_renames to rename them, but that's not trivial and not worth it
        template = checked_gsub(template, 'ps8_runtime%(a, b, c%)', 'ps8_runtime(--[[$rename::a]]a, --[[$rename::b]]b, --[[$rename::c]]c)')
        -- ignore the _ENV in the template for the purpose of safety checking, allowing to still rename globals
        template = checked_gsub(template, '%f[%w_]_ENV%f[^%w_]', '--[[$force-safe]]_ENV')
        template = checked_gsub(template, '`deserializer`', deserializer_name)
        template = checked_gsub(template, '`const`', const_name)
        
        local deserializer = data.deserialize_kind == "full" and deserializer_full or 
                             data.is_bigstring and deserializer_flat_bs or deserializer_flat
        deserializer = checked_gsub(deserializer, '`funcname`', deserializer_name)
        
        local boilerplate = checked_gsub(fp_boilerplate, '`funcname`', const_name)
        return hints .. boilerplate .. decompressor .. deserializer .. template
    end
end

function get_parens8_interp_ops(opts)
    local opfuncs = {}
    for opcode, vm_op in ipairs(vm_ops) do
		opfuncs[opcode] = vm_op[2]
	end
	return "return " .. join(opfuncs, ",\n")
end

function get_parens8_interp_args(opts)
    local compiled_args = {}
    for opcode, vm_op in ipairs(vm_ops) do
		compiled_args[opcode] = vm_op[1]
	end
	return '"' .. join(compiled_args, ",") .. '"'
end

function get_parens8_interp_argcounts(opts)
    local compiled_args = {}
    for opcode, vm_op in ipairs(vm_ops) do
		compiled_args[opcode] = vm_op[4]
	end
	return '"' .. join(compiled_args, ",") .. '"'
end

function get_parens8_run_code(opts)
    local result_id = opts.args
    return format('run_ps8(--[[$placeholder-expr::parens8.result `1`]] "")', {result_id})
end

function get_parens8_assign_code(opts)
    local sep = string.find(opts.args, " ")
    local dest = rename(opts.ctxt, sub(opts.args, 1, sep - 1))
    local result_id = sub(opts.args, sep + 1)
    return format('`1` = --[[$placeholder-expr::parens8.result `2`]] ""', {dest, result_id})
end

function get_parens8_result(opts)
    return get_parens8_data(opts.ctxt).results[opts.args]
end

function module.include_main(name)
    if (name == "parens8.interpreter") return get_parens8_interpreter
    if (name == "parens8.interp_ops") return get_parens8_interp_ops
    if (name == "parens8.interp_args") return get_parens8_interp_args
    if (name == "parens8.interp_argcounts") return get_parens8_interp_argcounts
    if (name == "parens8.run") return get_parens8_run_code
    if (name == "parens8.assign") return get_parens8_assign_code
    if (name == "parens8.result") return get_parens8_result
end

function module.compiler_main(name)
    if (name == "parens8") return Parens8Compiler
end

return module
