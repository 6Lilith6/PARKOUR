import * as Comlink from "https://cdn.jsdelivr.net/npm/comlink@4.4.2/dist/esm/comlink.min.js";
import {loadPyodide} from "https://cdn.jsdelivr.net/pyodide/v314.0.3/full/pyodide.mjs";
import * as AnsiToHtml from 'https://cdn.jsdelivr.net/npm/ansi-to-html@0.7.2/+esm';
import * as AnsiToText from 'https://cdn.jsdelivr.net/npm/strip-ansi@7.2.0/+esm';
import {getLowExt, getParentDir, joinPath, isFormatText} from "./utils.js";

let targetLang = new URLSearchParams(location.search).get("target");
let isPico8 = targetLang === "pico8";
let isPicotron = targetLang === "picotron";
let srcExt = isPico8 ? "p8" : isPicotron ? "p64" : null;

let inputFile = "__input." + srcExt;
let inputSrcDir = "__input.dir";
let extraInputFileTmpl = "__extrainput#." + srcExt;
let outputFile = "__output.unk";
let outputDir = "__output.dir";
let previewFile = "__preview." + srcExt;
let pythonScriptFile = "__script.py";
let picoScriptFile = "__script.lua";
let picoDat = "__" + targetLang + ".dat";
let extractDir = "__extract";
let tempZip = "__save.zip";

let outputCapture = undefined;
let outputColumns = undefined;
let outputHtml = false;
let initProgress = 0;
let hasPicoDat = false;
let hasPythonScript = false;
let hasPicoScript = false;

function run_main(main, args, fail) {
    try {
        outputCapture = "";
        let exitCode = main(args);
        if (fail) {
            if (exitCode) {
                throw new Error();
            }
            return outputCapture;
        } else {
            return [exitCode ? exitCode : 0, outputCapture];
        }
    } catch (e) {
        console.error(e);
        let isExit = e instanceof pyodide.ffi.PythonError && e.type == "SystemExit";
        if (!e.message || isExit) {
            if (isExit && fail === false) {
                return [-1, outputCapture];
            }
            e.message = outputCapture; // rest doesn't matter
        } else {
            e.message += "\n" + outputCapture;
        }
        throw e;
    } finally {
        outputCapture = undefined
    }
}

function shrinko(args, fail) {
    return run_main(self.shrinko_main, args, fail)
}

class TtyOutput {
    constructor(logger) {
        this.logger = logger;
        this.decoder = new TextDecoder();
        this.htmlConverter = new AnsiToHtml.default({stream: true, escapeXML: true});
        this.textConverter = AnsiToText.default;
        this.rawBuffer = "";
        this.isatty = true;
    }

    getTerminalSize() {
        return { columns: outputColumns ?? 80, rows: 25 };
    }

    write(buffer) {
        try {
            this.rawBuffer += this.decoder.decode(buffer, {stream: true});

            let ln;
            while ((ln = this.rawBuffer.indexOf('\n')) >= 0) {
                let line = this.rawBuffer.slice(0, ln + 1);
                this.rawBuffer = this.rawBuffer.slice(ln + 1);

                let cleanLine = this.textConverter(line);
                this.logger(cleanLine);

                if (outputCapture != undefined) {
                    if (outputHtml) {
                        outputCapture += this.htmlConverter.toHtml(line);
                    } else {
                        outputCapture += cleanLine;
                    }
                }
            }

            return buffer.length;
        } catch (e) {
            console.error("error in tty output:");
            console.error(e);
            return 0;
        } 
    }
}

async function initShrinko() {
    try {
        initProgress = 50;
        self.pyodide = await loadPyodide();
        console.log(pyodide.FS.readdir("."));

        pyodide.setStdout(new TtyOutput(console.info));
        pyodide.setStderr(new TtyOutput(console.warn));

        self.fs = pyodide.FS
        fs.writeFile(inputFile, "");

        initProgress = 60;
        await pyodide.loadPackage("pillow");
        initProgress = 70;
        await pyodide.loadPackage("micropip");
        initProgress = 80;
        const micropip = pyodide.pyimport("micropip");
        await micropip.install('lupaz8');
        initProgress = 90;

        let response = await fetch("shrinko.zip");
        await pyodide.unpackArchive(await response.arrayBuffer(), "zip", {extractDir});

        initProgress = 99;
        self.shrinko_main =
            isPico8 ? pyodide.pyimport(extractDir + ".shrinko8").main :
            isPicotron ? pyodide.pyimport(extractDir + ".shrinkotron").main :
            null;
        initProgress = 100;
    } catch (e) {
        console.error(e);
        initProgress = -1;
    }
}

let initPromise = initShrinko();

let shlex_module;
function shlex(str) {
    if (!shlex_module) {
        shlex_module = pyodide.pyimport("shlex");
    }

    return shlex_module.split(str).toJs()
}

let shutil_module;
function makeArchive(outputFile, ...args) {
    if (!shutil_module) {
        shutil_module = pyodide.pyimport("shutil");
    }

    let zipName = shutil_module.make_archive(outputFile, ...args)
    if (outputFile !== zipName) {
        shutil_module.move(zipName, outputFile)
    }
}

let zipfile_module;
function makeArchiveFrom(outputFile, files) {
    if (!zipfile_module) {
        zipfile_module = pyodide.pyimport("zipfile");
    }

    let zip = zipfile_module.ZipFile(outputFile, "w");
    for (let file of files) {
        zip.write(file);
    }
    zip.close();
}

function rmdirRec(path) {
    for (let file of fs.readdir(path)) {
        if (file == "." || file == "..") {
            continue;
        }

        let child = joinPath(path, file);
        if (fs.isDir(fs.stat(child).mode)) {
            rmdirRec(child);
            fs.rmdir(child);
        } else {
            fs.unlink(child);
        }
    }
}

function mkdirParentRec(path) {
    let result = fs.analyzePath(path);
    if (!result.exists && !result.parentExists) {
        let parentPath = getParentDir(path);
        if (parentPath) {
            mkdirParentRec(parentPath);
            fs.mkdir(parentPath);
        }
    }
}

function rmdirRecIfNeeded(dir) {
    if (fs.analyzePath(dir).exists) {
        rmdirRec(dir);
    }
}

function copyInputs(files, main) {
    rmdirRecIfNeeded(inputSrcDir);
    for (let [relpath, data] of files) {
        let path = joinPath(inputSrcDir, relpath);
        mkdirParentRec(path);
        fs.writeFile(path, new Uint8Array(data));
    }

    return joinPath(inputSrcDir, main); // main can be empty to just get dir
}

let api = {
    loadInputFiles: async (files, main, subfile, extras) => {
        await initPromise;

        let mainExt = getLowExt(main);
        if (isFormatText(mainExt) && files.size == 1 && subfile == null && !extras) {
            // simple case - no conversion/preprocessing is needed or wanted.
            let data = files.values().next().value;
            fs.writeFile(inputFile, new Uint8Array(data));
            return fs.readFile(inputFile, {encoding: "utf8"});
        } else {
            // copy entire files list and convert/preprocess to p8
            let mainPath = copyInputs(files, main);
            let args = [mainPath, inputFile];
            if (subfile != null) {
                args.push("--cart", subfile)
            }
            shrinko(args, true);
            let result = fs.readFile(inputFile, {encoding: "utf8"});
            
            // also convert/preprocess extra files
            let extraI = 0;
            if (extras) {
                for (let extra of extras) {
                    let extraInputFile = extraInputFileTmpl.replace("#", extraI++);
                    shrinko([joinPath(inputSrcDir, extra), extraInputFile], true);
                }
            }

            return result;
        }
    },
    listInputFile: async (files, main) => {
        await initPromise;
        let mainPath = copyInputs(files, main);
        let output = shrinko([mainPath, "--list"], true);
        return output.split("\n").filter(l => l);
    },

    updateInputFile: async (text) => {
        await initPromise; // includes fs init
        fs.writeFile(inputFile, text);
    },
    updatePythonScriptFile: async (text) => {
        await initPromise; // includes fs init
        fs.writeFile(pythonScriptFile, text);
        hasPythonScript = Boolean(text);
    },
    updatePicoScriptFile: async (text) => {
        await initPromise; // includes fs init
        fs.writeFile(picoScriptFile, text);
        hasPicoScript = Boolean(text);
    },
    updatePicoDat: async (data) => {
        await initPromise; // includes fs init
        fs.writeFile(picoDat, new Uint8Array(data));
        hasPicoDat = true;
    },
    uploadExtraFile: async (path, data) => {
        await initPromise; // includes fs init
        fs.writeFile(path, new Uint8Array(data));
    },
    listExtraFiles: async (path) => {
        await initPromise; // includes fs init
        return fs.readdir(path).filter(f => !f.startsWith(".") && !f.startsWith("__"));
    },
    downloadExtraFiles: async (paths) => {
        await initPromise; // includes fs init
        if (paths.length == 1) {
            return fs.readFile(paths[0]);
        } else {
            makeArchiveFrom(tempZip, paths);
            return fs.readFile(tempZip);
        }
    },
    
    getProgress: () => initProgress,
    getVersion: async () => {
        await initPromise;
        return shrinko(["--version"], true);
    },
    getHelp: async (columns) => {
        await initPromise;
        try {
            outputHtml = true;
            outputColumns = columns;
            let [_, stdout] = shrinko(["--help"], false);
            return stdout;
        } finally {
            outputColumns = undefined;
            outputHtml = false;
        }
    },

    runShrinko: async (args, argStr, encoding, usePreview, doZip, extraNames) => {
        await initPromise;

        let cmdline = [inputFile];
        if (encoding) {
            if (doZip) {
                rmdirRecIfNeeded(outputDir);
                cmdline.push(outputDir);
            } else {
                cmdline.push(outputFile);
            }
        }
        cmdline.push(...args);
        if (argStr) {
            cmdline.push(...shlex(argStr));
        }
        if (hasPythonScript) {
            cmdline.push("--script", pythonScriptFile);
        }
        if (hasPicoScript) {
            cmdline.push("--script", picoScriptFile);
        }
        if (usePreview) {
            cmdline.push("--extra-output", previewFile);
        }
        if (hasPicoDat) {
            cmdline.push("--" + targetLang + "-dat", picoDat); // won't hurt to always pass - only read if needed
        }
        if (extraNames) {
            for (let i = 0; i < extraNames.length; i++) {
                let extraInputFile = extraInputFileTmpl.replace("#", i);
                cmdline.push("--extra-input", extraInputFile, srcExt, extraNames[i]);
            }
        }
    
        console.log(cmdline);
        let [code, stdout] = shrinko(cmdline);

        let output, preview;
        if (code == 0) {
            if (doZip) {
                makeArchive(outputFile, "zip", outputDir, ".")
            }
            if (encoding) {
                output = fs.readFile(outputFile, {encoding});
            }
            if (usePreview) {
                preview = fs.readFile(previewFile, {encoding: "utf8"});
            }
        }

        return [code, stdout, output, preview];
    },

    runTests: async (argsStr, save) => {
        await initPromise;
        
        if (!self.shrinko_run_tests) {
            let response = await fetch("shrinko_test.zip");
            await pyodide.unpackArchive(await response.arrayBuffer(), "zip", {extractDir});

            let run_tests = pyodide.pyimport(extractDir + ".run_tests")
            self.shrinko_run_tests = run_tests.main
        }
        
        let oldCwd = fs.cwd();
        fs.chdir(extractDir);

        let args = [];
        if (argsStr) {
            args.push(...shlex(argsStr))
        }
        if (fs.analyzePath("private_pico8").exists) {
            // it'll pick up the pico8.dat based on this fictive path
            args.push("-p", "private_pico8/pico8.exe", "-P");
        }

        let [exitcode, output] = run_main(self.shrinko_run_tests, args);

        let saveData = undefined
        if (save) {
            if (fs.analyzePath("private_test_output").exists) {
                fs.rename("private_test_output", "test_output/private")
            }

            makeArchive(tempZip, "zip", "test_output", ".");
            saveData = fs.readFile(tempZip);
        }

        fs.chdir(oldCwd);

        return [exitcode, output, saveData]
    },
}

Comlink.expose(api);
