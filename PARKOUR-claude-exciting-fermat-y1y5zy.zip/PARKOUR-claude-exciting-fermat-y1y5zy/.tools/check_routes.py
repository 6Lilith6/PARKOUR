import sys, importlib, os
sys.path.insert(0, 'tools')
import playtest, build
playtest.CART=build.build(os.path.abspath('.tools/routes.p8'))[0]
for n in (2,3,5,6,7,8):
    m=importlib.import_module('tests.l'+str(n))
    playtest.SCENARIOS.update({'L%d:%s'%(n,k):v for k,v in m.SCENARIOS.items()})
overrides={
'L2:pallet_f1':[(30,'up+z'),(10,'up')]*6,
'L3:catwalk_to_containers':[(1,'flow=.6'),(800,'up+ej+pj')],
'L3:pump_service_pier':[(400,'up+ej+pj')],
'L3:long_jump':[(1,'flow=1'),(1,'spd=8.5'),(450,'up+ax+ej+pj')],
'L3:silo_goal':[(30,'up+z'),(10,'up')]*12,
'L5:billboard_cable':[(1,'flow=.5'),(300,'up+ax+ej+pj')],
'L6:rail_deck':[(1,'flow=.6'),(500,'up+ax+ej+rl')],
'L7:outcrops':[(30,'up+z'),(10,'up')]*16,
'L7:gorge_beams':[(700,'up+bal+pj')],
}
for k,steps in overrides.items():
    start,_,check=playtest.SCENARIOS[k]
    playtest.SCENARIOS[k]=(start,steps,check)
    playtest.run(k,verbose=True)
