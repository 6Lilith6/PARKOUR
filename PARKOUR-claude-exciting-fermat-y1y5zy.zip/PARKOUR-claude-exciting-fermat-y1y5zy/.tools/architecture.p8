pico-8 cartridge // http://www.pico-8.com
version 42
__lua__
-- parkour: rooftops
-- third-person 3d parkour
-- main loop, game flow,
-- checkpoints, timer, hud

dt=1/60
lnames=split"old city rooftops,construction site,factory,underground,downtown,neon district,cliff village,megastructure"
hints=split("⬆️ run   ⬅️➡️ steer   🅾️ jump|low barriers: run to vault\nroofs and gaps: press 🅾️|❎ while running: slide|❎ just before landing: roll\nhigh drops without it hurt|jump at a ledge to grab it\n⬆️ climb  ⬅️➡️ shimmy  ❎ drop\n⬇️+🅾️ jump away|ladders and fixed drainpipes\nhold ⬆️ to climb|hold 🅾️ into a wall: run up it\nhold 🅾️ along a wall: wallrun|on a wall press 🅾️: kick off\n(tic-tac / wall jump)|narrow beams: ⬅️➡️ keep balance|red awnings bounce you high|keep moving to build flow\nflow = higher top speed|three ways up: ladder,\nsteps, or run up the wall|wallrun, 🅾️ wall jump, wallrun\nor take the cable / skybridge|last climb: stairs, chimney\nor vault-jump-mantle|construction site: climb floor\nby floor to the crane|4m up: ladder, pallets, or\nhold 🅾️ and run up the formwork|❎ slide under the formwork bar\nor go round the lift core|hoist or stored formwork:\npress 🅾️ for precise jumps|loading decks: jump the gap\nor cross the rear scaffold|ladder or stacked formwork:\nchoose the next floor|climb the crane mast and walk\nthe jib to the cab|factory: long straights build\nflow - keep moving, keep speed|the catwalk is the sprint lane:\nladder or crate steps up|container tops: chain the jumps\nwithout stopping|hold 🅾️ along the tank: wallrun\nonto the pipe rack|❎ slide under the pipes,\nvault the valve|pit: pump pier or long jump\nservice bridge below is safer|follow the station exit signs\nplatform, roofs or service walk|tunnel: wallrun, 🅾️ wall jump,\nwallrun - zig-zag the walls|❎ slide under pipes and cables|pump hall: service ladder\nor jump the machinery housings|hop the narrow beams over\nthe shaft|downtown: up from the street\nto the rooftops|taxi, van, awning: bounce\nonto the balcony|roof garden: ❎ slide under\nthe pergola, vault the glass|cross on the cable or take\nthe skybridge|office roof: AC units,\npenthouse, tank - pick a line|garage: weave between the\ncars or hop the roofs|4m walls: ladder, gondola,\nAC units, or run up|neon district: speed - keep\nflow up and never stop|billboard service decks:\njump gaps or take side girder|bounce the bar awning onto\nthe high roof - then fly|the train: wallrun its side\nor run along the roof|leap from the train roof, run\nup the sign, or the ladders|cliff village: careful feet -\nlong falls, slow is fine|bridge, rope, or the roofs:\njump for the far house|up the cliff: fixed ladders\nor deliberate outcrop jumps|the gorge: bridge or beams\nor jump the broad buttresses|terraces: ladders, crate and\ngrabs, or run up the walls|last wall: long ladder, or\nrun up the ledges|megastructure: climb it all,\nevery move counts|8m up: ladders, machinery\nor climb via service balconies|cross the service balconies\nor wallrun along the hoarding|core balconies or pipework\nwallrun is the direct line|vault the guard, then choose:\ncore wallrun, balcony or pipe|the crown: last climb, then\nsprint to the end","|")

function _init()
 cartdata"pk_parkour_2"
 menuitem(1,"restart level",restart)
 menuitem(2,"last checkpoint",respawn)
 menuitem(3,"level select",function() mode="title" end)
 -- debug: fps, cpu, collision
 -- boxes near the runner
 menuitem(4,"perf overlay",function() dbg=not dbg end)
 music(0)
 mode="title"
 setlv(0)
end

function restart()
 cpi,tm,splits,score,cp,started=0,0,{},0,spawn
 worldreset()
 respawn()
end

-- reset player at checkpoint
function respawn()
 px,py,pz,ang=unpack(cp)
 for k in all(split"vx,vy,vz,spd,flow,chain,idle,bal,balv,heavy,ngrab,jbuf,rbuf,coy,kicks,aph,shake,stun,popt,splt,shy,wrs,lc,lvy,oh") do _ENV[k]=0 end
 peak,pop,fade,bang,crouch,gb,wupd,lastwr,gnd=py,"",12,ang
 setst"ground"
 nearupd()
 camreset()
end

function inp()
 local o,x=jz,xx
 jz,xx,iu,id=btn(4),btn(5),btn(2),btn(3)
 jzp,xp=jz and not o,xx and not x
 turn=(btn(0) and 1 or 0)-(btn(1) and 1 or 0)
end

-- 30 fps: one drawn frame runs
-- two fixed 1/60s steps, so the
-- physics never depends on how
-- long drawing takes
function _update()
 inp()
 menu()
 step()
 jzp,xp=nil
 step()
end

function menu()
 if mode~="play" then
  if mode=="title" then
   ang+=.0016
   -- level select: next level
   -- unlocks once this one's done
   if btnp(0) then setlv(lv-1) end
   if btnp(1) and dget(lv*8)>0 then setlv(lv+1) end
  elseif jzp then
   setlv(lv+1)
  end
  if jzp or xp and mode=="done" then mode="play" restart() end
 end
end

function step()
 if mode=="play" then
  if btn()>0 then started=true end
  if started then tm=min(tm+1,32000) end
  fade,splt,popt=max(fade-1),max(splt-dt),max(popt-dt)
  worldupd()
  pupd()
  trigupd()
 end
 camupd()
end

function trigupd()
 hint=nil
 for b in all(trig) do
  if inside(b,px,pz,0) and py>b[2]-1 and py<b[5] then
   if b.m==11 and b.k>cpi then
    cpi,cp,splt=b.k,{(b[1]+b[4])/2,b[2],(b[3]+b[6])/2,ang},2.5
    splits[cpi]=tm
    local o=dget(lv*8+cpi)
    sdel=o>0 and tm-o
    sfx(6)
   elseif b.m==12 then
    -- finish line
    mode,best="done",dget(lv*8)
    newbest=best==0 or tm<best
    if newbest then
     dset(lv*8,tm)
     for i,s in pairs(splits) do dset(lv*8+i,s) end
    end
    sfx(9)
   elseif b.m==13 then
    hint=b.k+1+sk[9]
   end
  end
 end
end

-- m:ss.cc from frames
function ft(f)
 local s=f\60
 return s\60 ..":"..sub("0"..s%60,-2).."."..sub("0"..(f%60*5\3),-2)
end

-- outlined text (centered if no x)
function pr(s,y,c,x)
 x=x or 64-#s*2
 for d=-1,1,2 do print(s,x+d,y,0) print(s,x,y+d,0) end
 print(s,x,y,c)
end

function _draw()
 render()
 if mode=="title" then
  rectfill(0,30,127,74,0)
  pr("\^w\^tparkour",36,7,36)
  pr("⬅️ "..lv+1 ..". "..lnames[lv+1].." ➡️",50,9)
  pr("press 🅾️ to start",64,7)
  rectfill(0,90,127,112,0)
  print("⬅️➡️ steer  ⬆️ run  ⬇️ brake\n🅾️ jump, hold on walls\n❎ slide / roll / drop",6,92,6)
  if dget(lv*8)>0 then pr("best "..ft(dget(lv*8)),116,10) end
  return
 end
 -- timer, best time
 pr(ft(tm),2,7,2)
 if dget(lv*8)>0 then pr(ft(dget(lv*8)),9,5,2) end
 -- checkpoint split vs best
 if splt>0 then
  pr("checkpoint "..cpi..(sdel and "  "..(sdel<=0 and "-" or "+")..ft(abs(sdel)) or ""),20,sdel and sdel>0 and 8 or 11)
 end
 -- speed + flow meter
 rectfill(2,121,2+hs()/9*40,124,flow>.6 and 10 or flow>.3 and 9 or 13)
 rect(1,120,43,125,5)
 -- A fixed move label keeps the landing zone visually quiet.
 if popt>0 then
  pr(pop,112,7)
 end
 if hint then
  rectfill(1,97,126,117,1)
  print(hints[hint],3,99,7)
 end
 if fade>0 then
  fillp(fade>6 and 0 or 0x5a5a)
  rectfill(0,0,127,127,0)
  fillp()
 end
 if mode=="done" then
  rectfill(16,34,111,96,0)
  rect(16,34,111,96,7)
  pr(lnames[lv+1],40,10)
  pr("time  "..ft(tm),52,7)
  pr(newbest and "new best!" or "best  "..ft(best),60,newbest and 11 or 6)
  pr("flow score "..score,72,12)
  pr("🅾️ next level  ❎ retry",86,7)
 end
 if dbg then print(stat(7).." "..stat(1).." "..#nb,1,9,7) end
end
-->8
-- level data, written into cart
-- memory by tools/build.py.
-- 0x0000: 8 x 2-byte level address
-- level block:
--  16 display palette
--  11 sky: top,haze,sil a,sil b,
--     ground,sun,fog col,fog dist,
--     hint base,spawn heading,
--     silhouette height
--  15 materials x 4: top,side x,
--     side z,deco (lo=type hi=col)
--  2 box count, boxes x 10 bytes:
--  x,z,y:2 (/8) w,h,d:1 (/4)
--  mat:1 (lo=material hi=arg)
-- material flags (fixed per id):
-- 1 solid 2 climb 4 bouncy 8 trigger
mflag=split"1,1,1,1,1,3,1,5,1,1,8,8,8,1,1"

-- read an n-byte value
function rd(n)
 ra+=n
 return n>1 and peek2(ra-2) or peek(ra-1)
end

function setlv(l)
 lv=mid(0,l,7)
 ra=peek2(lv*2)
 for i=0,15 do pal(i,rd(1),1) end
 sk,mats,boxes,trig,dl,movers={},{},{},{},{},{}
 for i=1,11 do sk[i]=rd(1) end
 for i=1,15 do mats[i]={rd(1),rd(1),rd(1),mflag[i],rd(1)} end
 for i=1,rd(2) do
  local x,z,y=rd(2)/8,rd(2)/8,rd(2)/8
  local w,h,d,m=rd(1)/4,rd(1)/4,rd(1)/4,rd(1)
  local b={x,y,z,x+w,y+h,z+d,m=m%16,k=m\16,f=mflag[m%16]}
  if b.f&8>0 then
   add(trig,b)
   if b.m==11 and b.k==0 then spawn={x+w/2,y,z+d/2,sk[10]/256} end
  else
   add(boxes,b) add(dl,b)
   if b.k>=12 then b.o=0 add(movers,b) end
  end
 end
 -- player pseudo-box, sorted
 -- with the world for drawing
 plb={}
 add(dl,plb)
 restart()
end

-- Transport has a timetable, with dwell at each end. The same boxes
-- participate in rendering, collision and rider attachment.
function worldreset()
 wt=0
 for b in all(movers) do
  local ax=b.k==13 and 2 or 3
  b[ax]-=b.o b[ax+3]-=b.o b.o=0
 end
end

function worldupd()
 if not started then return end
 wt=(wt+dt)%24
 local phase,moved=mid(0,min(wt-3,21-wt)/6,1),false
 for b in all(movers) do
  local ax=b.k==13 and 2 or b.k==14 and 1 or 3
  local offset=phase*(b.k==12 and 12 or b.k==13 and 4 or 8)
  local d=b.k==14 and dt*1.2 or offset-b.o
  local ride=gnd==b and abs(py-b[5])<.1
  local held=hb==b and (st=="hang" or st=="pull")
  if b.k~=14 then
   b[ax]+=d b[ax+3]+=d b.o=offset
  end
  if ride or held then
   local p={px,py,pz}
   p[ax]+=d
   px,py,pz=unpack(p)
   moved=ride and d~=0 or moved
   if held and st=="pull" then pa[ax]+=d pb[ax]+=d end
  elseif d~=0 and b.k~=14 and phit()==b then
   -- A slow vehicle pushes toward its direction of travel instead of
   -- swallowing the runner. A blocked exit uses the last safe checkpoint.
   if ax==3 then pz=d>0 and b[6]+r+.01 or b[3]-r-.01 end
   moved=d~=0 or moved
  end
 end
 -- Recheck against the current world, including newly arrived vehicles.
 if moved then
  nearupd()
  if phit() then respawn() end
 end
end
-->8
-- collision system
-- player = aabb at feet px,py,pz
-- radius r, height ph

r=.3

-- Shared horizontal footprint: positive margin fits inside the surface;
-- negative margin tests overlap. Used by collision, routes and transport.
function inside(b,x,z,m)
 return x>b[1]+m and x<b[4]-m and z>b[3]+m and z<b[6]-m
end

-- gather boxes near the player
function nearupd()
 nb={}
 for b in all(boxes) do
  if inside(b,px,pz,-8) and b[2]<py+8 and b[5]>py-8 then
   add(nb,b)
  end
 end
end

-- first near solid overlapping
-- the given region
function hit(x0,y0,z0,x1,y1,z1)
 for b in all(nb) do
  if x0<b[4] and x1>b[1] and y0<b[5] and y1>b[2] and z0<b[6] and z1>b[3] then
   return b
  end
 end
end

function phit(y)
 y=y or py
 return hit(px-r,y,pz-r,px+r,y+ph,pz+r)
end

function solid(x,y,z)
 return hit(x-.05,y-.05,z-.05,x+.05,y+.05,z+.05)
end

-- step onto low curbs/stairs
function stepup(b)
 if st~="air" and st~="wallrun" and b[5]-py<.55 and not phit(b[5]+.01) then
  py=b[5]+.01
  return true
 end
end

-- move by velocity, axis by axis.
-- sets wall/gnd contacts
-- push out on the side the
-- centre came from (also right
-- if already overlapping)
function pmove()
 wall,gnd=nil
 local ox,oz=px,pz
 px+=vx*dt
 local b=phit()
 if b and vx~=0 and not stepup(b) then
  wnx,wnz=ox<(b[1]+b[4])/2 and -1 or 1,0
  px,wall=wnx<0 and b[1]-r-.001 or b[4]+r+.001,b
 end
 pz+=vz*dt
 b=phit()
 if b and vz~=0 and not stepup(b) then
  wnx,wnz=0,oz<(b[3]+b[6])/2 and -1 or 1
  pz,wall=wnz<0 and b[3]-r-.001 or b[6]+r+.001,b
 end
 py+=vy*dt
 b=phit()
 if b and vy~=0 then
  if vy<0 then
   py,gnd=b[5],b
   -- prefer wide footing over
   -- beams/ladder tops
   for o in all(nb) do
    if inside(o,px,pz,-r) and o[5]==py and not narrow(o) then gnd=o end
   end
  else
   py=b[2]-ph
  end
  vy=0
 end
end

function hs()
 return sqrt(vx*vx+vz*vz)
end
-->8
-- parkour detection + move
-- starters used by the states

function narrow(b)
 return b and min(b[4]-b[1],b[6]-b[3])<.7
end

-- Only authored low obstacles (arg 4), crossed from real ground.
-- The far side must fit both feet: a landing ledge is never a vault.
function canvault(b)
 if st~="ground" or not gnd or not iu or xx or jbuf>0 or narrow(gnd) or b.k~=4 then return end
 local h,dx,dz=b[5]-py,cos(ang),sin(ang)
 if h<=.55 or h>1.35 or abs(b[2]-py)>.15 or -dx*wnx-dz*wnz<.65 then return end
 local ix=wnx~=0 and 1 or 3
 if b[ix+3]-b[ix]>1.6 or b[7-ix]-b[4-ix]<.9 then return end
 local v=ix==1 and dx or dz
 local d=(b[v>0 and ix+3 or ix]-(ix==1 and px or pz)+(r+.15)*sgn(v))/v
 local x,z=px+dx*d,pz+dz*d
 local floor=solid(x,py-.1,z)
 return floor and abs(floor[5]-py)<.35 and inside(floor,x,z,.35) and not hit(min(px,x)-r,b[5]+.02,min(pz,z)-r,max(px,x)+r,b[5]+1.8,max(pz,z)+r) and not hit(x-r,floor[5]+.02,z-r,x+r,b[5],z+r)
end

-- ledge in front of the hands,
-- top lo..hi above the feet,
-- with room to climb onto it
function findledge(lo,hi)
 local x,z=px+cos(ang)*.6,pz+sin(ang)*.6
 for b in all(nb) do
  local t=b[5]-py
  if t>lo and t<hi and inside(b,x,z,0) and not hit(x-.2,b[5]+.05,z-.2,x+.2,b[5]+1,z+.2) then
   return b
  end
 end
end

-- face box b from the side the
-- player is outside of
function snapface(b,zf,keep)
 if zf==nil then zf=max(b[1]-px,px-b[4])<=max(b[3]-pz,pz-b[6]) end
 if not zf then
  wnx,wnz=px<b[1] and -1 or 1,0
  px=wnx<0 and b[1]-r or b[4]+r
 else
  wnx,wnz=0,pz<b[3] and -1 or 1
  pz=wnz<0 and b[3]-r or b[6]+r
 end
 if not keep then ang,vx,vy,vz=atan2(-wnx,-wnz),0,0,0 end
end

-- move feedback: name, flow, sfx
function trick(n,f,s)
 pop,popt,idle=n,1,0
 chain+=1
 score=min(score+5*min(chain,20),32000)
 flow=mid(0,flow+f,1)
 if s then sfx(s) end
end

-- a mistake: breaks the chain
function brk(n,s)
 pop,popt,chain,idle=n,1,0,0
 flow*=.4
 if s then sfx(s) end
end

function toair(j)
 peak,airjump,gnd=py,j
 setst"air"
end

function dojump()
 local h,jv=spd,6.2
 if spd<2.5 then
  -- standing: precise hop
  h=iu and 3.6 or 0
 else
  jv=6+spd*.2
  -- takeoff right at an edge
  if not solid(px+cos(ang)*.8,py-.3,pz+sin(ang)*.8) then
   h*=1.08 trick("edge jump",.06)
  end
 end
 if narrow(gb) then jv-=.6 end
 if st=="slide" or st=="roll" then jv-=.5 trick(st.." jump",.05) end
 vx,vy,vz,jbuf=cos(ang)*h,jv,sin(ang)*h,0
 toair(true)
 sfx(1)
end

function startvault(b)
 vtop,vy0,vt=b[5],py,spd<3.6 and 1 or spd<6.3 and 2 or 3
 -- tall obstacles can't be
 -- speed vaulted cleanly
 if vtop-py>1.15 then vt=min(vt,2) end
 vdur,vspd=({.38,.2,.12})[vt],({min(spd,2.2),spd*.92,spd*1.04})[vt]
 trick(({"climb over","vault","speed vault"})[vt],vt*.05-.05,7)
 setst"vault"
end

-- Rescue catches need contact with a broad ledge while descending.
-- Small landing surfaces and rising jumps get no automatic lift.
function airgrab()
 if ngrab>0 or xx or not wall or vy>0 then return end
 local b=findledge(.65,2.15)
 if b and abs(b[5]-wall[5])<.1 and min(b[4]-b[1],b[6]-b[3])>1.2 then
  if b[5]-py<1.3 and not airjump then return end
  hb,hcat=b,hs()>3
  snapface(b)
  if b[5]-py<1.3 then
   startpull()
   trick("mantle",.05,4)
   return true
  end
  py=b[5]-(hcat and 1.5 or 2.05)
  setst"hang"
  trick(hcat and "cat leap" or "ledge grab",hcat and .1 or 0,4)
  return true
 end
end

function startpull()
 pa,pb={px,py,pz},{px+cos(ang)*.7,hb[5]+.01,pz+sin(ang)*.7}
 pdur=hcat and .3 or .5
 setst"pull"
end

-- kick off a wall (tic-tac / wall
-- jump): keep along-wall speed vp
function wallkick(vp,out,n)
 vx,vy,vz,jbuf=-wnz*vp+wnx*out,max(vy,6.6-kicks*1.3),wnx*vp+wnz*out,0
 kicks+=1
 ang=atan2(vx,vz)
 toair(true)
 trick(n,.1,4)
end

-- jump away from a ledge/ladder
function jumpback()
 ang+=.5
 vx,vy,vz,ngrab=cos(ang)*4.5,6.5,sin(ang)*4.5,.25
 toair(true)
 trick("wall jump",.05,4)
end

function bonk()
 vx,vz,spd,shake=0,0,0,.15
 brk("ouch",11)
end
-->8
-- player physics + state machine
-- one update function per state

g=20
s={}

function setst(n)
 st,stt,ph=n,0,1.8
end

function pupd()
 nearupd()
 stt+=dt
 jbuf,rbuf,ngrab=max(jbuf-dt),max(rbuf-dt),max(ngrab-dt)
 if jzp then jbuf=.12 end
 if xp then rbuf=.3 end
 s[st]()
 -- fell into the street
 if py<1 then
  sfx(11) respawn()
 end
 -- shadow height
 shy=-1
 for b in all(nb) do
  if inside(b,px,pz,0) and b[5]<=py+.05 then shy=max(shy,b[5]) end
 end
 anim()
end

-- ground velocity from heading
function gvel()
 vx,vy,vz=cos(ang)*spd,-3,sin(ang)*spd
 pmove()
end

-- idle/walk/run/sprint/crouch
-- and balancing on beams
s.ground=function()
 local nar,vmax=narrow(gb),6.2+flow*2.8
 if nar then
  vmax=4
  if balance() then return end
 else
  ang+=turn*(.6-min(spd,9)*.04)*dt
 end
 if heavy>0 then heavy-=dt vmax=2.5 end
 -- crouch: x held slow, or
 -- no headroom
 ph=1.8
 crouch=xx and spd<3.5 or phit()
 if crouch then ph,vmax=1,1.6 end
 if iu then
  spd+=(spd<5 and 9 or 2.2)*dt
 else
  spd-=(id and 16 or spd>3 and 4 or 9)*dt
 end
 spd=max(min(spd,max(vmax,spd-6*dt)))
 -- momentum: flow builds while
 -- fast, drains when slow
 if spd>5.8 then flow=min(flow+.04*dt,1) end
 if spd<3 then flow=max(flow-.5*dt) end
 if spd<1.5 then
  idle+=dt
  if idle>1.2 then chain=0 end
 end
 if jbuf>0 and not crouch then dojump() return end
 if xp and spd>=3.5 and not nar then
  spd*=1.05
  trick("slide",0,3)
  setst"slide"
  return
 end
 gvel()
 if not gnd then
  coy,vy=.1,0
  toair()
  return
 end
 gb=gnd
 local f=flr(aph*2)
 if f~=lstep and spd>.5 then sfx(0) end
 lstep=f
 if wall then
  local into=-cos(ang)*wnx-sin(ang)*wnz
  if wall.f&2>0 and iu and into>.5 then
   startclimb()
  elseif spd>1 and canvault(wall) then
   startvault(wall)
  elseif into>.6 and jz and spd>3 then
   wallup(spd*into)
  elseif into>.7 then
   if spd>5.5 then
    bonk()
    stun=.3
    setst"land"
   end
   spd=0
  elseif into>0 then
   -- glancing: slide along it
   local tx,tz=-wnz,wnx
   if cos(ang)*tx+sin(ang)*tz<0 then tx,tz=-tx,-tz end
   ang=atan2(tx,tz)
   spd*=1-into*.5
  end
 end
end

-- beam wobble grows with speed,
-- ⬅️➡️ counters it
function balance()
 ang+=angd((gb[4]-gb[1]>gb[6]-gb[3] and (cos(ang)>0 and 0 or .5) or (sin(ang)>0 and .75 or .25))-ang)*.15
 balv=balv*.97+((rnd(2)-1)*(1+spd*.8)+bal*2.5-turn*5)*dt
 bal+=balv*dt
 -- drift sideways with the lean
 local lx,lz=-sin(ang)*bal,cos(ang)*bal
 px+=lx*.4*dt
 pz+=lz*.4*dt
 if abs(bal)>1 then
  vx,vy,vz=lx*2,1,lz*2
  bal,balv=0,0
  brk("slipped",11)
  toair()
  return true
 end
end

s.air=function()
 coy-=dt
 if jbuf>0 and coy>0 then dojump() return end
 vy=max(vy-g*dt,-30)
 -- limited air steering
 local da=turn*.2*dt
 local c,sn=cos(da),sin(da)
 ang+=da
 vx,vz=vx*c-vz*sn,vx*sn+vz*c
 if iu and hs()<3.6 then
  vx+=cos(ang)*5*dt vz+=sin(ang)*5*dt
 end
 if id then vx*=.97 vz*=.97 end
 pmove()
 peak=max(peak,py)
 if gnd then land() return end
 if airgrab() then return end
 -- holding z near a wall pulls
 -- you onto it (wallrun magnet)
 if not wall and jz and hs()>3.2 then
  -- nearest probe first: a thin
  -- wall hides what is behind it
  for sd in all(split"0,.4,-.4,.8,-.8") do
   local b=solid(px-sin(ang)*sd,py+1,pz+cos(ang)*sd)
   if b and not wall and b~=lastwr and max(b[4]-b[1],b[6]-b[3])>2 then
    wall=b
    snapface(b,px>b[1] and px<b[4],1)
   end
  end
 end
 if not wall then return end
 local vin,vp=max(-vx*wnx-vz*wnz),vz*wnx-vx*wnz
 if wall.f&2>0 and iu and vin>.5 then
  -- catch a ladder/pipe mid-air
  startclimb()
 elseif jbuf>0 then
  -- tic-tac: kick off, keep
  -- the along-wall speed
  wallkick(vp,max(3.2,vin*.5),"tic-tac")
 elseif jz and abs(vp)>3.2 and abs(vp)>vin*.7 and wall~=lastwr then
  -- wallrun
  wrs,lastwr=max(abs(vp),hs()*.85),wall
  wrt=.5+wrs*.12
  wrmax=wrt
  vy=mid(vy,1+wrs*.25,3.5)
  ang=atan2(-wnz*vp,wnx*vp)
  trick("wallrun",.1,5)
  setst"wallrun"
 elseif jz and vin>2 and not wupd then
  wallup(vin)
 else
  if vin>6.5 then bonk() end
  vx+=wnx*vin vz+=wnz*vin
 end
end

function land()
 local h,hv=peak-py,hs()
 if hv>.5 then ang=atan2(vx,vz) end
 spd,gb,coy,wupd,kicks,lastwr=hv,gnd,0,false,0
 -- awning: bounce up
 if gb.f&4>0 then
  toair(true)
  vy=jz and 12.5 or 11
  trick("bounce",.1,10)
  return
 end
 sfx(2)
 if narrow(gb) then
  spd,bal,balv=min(spd,2.5),0,0
  if h>.6 then trick("precision",.08) end
  setst"ground"
  return
 end
 if h>1.6 and rbuf>0 then
  if h<11 then
   spd=max(spd*.95,4)
   trick("roll",.12,3)
   setst"roll"
   return
  end
  -- too high even for a roll
  h-=4
 end
 if h>4.6 then
  spd*=.15
  stun,shake,heavy,flow=.6,.3,.6,0
  brk("hard landing",8)
  setst"land"
 elseif h>2.6 then
  spd*=.6
  stun,flow=.15,max(flow-.25)
  setst"land"
 else
  spd*=.97
  setst"ground"
 end
end

-- stunned after a bad landing
s.land=function()
 spd=max(spd-10*dt)
 gvel()
 ph=1.2
 if stt>stun then setst"ground" end
end

s.roll=function()
 spd=max(spd-2*dt)
 ang+=turn*.25*dt
 gvel()
 ph=.9
 if not gnd then toair() return end
 if jbuf>0 and stt>.2 and not phit(py+.9) then dojump() return end
 if stt>.45 then setst"ground" end
end

s.slide=function()
 spd=max(spd-1.6*dt)
 ang+=turn*.15*dt
 ph=.8
 gvel()
 if not gnd then toair() return end
 -- jump only with headroom
 if jbuf>0 and not phit(py+1) then dojump() return end
 if wall then spd*=.5 end
 if not xx and stt>.35 or spd<2.5 then
  ph=1.8
  if phit() then
   -- still under something
   ph,spd=.8,max(spd,2.5)
  else
   setst"ground"
  end
 end
end

s.vault=function()
 local k=min(stt/vdur,1)
 py=vy0+(vtop+.05-vy0)*k
 vx,vy,vz=cos(ang)*vspd*.3,0,sin(ang)*vspd*.3
 pmove()
 if k>=1 then
  spd=vspd
  vx,vy,vz=cos(ang)*spd,vt==3 and 2.5 or 1.5,sin(ang)*spd
  toair()
 end
end

s.wallrun=function()
 wrt-=dt
 vy-=g*(.05+(1-wrt/wrmax)*.55)*dt
 wrs=max(wrs-dt)
 vx,vz=cos(ang)*wrs-wnx,sin(ang)*wrs-wnz
 pmove()
 if gnd then land() return end
 if airgrab() then return end
 if jbuf>0 then
  wallkick((vz*wnx-vx*wnz)*.9,4.8,"wall jump")
 elseif not wall or wrt<=0 or xp then
  vx+=wnx vz+=wnz
  setst"air"
 end
 peak=py
end

-- run up a wall head-on
function wallup(vin)
 wupd=true
 snapface(wall)
 vy=max(vy,4+vin*.7)
 trick("wall climb",.05)
 setst"wallup"
end

s.wallup=function()
 vx,vy,vz=-wnx*.5,vy-g*dt,-wnz*.5
 pmove()
 peak=max(peak,py)
 if gnd then land() return end
 if airgrab() then return end
 if jbuf>0 then
  wallkick(0,4.5,"wall jump")
 elseif vy<-1.5 or not wall then
  setst"air"
 end
end

-- hanging / cat leap on a ledge
s.hang=function()
 if stt<.12 then return end
 if iu and airjump or jbuf>0 and not id then
  startpull()
 elseif jbuf>0 then
  jumpback()
 elseif xp then
  ngrab=.35
  toair()
 elseif turn~=0 then
  -- shimmy along the edge
  local ox,oz,b=px,pz,hb
  px+=sin(ang)*turn*1.4*dt
  pz-=cos(ang)*turn*1.4*dt
  local x,z=px+cos(ang)*.6,pz+sin(ang)*.6
  if not inside(b,x,z,.1) or phit() then px,pz=ox,oz end
  aph+=dt*1.5
 end
end

s.pull=function()
 local k=min(stt/pdur,1)
 local a=lerp3(pa,pb,max(k*2-1))
 px,py,pz=a[1],lerp3(pa,pb,min(k*1.6,1))[2],a[3]
 if k>=1 then
  spd,gb=hcat and iu and 4 or 1
  setst"ground"
 end
end

-- ladders + drainpipes (yellow):
-- always face their broad side
function startclimb()
 cb=wall
 local zf=cb[4]-cb[1]>cb[6]-cb[3]
 snapface(cb,zf)
 if zf then px=mid(cb[1],px,cb[4]) else pz=mid(cb[3],pz,cb[6]) end
 setst"climb"
 sfx(4)
end

s.climb=function()
 local d=(iu and 1 or 0)-(id and 1 or 0)
 py+=d*2.6*dt
 aph+=d*dt*1.2
 if py+1.9>cb[5] then
  py=cb[5]-1.9
  if d>0 then hb,hcat=cb startpull() return end
 end
 if d<0 and solid(px,py-.05,pz) then setst"ground" spd=0 return end
 if jbuf>0 then
  jumpback()
 elseif xp or py<cb[2]-1.5 then
  ngrab=.35
  toair()
 end
end
-->8
-- procedural animation + 3d runner
-- pose q: 1 lean 2 side lean
-- 3 hip height 4/5 l ankle fwd/up
-- 6/7 r ankle fwd/up (ankle
-- targets: knees follow by ik)
-- 8/9 l arm/elbow 10/11 r arm/
-- elbow 12 arm spread 13 feet
-- side shift 14 body pitch
-- angles in turns, + = forward

q=split"0,0,.93,0,.07,0,.07,0,.1,0,.1,0,0,0"

-- key poses (q 1..13)
poses={}
for row in all(split("push;.06,0,.95,-.3,.12,.2,.4,.15,.15,-.1,.15,.04,0|up;.04,0,.95,-.1,.3,.15,.35,.12,.2,.05,.2,.08,0|fall;.02,0,.95,0,.18,.1,.12,.15,.15,.12,.15,.15,0|reach;.04,0,.93,.14,.08,.02,.12,.12,.12,.08,.12,.12,0|slide;-.1,.03,.45,.75,.07,-.05,.07,-.12,.05,.15,.2,.1,0|roll;.15,0,.6,.15,.4,.1,.35,.3,.3,.3,.3,0,0|land;.14,0,.56,.18,.07,-.12,.07,.12,.15,.08,.15,.06,0|v1;.15,0,1,.15,.45,.05,.5,.1,.08,.12,.08,0,0|v2;.1,.08,1,.25,.4,.15,.45,.06,.04,.08,.04,.08,.12|v3;.08,.12,1,.3,.45,.2,.5,.06,.02,.15,.12,.12,.2|cat;0,0,.95,.25,.45,.25,.4,.46,.03,.46,.03,0,0|hang;0,0,.95,.04,.1,-.03,.12,.46,.03,.46,.03,0,0|wallup;.02,0,.95,.3,.4,.24,.15,.38,.12,.42,.12,.05,0|climb;0,0,.95,.2,.3,.2,.3,.42,.1,.42,.1,0,0|pull;0,0,.95,.04,.1,0,.12,.46,.2,.46,.2,0,0","|")) do
 local p=split(row,";",false)
 poses[p[1]]=p[2]
end

-- run cycle at speed h: cadence
-- and stride from speed, the
-- stance foot moves back at
-- exactly h (planted), swing
-- foot lifts and swings forward
function gait(t,h)
 local f=1.1+h*.13
 -- legs follow the cycle closely
 rt=.75
 aph+=f*dt
 local d=min(.6,.5*f/h)
 local s=h*d/f
 -- pelvis: lowest mid-stance
 -- (runs), ballistic in flight
 t[3]=sqrt(.757-s*s/4)+.07-(.5-d)*.06*cos(aph*2-d)
 for i=0,1 do
  local p,x,u=(aph+i/2)%1,0,.07
  if p<d then
   x=s/2-s*p/d
  else
   p=(p-d)/(1-d)
   -- heel kicks up behind, then
   -- the leg reaches forward low
   -- and pulls back into contact
   x,u=sin(p)*.15-cos(p/2)*s/2,.07-sin(p/2)*(1.3-p)*(.08+h*.025)
  end
  -- arms swing against the leg
  local j=4+i*2
  t[j],t[j+1],t[j+4],t[j+5]=x,u,.03-x*.22,.14+h*.008
 end
 t[1]=.01+h*.004
end

function anim()
 rt=.3
 -- pose for this state (ground and
 -- wallrun start from standing)
 local h,n,tu=hs(),st=="air" and (vy>0 and (stt<.12 and "push" or "up") or py-shy<1.2 and "reach" or "fall") or st=="vault" and "v"..vt or st=="hang" and hcat and "cat" or st,angd(ang-bang)
 local t=split(poses[n] or "0,0,.93,.04,.07,-.04,.07,.03,.08,.03,.08,.03,0")
 add(t,0)
 -- body follows the heading with
 -- a short lag
 bang+=tu*.25
 if st=="ground" then
  if h>.3 then
   gait(t,h)
   -- lean with acceleration
   t[1]+=mid(-.04,(h-oh)*.25,.03)
  else
   -- idle: slow breathing only
   t[3]+=sin(time()/4)*.004
  end
  if crouch then t[3]-=.3 t[1]+=.1 end
  -- landing: knees take the
  -- impact, more for harder ones
  if lvy<-4 then lc=(-lvy-4)*.03 end
  t[3]-=lc
  if narrow(gb) then
   -- balance: arms out
   t[8],t[10],t[12],tu=0,0,.25,bal*-.06
  end
 elseif st=="wallrun" then
  gait(t,wrs)
  -- lean into the wall, feet on it
  local w=wnx*sin(bang)-wnz*cos(bang)
  t[2],t[12],t[13]=w*.04,.14,w*.2
 elseif st=="climb" then
  local w=sin(aph)*.12
  t[5]+=w t[7]-=w t[8]-=w/3 t[10]+=w/3
 elseif st=="pull" then
  -- arms press down as the body
  -- rises, a knee comes up to
  -- the ledge
  local k=stt/pdur
  t[1],t[8],t[10]=k*.15,.46-k*.42,.46-k*.42
  if k>.35 then t[6],t[7]=.3,min(hb[5]-py,.5)+.07 end
 end
 lvy,oh,lc=st=="air" and vy or 0,h,lc*.85
 -- lean into turns, more when fast
 t[2]-=tu*(h+3)*.12
 if n=="roll" then t[14]=min(stt/.45,1) end
 for i=1,13 do q[i]+=(t[i]-q[i])*rt end
 q[14]=t[14]
end

-- local (fwd,up,side) -> screen,
-- body pitch q[14] about the hip
function jp(p)
 local f,u,s=unpack(p)
 local ur=u-q[3]
 f,u=f*pcr+ur*psr,ur*pcr-f*psr+q[3]
 local c={tocam(px+bfx*f-bfz*s,py+u,pz+bfz*f+bfx*s)}
 if c[3]>near then
  local p=proj(c)
  p[3]=c[3]
  return p
 end
end

-- next joint: length l at swing a,
-- sideways spread sp on side sd
function seg(o,a,l,sp,sd)
 return {o[1]-sin(a)*cos(sp)*l,o[2]-cos(a)*cos(sp)*l,o[3]-sin(sp)*sd*l}
end

-- point along the spine at t
-- (shifted over the stance leg)
function spn(t,f,s)
 return {sdf*t+lcf*f,q[3]+sdu*t+lsf*f,sds*t+s+sh}
end

-- queue a tapered limb segment
function cap(a,b,r,c)
 if a and b then add(bp,{(a[3]+b[3])/2,a,b,r,c}) end
end

function drawplayer()
 local l,sl,hp=q[1],q[2],q[3]
 bfx,bfz,pcr,psr,bp=cos(bang),sin(bang),cos(q[14]),-sin(q[14]),{}
 -- spine direction + forward axis
 sdf,sdu,sds,lcf,lsf=-sin(l),cos(l)*cos(sl),-sin(sl),cos(l),sin(l)
 -- pelvis drifts over the foot
 -- that carries the weight
 sh=(q[5]-q[7])*.06
 -- shadow blob
 if shy>0 then
  local sc={}
  for i=0,3 do
   add(sc,{tocam(px+cos(i/4)*.35,shy+.02,pz+sin(i/4)*.35)})
  end
  cpoly(sc,5)
 end
 local head=jp(spn(.76,0,0))
 if not head then return end
 -- which side faces the camera
 local cs=(cpos[1]-px)*-bfz+(cpos[3]-pz)*bfx>0 and 1 or -1
 local lg={}
 for sd=-1,1,2 do
  local i,nr=sd<0 and 4 or 6,sd==cs
  -- leg: two-bone ik from the hip
  -- (pelvis turns with the
  -- stride) to the ankle target,
  -- knee bends forward
  local h,az=(q[6]-q[4])*sd*.05,sd*.12+q[13]
  local f,u=q[i]-h,q[i+1]-hp
  local d=max(sqrt(f*f+u*u),.05)
  local x=(.0176+d*d)/2/d
  local y=sqrt(max(.2025-x*x))
  local k,an={h+(x*f-y*u)/d,hp+(x*u+y*f)/d,sd*.15+az/2+sh/2},{h+f,hp+u,az}
  -- foot square to the shin,
  -- flat on the ground
  add(lg,{jp{h,hp,sd*.17+sh},jp(k),jp(an),jp{an[1]-(an[2]-k[2])*.46,max(an[2]+(an[1]-k[1])*.46,.02),az},nr})
  -- arm: shoulder, elbow, hand
  local so=spn(.47,0,sd*.24)
  local el=seg(so,q[i+4],.28,q[12],sd)
  local je=jp(el)
  cap(jp(so),je,.065,nr and 8 or 2)
  cap(je,jp(seg(el,q[i+4]+q[i+5],.26,q[12],sd)),.055,15)
 end
 -- two legs must always read as
 -- two: every joint pair keeps a
 -- leg width + 2px apart on screen
 local a,b=lg[1],lg[2]
 if a[1] and b[1] then
  local sg=sgn(b[1][1]-a[1][1])
  for i=1,4 do
   local p,o=a[i],b[i]
   if p and o then
    local m=max(.22*fl/p[3]+2-abs(o[1]-p[1]))/2*sg
    p[1]-=m
    o[1]+=m
   end
  end
 end
 for g in all(lg) do
  local c=g[5] and 1 or 0
  cap(g[1],g[2],.1,c)
  cap(g[2],g[3],.08,c)
  cap(g[3],g[4],.06,7)
 end
 -- pelvis, torso, backpack, neck
 for p in all{split"0,.04,.15,1,0",split".18,.42,.19,8,0",split".22,.36,.12,5,-.12",split".5,.76,.05,15,0"} do
  cap(jp(spn(p[1],p[5],0)),jp(spn(p[2],p[5],0)),p[3],p[4])
 end
 -- head: skin in front, hair behind
 cap(head,head,.15,15)
 local hb=jp(spn(.78,-.05,0))
 cap(hb,hb,.14,0)
 -- painter's order within the body
 isort(bp,1)
 for p in all(bp) do
  local a,b,r,c=unpack(p,2)
  -- tapered capsule: a chain of
  -- discs, radius by depth (limbs
  -- are short enough for 6)
  local ra,rb=r*fl/a[3],r*fl/b[3]
  for t=0,1,.2 do
   circfill(a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t,ra+(rb-ra)*t,c)
  end
 end
end
-->8
-- third-person camera
-- lags behind the heading, pulls
-- back + widens fov with speed,
-- never clips into walls

-- shortest signed angle diff
function angd(a)
 return (a+.5)%1-.5
end

function camreset()
 cyaw,fl=ang,70
 cam,look={px-cos(ang)*4,py+3,pz-sin(ang)*4},{px,py+1,pz}
 camupd()
end

function camupd()
 local h=hs()
 cyaw+=angd(ang-cyaw)*(st=="hang" and .03 or .05+h*.005)
 local d,fx,fz=2.8+h*.14,cos(cyaw),sin(cyaw)
 -- above + behind, looking down
 -- at the runner and ahead
 local t,w,lk={px,py+1.4,pz},{px-fx*d,py+2.8+h*.04,pz-fz*d},{px+cos(ang)*(1+h*.4),py+.9,pz+sin(ang)*(1+h*.4)}
 if st=="wallrun" then w[1]+=wnx*.9 w[3]+=wnz*.9 end
 -- boom collision: stop before a
 -- solid; too close -> lift up
 for k=.15,1,.15 do
  if solid(unpack(lerp3(t,w,k))) then
   w=k<.55 and {px-fx*.3,py+3,pz-fz*.3} or lerp3(t,w,k-.15)
   break
  end
 end
 cam,look=lerp3(cam,w,.18),lerp3(look,lk,.2)
 fl+=(72-h*1.7-fl)*.1
 shake=max(shake-dt)
 cpos={cam[1]+rnd(shake)-shake/2,cam[2]+rnd(shake),cam[3]}
 local lx,ly,lz=look[1]-cpos[1],look[2]-cpos[2],look[3]-cpos[3]
 local yaw,pit=atan2(lx,lz),atan2(sqrt(lx*lx+lz*lz),ly)
 ccy,csy,ccp,csp=cos(yaw),sin(yaw),cos(pit),sin(pit)
 cfw={ccy*ccp,csp,csy*ccp}
end

-- world -> camera space
function tocam(x,y,z)
 x-=cpos[1] y-=cpos[2] z-=cpos[3]
 local f=x*ccy+z*csy
 return z*ccy-x*csy,y*ccp-f*csp,f*ccp+y*csp
end

-- camera space -> screen, cached
-- on the point (shared corners
-- project once per frame)
function proj(c)
 local z=c[3]
 c.s=c.s or {64+c[1]*fl/z,64-c[2]*fl/z}
 return c.s
end
-->8
-- 3d rendering: painter's sort
-- of boxes, near-plane clipping,
-- scanline polygons, fog, sky

near,fr=.2,0

-- convex polygon fill: downward
-- edges fill one side, upward
-- edges the other
function poly(v,c)
 local l,rr,y0,y1={},{},999,-1
 for i=1,#v do
  local a,b,t=v[i],v[i%#v+1],l
  local ax,ay,bx,by=a[1],a[2],b[1],b[2]
  if ay>by then ax,ay,bx,by,t=bx,by,ax,ay,rr end
  local sl,ya,yb=(bx-ax)/(by-ay),max(ceil(ay)),min(ceil(by)-1,127)
  local x=ax+(ya-ay)*sl
  for y=ya,yb do
   t[y]=x
   x+=sl
  end
  y0,y1=min(y0,ya),max(y1,yb)
 end
 for y=y0,y1 do rectfill(l[y] or 0,y,rr[y] or 0,y,c) end
end

-- clip camera-space polygon
-- against the near plane
function cpoly(vs,c)
 local o,n={},#vs
 for i=1,n do
  local a,b=vs[i],vs[i%n+1]
  if a[3]>=near then add(o,proj(a)) end
  if (a[3]<near)~=(b[3]<near) then
   local t=(near-a[3])/(b[3]-a[3])
   local c=lerp3(a,b,t)
   c[3]=near
   add(o,proj(c))
  end
 end
 if #o>2 then poly(o,c) end
end

-- insertion sort, largest key
-- first
function isort(t,k)
 for i=2,#t do
  local p,j=t[i],i-1
  while j>0 and t[j][k]<p[k] do t[j+1]=t[j] j-=1 end
  t[j+1]=p
 end
end

function lerp3(a,b,t)
 local v={}
 for i=1,3 do v[i]=a[i]+(b[i]-a[i])*t end
 return v
end

-- point on face quad (u across,
-- t up) for decorations
function fp(q,u,t)
 return lerp3(lerp3(q[1],q[4],u),lerp3(q[2],q[3],u),t)
end

-- sub-quad u0..u1 x t0..t1
function fq(q,u,t,v,w)
 return {fp(q,u,t),fp(q,u,w),fp(q,v,w),fp(q,v,t)}
end

-- corner order per axis so that
-- 1-2 and 4-3 are vertical edges
faces={split"1,3,7,5",split"1,2,6,5",split"1,3,4,2"}
-- box corner i: x/y/z index
ci,cj,ck=split"1,4,1,4,1,4,1,4",split"2,2,5,5,2,2,5,5",split"3,3,3,3,6,6,6,6"
fpat=split"0x3333,0x5555,0x7777,0x5a5a"
dpat=split"0,0xf0f0,0,0x3333,0,0,0,0xa5a5"

-- must a be drawn before b?
-- every separating plane must have
-- the camera on the same side (if
-- not, or the camera is between
-- them, they can't overlap: no
-- constraint). intersecting boxes
-- fall back to distance
function behind(a,b)
 local r
 for i=1,3 do
  local c,s=cpos[i]
  if a[i+3]<=b[i] then
   s=c>=b[i] and 1 or c<=a[i+3] and 0 or 2
  elseif b[i+3]<=a[i] then
   s=c<=b[i+3] and 1 or c>=a[i] and 0 or 2
  end
  if s then
   if s==2 or r and r~=s then r=2 break end
   r=s
  end
 end
 return r==1 or not r and a.d>b.d
end

function render()
 sky()
 -- player pseudo-box joins sort
 plb={px-r,py,pz-r,px+r,py+ph,pz+r}
 dl[#dl]=plb
 -- d: centre distance (tie
 -- break), e: gap distance (fog),
 -- f: depth of the nearest
 -- corner (all behind: culled).
 -- boxes in range and in front
 -- get camera-space corners and
 -- screen bounds
 local v={}
 for k=1,#dl do
  local b,d,e,f=dl[k],0,0,0
  for i=1,3 do
   local c,m=cpos[i],(b[i]+b[i+3])/2
   d+=abs(m-c)
   e+=max(max(b[i]-c,c-b[i+3]))
   f+=(m-c)*cfw[i]+abs((b[i+3]-b[i])*cfw[i])/2
  end
  b.d,b.e=d,e
  if e<sk[8]+24 and f>near then
   local x0,y0,x1,y1,cs=999,999,-999,-999,{}
   for i=1,8 do
    local c={tocam(b[ci[i]],b[cj[i]],b[ck[i]])}
    cs[i]=c
    if c[3]<near then
     -- corner behind us: unbounded
     x0,y0,x1,y1=-999,-999,999,999
    else
     local s=proj(c)
     x0,y0,x1,y1=min(x0,s[1]),min(y0,s[2]),max(x1,s[1]),max(y1,s[2])
    end
   end
   b.cs,b.bx=cs,{x0,y0,x1,y1}
   -- on screen? far ones are flat
   -- fog: a rect, no sorting (and
   -- skipped if they reach behind
   -- the camera)
   if x1>=0 and x0<128 and y1>=0 and y0<128 then
    if e<sk[8]+10 then
     add(v,b)
    elseif x0>-999 then
     rectfill(x0,y0,x1,y1,sk[7])
    end
   end
  end
 end
 -- painter's order: topological
 -- sort over screen-overlapping
 -- pairs (dfs, back to front),
 -- starting far to near so most
 -- boxes behind are already drawn
 isort(v,"d")
 fr+=1
 local function visit(b)
  if b.mk~=fr then
   b.mk=fr
   local x0,y0,x1,y1=unpack(b.bx)
   for i=1,#v do
    local a=v[i]
    local p=a.bx
    if a.mk~=fr and p[1]<x1 and p[3]>x0 and p[2]<y1 and p[4]>y0 and behind(a,b) then visit(a) end
   end
   if b==plb then drawplayer() else drawbox(b) end
  end
 end
 for b in all(v) do visit(b) end
end

function drawbox(b)
 local m,cs=mats[b.m],b.cs
 local fog=b.e>sk[8]
 for ax=1,3 do
  local sd=cpos[ax]>b[ax+3] and 1 or 0
   if cpos[ax]<b[ax] or sd==1 then
    local q={}
    for k in all(faces[ax]) do add(q,cs[k+sd*(ax==3 and 4 or ax)]) end
    local c=ax==2 and sd==1 and m[1] or m[ax==1 and 2 or 3]
    if fog then fillp(0x5a5a) c+=sk[7]*16 end
    cpoly(q,c)
    fillp()
    -- details only with cpu to spare
    if ax~=2 and not fog and stat(1)<.9 then deco(b,m[5],q,c) end
   end
 end
end

-- surface details on vertical
-- faces. deco: lo=type hi=colour
-- 1 window bands 3 poster 5 vent
-- 7 cross brace
-- 2/4/8 full pattern (rungs,
-- stripes, rough stone/grime)
function deco(b,dk,q,c)
 local h,t,k=b[5]-b[2],dk%16,dk\16
 if t==1 and h>3 then
  fillp(fpat[flr(b[1]+b[3])%3+1])
  for y=1.4,h-1.2,3 do
   cpoly(fq(q,.06,y/h,.94,(y+1.3)/h),c+k*16)
  end
 elseif t==3 and h>1.5 then
  fillp(fpat[b.k%4+1])
  cpoly(fq(q,.08,.15,.92,.85),split("0xa9,0x7c,0xeb,0xb3")[b.k%4+1])
 elseif t==5 then
  fillp(0x0f0f)
  cpoly(fq(q,.2,.25,.8,.75),c+k*16)
 elseif t==7 then
  for i=1,2 do
   local a,e=q[i],q[i+2]
   if a[3]<near or e[3]<near then return end
   a,e=proj(a),proj(e)
   line(a[1],a[2],e[1],e[2],k)
  end
 elseif t>0 then
  fillp(dpat[t])
  cpoly(q,c+k*16)
 end
 fillp()
end

-- sky gradient, sun, skyline
function sky()
 local hy=mid(-20,64+fl*csp/ccp,150)
 cls(sk[1])
 fillp(0x5a5a)
 rectfill(0,hy-34,127,hy-18,sk[1]+sk[2]*16)
 fillp()
 rectfill(0,hy-18,127,hy,sk[2])
 if sk[6]>0 then circfill(64-angd(.1-atan2(ccy,csy))*fl*6,hy-30,7,sk[6]) end
 -- Distant buildings are the level's authored geometry, drawn as fog
 -- silhouettes by render(), so landmarks keep their actual location.
 rectfill(0,hy,127,127,sk[5])
end
-->8
-- Speed is conveyed by camera distance/FOV and the runner's cadence.
-- No random screen streaks obscure upcoming landing surfaces.
__gfx__
0100ff5027a07dd02131b181cbb176f1001020384850687080f878b8c8d8e8f0c090d04050a0d0a1000c8060402011d0e0401060d050555000000060d0500060
50502050e020308020204740402000c0101000000000000000000000000000d050101a00402084f80000000000000005838810840080000700808080b0800040
00070084c061d080000300070084c081d18100840007006040403444008400070060404034070084000700604040340000080007000530205480000900070084
c001d200004b0087000510105002004b00070010401050e7004b0007001040105087000d0007001080109087006e00070010801090e8000d00070010801090e8
006e000700108010906700ec000800e0a0e09001000d0007004020403480000e00070003c081d30100821000000503862001008310060005c080b10100051006
0005c082da820086100600012001a0070086100600012001a001000a10060005c0c0db23006f1006006001106002008b10060061c0f1d587008b100600804060
3407008d10060001a00110c6000a100600a1c0c1d407008d10470001c001d7c4008b10060001c0f1d602008f100000050447e002000020080005c080b2040003
200800604040340600052008008050403403000720080001c08110090004200800108110508c0002200000014303200c000a20e700811010500f000a20870010
40105089000920080041c041d80b00ec20480082e010700d000d200000102410508e000d2000001024105008008b20080081c041d60f000020000084c387104f
0000208700a0c087b3821003208700012081a0031009208700604040340510092087006040403485100120870001c001e002104120090081c010710210412087
0010c01040e4104120870010c0104006100420870001c083d308100c204600a010c040081089204500a010c0400a1004200000844207200e1008208400804060
3400200b208400604040344a10e1308400204210600a108f208400a0c031d50c1001300500011080804e1041306700011060404b100e208400e1c081d9071002
3000000584871007108230090005c080b4081006300900604040340a1006300900604040340c1006300900604040340e10063009006040403407100930890005
10105009100930090010401050ee10093009001040105009108b300900012001a00d108b300900012001a087100e3009001080109087106f30090010801090e8
100e30090010801090e8106f300900108010906710ed300a00e0a0e0900d100f3009000241107208108240000004444420891005408800805080340d10864088
00604040340a100b406800101001400a100d4087001080104006100d40000004c3841006100e40870004c080b5071001508700604040340b1081508700802001
a006100350870002c081dc0d1006508600c08043100d1006508700106043506e1006508700106043508d10095087006030403409100650670010104350e71085
50c7001001c171e7108750000010e31050e9108850080010014272e9108a5000001004105005108c5000000504c42005100e50080005c080b686108060080060
40403405100060080005c0c1dd061006600000044503e00810846008004060c0108810846008004040c0100910846008004020c0100610846008000180c010a6
10e560090060c010608b100460080080c0a0108b100260080080506034081008608a000210815008100860aa0002b081c00c100b608a00108110504900cf0007
0040a040f041004e10060040a040f08f008d20870040a040f040200040090040a040f0ce108940880040a040f081008c10c7000410105081008c10060010e010
5089008c10060010e01050c1008c10670050301071a8008c1067005030107209ff00000000828587e00aff02100000828288200bff05200000828609100d0000
000000838487200e000110000083020610000000300000060306200d0002300000040686e005200320000004050ae0032009300000838386200c000640000084
05871001200b400000830646e00c0008500000048606e001200a5000008305871004100f600000068883200d0006600000830486100f00050009008101107300
102030405060708090a0b0c0d0e0f0c060d060407060a1e00c6060d0d08590404042c0c010419040400050005000a0909020a0a09040b030308340402000c010
100000000000000000000000000050501000a0a0907096000fff0fff00008241823082000fff8200c0a08130800000008200c0c080b00fff0fff820082c002d0
0fff04006200031001900fffc500000010311040e400c5000000103110400eff06004400062006100eff06004600062082100eff8c0046000620c01006000b00
46000220c0100eff0a0048000620041006000f000000014501e00eff06000000302430100effa110000030243010a9000600000030243010a900a11000003024
30100000e500820060011060420005008200805080908300e5008200c00110200fff0400820003c0f0d10eff8600840006c080b10eff09008400823020548600
0a008400c04080340eff8c002500032020500eff8c00840010502050e3008c008400105020500eff8a00840003c0e0d280000e0084006001106082004e008400
a050809082000e002500a05060900eff0e00840001011020860007008600804080348700e900860060011060010088008600c080c09048004e008400c020604d
c900ce008400100220f00300e9008600c00110200eff0600860006c0e0d30eff8a00880006c080b20a000d0048000220c0908b000d000000202410408b006e00
0000202410408f000d0048004220c09001100d0000002024104001106e000000202410400a0080104800052080908d0041100000202420400110411000002024
20400a004f006800051020400a00cc000800056020400b00ec00c800c3e0107007008b00880081c043d404100600480004200610071006004a00042006100a10
06004c00042006100d1006004e0074200610041006000000302430100410a110000030243010ab100600000030243010ab10a110000030243010ae1006000000
30253010ae10a110000030253010a1200600000030263010a120a110000030263010852006000000302730108520a110000030273010041086008800c0c085b3
e6100600880010010620c610070088001001606085100a008800b050019004100900880041c002d5e91006008a0010010620c91000108a001001606008100a00
8a00f080c090c71086008a001150c090481086008a00d0a0c090ec1006008c0010010620cc1007008c00100160608b100d008c00b05001900d1086008e00c0c0
85b4002009008e008050c03401200e008e00c040803406200b00000080a880f0e5204b008e00106140600a106b0001100620204007200b008010018080300320
0b00af00c0108090b3206b00cf0010a01050012009008e0072c003d60c10ea008f0001c0a0300e100b00411001c080c006ff041000000303031006ff04100600
0320031006ff041008000320031006ff0410460020e02010cbffc910460020e020100a000910000083c0823009ff00000000818081900f000000000081a0c030
8f0000004100c060c0400d2000000000800a80f00320600004100720204001ff03200000058705100e10091000000506051000102038405068708098a0b84858
90f0c090d0005000d0815100e060d05040303010819040205560505070d0505000a0909020a0a09040b030308340402000c0c010400000000000000000000000
00d000000080802042e4000bff0bff00000f8087e009100bff00000f800ae007300bff00000a800ae082500bff0000c8800ae0cfff0bff0100208287100000c9
0001008c82201000000bff01008c82201000000bff06008c208710800081000100c0c001b000004bff010002c0e4d006004bff0100604065740b004bff810040
2065500b00c5000100404020400f00000001006050819403100fff010081c0823409004bff010001c065d402000800e2000b10e040e100480001001001606007
00850001008050809007008600010080a0809001000600010081c0e1d108108bff0100c0c007b1861087000300c0c001b10a10080001000341a0f00220080001
000341a0a00a20080001000341a0f00c108500010002a0a0a003208500010002a0a0f009208500010002a0a0a00b10850001008050a0900f1081000100c05080
34852000000100804002900c200fffa1004020c2500c200fff0100405020400c20440001004050204009100800830001c0a0d200308bff0100c0c0c9b2013049
0001007203022008308a000100028202200e300cff0100028202200e200800830001c0a0d30530080043000b20a0500530860043000b20205005308600010040
2141400d308600010040214140044086000100402141408a408600010040214140e43028000100104160600c3006000400402082500140c70083006040a03406
40060004004020c1500c3006000100408120400640060001004081204008300600830081c0c1d4094008008300c0c0a0b3094066008300c0c040b309408bff01
00c0c045b30b4003008000c34020408c40c7000000a0b1c0208e40870063004710e07e8e40c700000040b1a0400650c700000040b1a0408c50c700000040b1a0
400350670001006041106008400600830081c0c1d50e500600010002028220ed5007000100100260608b50c70083008050a0908e508600050081c002c00a0004
100000c087c020032009100000c00ac010014086100000c0c8c0200a5004100000c046c0100e1001ff0000c087c020064001ff0000c007c01000000f0000000a
0405100d20041000008705051004600bff000005840a100010203848506870809078b81858e0f000000000000000e0b10c0060d0d085d0303015904020556050
5070d0505000a0909020b0b030300000000040402000a0a0a057000000000000000000000000500000006090901ad7008fff8fff000006800ee0000000000100
42500a1086000000010001508d108a000000010040508d108fff0000010040c10a200b000000010040c1cd208fff8fff010006c140208fff8fff840006200e20
8fff0410010082c1402088000b10010081c1402086008a10010001c1402083000600a100407140e007000600a100407140e083000e00a100407140e007000e00
a100407140e001000600a1004040c03487000b00a1004040c034a40002000100e0e082f0a40008000100e0e082f0a4000e000100e0e082f04500070041004020
80e045000d004100402080e0e80003000100c0e0c2fce80089000100c0e0c2fce4000000010010108d4006000000010010108d4029000000010010108d400a00
0000010010108d400400431001004150a010840004106400011040208200e31003000160107084008410a2000210804048008410010020d080e0860088100100
0190011007000810a100c0204010020003006400401001a0880003006400401001a002000f006400401001a088000f006400401001a001008000a10001c080b0
00000000a10042c081d004008410000081804ce004008410010040814c2086008410010040d080208600861001004081012086008a1001004081492004008410
840081204c2084000410010050500140840006100100507040108400861001005090824084000d1001005090034084008420010050904440c500081001005040
403425000e108100b020205084000020c2005010205045000910e300401080a045000120e300401080a045000920e300401080a084008410a10001c041d18400
0a10010001c0c1d284008410010001c041b10dff8c200000888007e08cff8c200100404307200e008c200100404307208cff8c200100c343402007008c200100
c34340208cff0a3001000443402086000a3001000443402084000a30c600016040208cff8c208700092007200dff87304400882041100dff6730010088a11020
00004730010060c1106084000d2001005090824084000230010001e0c0f08400043001000131c0f08400063001000181c0f04600823004002001825000004730
050001601070010000306700801001a0090000306700801001a00dff0d20010088c080b284000d20220050c080b20dff0430010088c0a1d30dff0830840088c0
01b384008a304400012043108400824044000120c1108400014044004020c04005000640440020200240c500064044002020024084000a404400012084100400
8a30000040634c2086008a30000040634c2004008a30c60081204c2084000e30050001202050c40084408400c040403445008c30a600401080a045008340a600
401080a045000c40a600401080a084000340840001c061d484008240840001c040b4000003500000854206108fff8250840082c1402086008250840082c14020
8fff0350840040c106200b000350840040c106208fff0f50840006c140208fff8250080006208620810006508400504060344400065084005040603485000650
8400504060344800065084005040603404000a5084008120821004008a5084008140421004000b5084008160021004008b5084008180c11004000c50840081a0
811004008c50840081c0411004000d50840081e0011004008d5084008101c01004000e5084008121801004008e508400814140108400ee508700014010708400
0350840001c080b504000d50070081c001c0001020b8405060708098a0b0c0d0c8f0c060d010507060c1020c6160d0d0115040201160d0505550000000605050
0060505020507060308080208730404000d0c0e01100000000000000000000000050500000e0e01050870009ff0bff00008d800ee009ff071000008d808de009
ff023000008d800ae000000dff0100c0108c1086000dff0100c0108c100aff0bff01008a0301200aff0dff0100032106200aff090001000322862008000dff01
0083428c100b000dff850002c486a0030000000100c0c0c0b081000dff010082c0c2d0e60001002300901081400700e000210060111060e70003004300102160
60c40003000100806001f0450085000100a090a13006008900620001100180c6008c00a300a0100240c60080106500a010814007006010c30060e01060c4000d
000100c0e0c37fc20003100100c0b08130c20006100100c08080a0000003106300c0108180000085108400a010c04000008510830010906060030082000100c1
c081d1810081000100806001f0000004002200a01001808dff02004300805060348bff85004300605080348eff08004300807080300cff0f004500806080308c
ff0210e500810110728cff02104500105010406fff02104500105010408800050085008030819009000a0085008050603408000c0026008110205008000c0085
0010502050ea000c008500105020508b000d008500413081a00c00021085000150803008000000850081c002d209000610040001b041a0eeff06102500101041
500aff881065008a10c0100aff0410450003c001d30aff881085008ac0c0b18900e910850060c010608eff4910850080506034030029108500a03060900aff0a
1001008a0306a001000e10070002e002200200ed10070060e0106005008e1007008050a03407008c100700813081a08bff0c100700803002900eff0d10070001
3060900b000c100700c05080348b0001200700108010108b006220070010801010ec000120070010801010ec0062200700108010106b00e0200800e0a0e0108a
ff0320a700020110738aff03200700105010406eff03200700105010400fff012007008060013007000220a70042102050070002200700105020500aff0a1007
008ac001d40cff06200100082209e00cff06204500082009100cff0820850010400850eb0008208500104008508dff09208500805001f081000a208500805001
30860009208500805001f08dff0d208500805001f081000e2085008050013086000d208500805001f08dff01308500805001f081000230850080500130860001
308500805001f009000e20850081c08120e8008e20850010c0606004000c204600c010105004000c2085001060104084000b2085001001105084000330850010
0110500cff8620850008c0c0b20cff0820850008c081d50cff08300100084385a001000b308700040104a003000e308900020182a0e40081408b0020c120500c
ff0530850008c061b30cff0530850008c061d60000e730850060011060040007308600c01080900400e730a600107010506500e730a600107010500400e73087
00c01030408100ea30870060011060840009308700a050803484000a308700a0a080308300ed308900600110604400cc308a00c010a0904400ed30aa00107010
50a500ed30aa00107010504400ed308b00c010304003008e308b0002c002c0041000000000030f03a00cef0e100000038c0310041003200000c34bc3a00fef07
300000830a831000100c30000083cd83a00bff0b400000848f04a000102030405068708088a0b8c0d0e0f00010201000701002720c21d010201ad020101e60d0
50556050100060d0d00060505020e0e0c030e0e0208740402000c010101c000000000000000000000000500000006010d05c45000fff0dff0000040689100200
8dff0c0001c0c0b00fff0dff0c0004c002d0010004000c00024060340fff0900ac00042020500fff09000c0010502050e60009000c0010502050c4000c000c00
10801090c4006d000c001080109026000c000c001080109026006d000c0010801090a400eb000d00e0a0e09007000300070030026071aeff0a00060030426072
8fff00108a0080408120460001000c0040c140710fff03100000048508200fff03100b0004c0c0b1810006100b00813001a00fff0e10ab0082b010730fff0e10
0b0010501040e3000e100b00105010400fff0f100b0004c002d10fff04100b00104103720600032089002081837006004620000020c440e004000320aa000110
4140040007202a000110814000000320ea00201083400dff0a20000005058b100dff0a200a0005c0c0b2040080300a008130c030040080306a008110c0800400
02300a0081c08720e60008308b0010c010500dff00300a00104103730eff0e200a00c0408034000004300a008050c0348dff09300a00804080348eff0c300a00
108010908eff6d300a0010801090efff0c300a0010801090efff6d300a00108010906effeb300b00e0a0e090800006300a00803001a00dff0b200a0005c081d2
0eff0140000001e421200eff0440000001d4c0200dff4440000005c4e5200dff4440890005c0c0b303000a408900014060340dff0d402a00812020500dff0d40
890010502050efff0d408900105020500dff0c40890005c002d346008640890040c1407200000050c70002200a1081000650000080e380e081000e50000080e3
80e0400002500800c0c008f082000850080080406030c1000d50a80021202050e3000d5008001050205000000050080002c0c0b40eff04600000048505a08100
8260080041c0c07382006260080060c010600200e360890060c0106000000f50080002c081d40fff84600b0003c002c00fff0d000c0010108150e6000d000c00
101081500fff00200b0010108150e60000200b00101081500dff0e300a0010108150e6000e300a00101081500dff0d40890010108150e6000d40890010108150
01ff0a000000030a03200d0009100000034b031002ff02300000030983a00e000c300000038c032004ff05500000038a03100c0002600000038903a000102038
485060708090a0b8c068e0f0c07060d0307060e1c20ca160d05085407060154040200040202000904040004090402080c0a03080802087404020007060600000
000000000000000000000050000000b030300055000eff0cff00000481041080008cff0300c0c0c0b00eff0cff030004c081d003000eff030041c0032083000d
ff0300c050803040000400e200801081902000040063001010815020000400e200105010402000e600e200105010404100040063001010815041000400e20010
5010404100e600e20010501040feff0400e200101081500eff0100030082c081d10eff0700000084810510030007000300418081200eff0b00030041e0412001
0009000300604060340eff0700030082c0c0b10dff01100000058486108dff8f00e4004110c0900eff6f0003006001106000008f00e6004110c0908dff8f0003
0010f0104062008f00030010f11040efff00100500100160600100e010070060011060c200e01003006003106084008e00030001a0411044004f00440001a0e0
10c400ef00850001a0901084008010c60001a040100eff0d00030084c001d20dff0110090005c0c0b28dff0610090001c041200400071009008050803400000e
10e8006010039000000520e80060100390efff0e10690010108650c0000e106900101086500000ea2009006080106003000e10e80020108240820003200000a0
a4a01003004420290020106140820007200000a0c4a01003004820690020106140c4000f1000000194811005008320000001c4411084008720000021f44110ef
ff0e10090010401040efffea20090010401040c0000e10090010401040c000ea200900104010400dff0b10090005c081d30dff0b200000050586f00dff0b200a
0005c0c0b30dff8c200a0005c080d40eff0e200a0082c081200eff01300a00826181200eff04300a00820202208effed200a0060c010608effe0308b0060a010
608effe330cc0060a0106001000d200a0080308030030002306b006010c090040000300a0001a0013003008430ec0001101050050004300a00018101100dff08
300000050784100dff08300e0005c0c0b40dff01400000048805a00fffe0400e0060811060020000400e0041c080100dff0c300e0005c081d500000640011001
c001200eff0540011010011050040005400110100110502eff0540a210f21010710eff0240011003c041c007ef04100000058c871009ef07100910038184a001
1008200000858b871003100b200710838184a00cef0b400000060f87100a0000500000060a061000102038405068708098a0b0c8d888f020905000008020a123
0ce160500085d050201560d0505590404070d050500060505020a0a000408080208760501000c0c0100000000000000000000000000050100081808020404500
050000000000028a0ce00eff8bff0eff09018fa00000081001000702811000000cff0500070202100000081009000702811000000cff0d000702021000000000
__gff__
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
__map__
080028020204900000004800280202040000c0000800280202049000c00048002802020400004001080028020204900040014800280202040000d0ff0c00180268010000b8000c00180264012600a0000e0001010c050800d0ff1000100c0c0b0000d0ff1000180c180d08003000100010040643000070001800180202053000
70001800100202051800300110000c10280224002e0110000610010624007e013000061001060000400110000c0a0a0f0000540110000c140a0f0000680110000c1e0c0f0000f0001000180c181d000080015000280c181b70009001500006040c43b000f0004c0018024801b00000004c001802500190004001580028020205
e0009000580002143807e000c0000000022c0204c000b8004e0010011009b400a0004e0001012805b00000015000180c182db8006000500010040643d0000000500006200106b0001c0050000c0a0a09b000000050000c140e090000c0ff9000700c0c2b300000008c00100230013000c0008c00100260013400180090000c04
064330004000980010020205380078008e000c011809320060008e0001013005300000009000100c083d4000200190000810300232007e0190000620010630004801a2000801080930006401b6000801080940006401b00008040e0200008001d000700c183b9000f000cc001002480190000000cc001002480198004c01d000
08030643ac009000ce00010130059000a800ce000a01180994005000d0000c04064390004001d000100c184d90000000d00008102002a2000000d00006200106a0002000e40008010809a0000800f8000801080990000000f00008050c028000c0ff1001300c0c4b7e00feff1001062001066200c8ff10010c0a0a0f6200dcff
10010c140a0f6200f0ff10010c1e080f5000d0ff1001081018020000c0ff1001700c0c5d500000005001200c0c5b580070005001180406435000d0005a01200202055000d00050010105020560002001500110050643500060015001200c100cc0feb0ff000030e0380e90015000000030c8380ee0fe9001000030a038016001
e001000030f0300e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
__sfx__
000300001e62500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
00020000164311d430224250000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000300000e64508625000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000400002062424630216250000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
00020000282352d225000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000300001a6251c6151a6251c61500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0005000024040280402b0403004500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000200001c63522625000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000500000a665066550c0530000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0007000024540285402b540305502b530305550000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0003000014041200412c0350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
00050000123530c345000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000e000015130001000010015130001000010015130001001813000100001001813000100001001c1300010011130001000010011130001000010011130001001313000100001001313000100001001713000100
000e00001804300000346150000034615000003461500000180430000034615000003461500000346150000018043000003461500000346150000034615000001804300000346150000034615000003461500000
000e00001113000100001001113000100001001113000100131300010000100131300010000100131300010015130001000010015130001000010018130001001713000100001001713000100001001c13000100
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
__music__
01 10114040
02 12114040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
__label__
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
cccc777c777c777c7c7cc777777c777cccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
cccc7c7c7c7c7c7c7c7c777777777c7ccccccccccccccccccccccccccccccccccc550505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
cccc777c777c77cc77c77777777777cccccccccccccccccccccccccccbcccccccc550505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
6c6c7c6c7c7c7c7c7c7777777777777c6c6c6c6c6c6c6c6c6c6c6c6cbbbc6c6c6c550505000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c676c6767676767677777777777776c6c6c6c6c6c6c6c6c6c666c6cbc6c6c6c65505050006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6c6c6c6c6c6c6c67777777777777776c6c6c6c6c6c6c6c6c66666c6c6c6c6c6c555505000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6c6c6c6c6c6c6c777777777777777c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c65555050006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6caaac6c6cac6caaa7a7a7aaa7a7776aac6c6c6aacaaac6c66aaacac6c6aacaca55505000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6a6a6c6c6a6c6a777a7a7a777a777a6c6c6c6a6a6a6c6c6c6a6c6a6c6a6a6a6a555050006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6caaac6c6cac6caa77a7a7aa77a777aaac6c6cacacaa6c6c66aa6cac6cacacaca55505000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6a6a6c6c6a6c6a677aaa7a777a776c6a6c6c6a6a6a6c6c6c6a6c6a6c6a6a6aaa550050006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6caaac6c6caaacaaa77a77aaa7aaacaa6c6c6caa6cac6c6c66a66caaacaa6caaa55005000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6c6c6c6c6c6c6c6c77777777777c6c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c655500500c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6c6c6c6c6c6c6c6c6c777777777c6c6c6c6c6c6c6c6c6c6c66666c6c6c6c6c6c555005006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6c6c6c6c6c6c6c6c6c6777776c6c6c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c655500500c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c66666c6c6c6c6c6c555005006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
6666c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c655500500c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6666666666666
66666c6c6c6c6c6c6666666666666c6c6c6c6c6c6c6c6c6c6c66666c6c6c6c6c6c555005006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c666666666666
6666c6c6c6c6c6c666666666666666c6c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c655500500c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6666666666666
66666666666666666666666666666666666666666666666666666666666666666655500500666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666655500500666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666655505500666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666655505500666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666655505500666666666666666666666666666666666666666666666666666666
6666666666666666666666666666666666666666666666666660a906666666666655505500666666666666666666666666666666666666666666666666666666
6666666666666666666666666666666666666666666666666660a906666666666655505500666666666666666666666666666666666666666666666666666666
6666666666666666666666666666666666666666666666666660a9006666666666555055006666666666666dddddddd666666666666666666666666666666666
6666666666666666666666666666666666666666666666666660a9009666666666555055006666666666666dddddddd66666666666666666dddddddd66666666
6666666666666666666666666666666666666666666666666660a9009966666666555055006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660a9009966666666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660a9009906666666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660a9009900666666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660aa009900666666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660aa009900966666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660aa009900966666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666646464646464646464646460aa009900946464555050006464646464666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666664646464646464646464640aa009900964646555050004646464646466dddddddd66666666666666666dddddddd66666666
6666666666666666666666666666646464646464646464646460aa00990094646455505004646464646466666666666666666666666666666666666666666666
6666666666666666666666666666664646464646464646464640aa00990096464655505006464646464646666666666666666666666666666666666666666666
6666666666666666666666666666666464646464646464646460aa00990094646455505004646464646466666666666666666666666666666666666666666666
4444444444444444444444444444444646464646464646464640aa00990096464655505006464646464644444444444444444444444444444444444444444444
4444444444444444444444444444446464646464646464646464aa00990094646455505004646464646464444444444444444444444444444444444444444444
4444444444444444444444444444444646464646464646464646aa00990096464655505006464646464644444444444444444444444444444444444444444444
4444444444444444444444444444446464646464646464636363aa00990094646455505004646464646444444444444444444444444444444444444444444444
4444444444444444444444444444444646464646464646463636aa00990096464655505006464646464644444444444444444444444444444444444444444444
4444444444444444444444444666666666666666666666666666aa00990096666655505006666666666666644444444444444444444444444444444444444444
444444444444444444444446d6d6d6d6d6d6d6d6d6d6d6d6d6d6aa0099009444445550500449d6d6d6d6d6d6d444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990044444455505004449944466666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990044444445505004444994466666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990044444445505004444499466666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990444444444505004444444996666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990444444444505004444444499666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00994444444444505004444444449996666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00994444444444505004444444444999666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00944444400044445004444444464449996444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00944444000004445004444444466444999444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00944444000004455004444444466644499944444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00444444000004455004444444466664449999444444444444444444444444444444444444
44444444444444444444444666666666664444444444444444444444444444f000f4455004444444466666444499944444444444444444444444444444444444
444444444444444444444446666666666644444444444444444444444444444fff44455004444444466666664449999444444444444444444444444444444444
44444444444444444444444666666666664444444444444444444444444444488844455004444444466666666444999944444444444444444444444444444444
44444444444444444444444666666666664444444444444444444444444244888884844444444444466666666444499999444444444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228855588884444444444466666666444444999944444444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228555558884444444444466666666444444499994444444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228555558884444444444466666666444444449999944444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228555558888444444444466666666444444444999994444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228555558484444444444466666666444444444449999944444444444444444444444
4444444444444444444444466666666666444444444444444444444444f248555558444444444444466666666444444444444999994444444444444444444444
44444444444444444444444666666666664444444444444444444444444448855588444444444444466666666444444444444499999944444444444444444444
44444444444444444444444666666666664444444444444444444444444440111111444444444444466666666444444444444449999994444444444444444444
44444444444444444444444666666666664444444444444444444444444400111111144444444444466666666444444444444444499999444444444444444444
66666666666666666666666666666666666666666666666666666666666000111111666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666000611111166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666606666611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666000666611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666000666661666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666600066611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666660666611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666600066661666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666600066611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666660666611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666555561666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666665555511166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666555555511166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666665555555711556666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666655555111666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666665555516666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666555566666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
