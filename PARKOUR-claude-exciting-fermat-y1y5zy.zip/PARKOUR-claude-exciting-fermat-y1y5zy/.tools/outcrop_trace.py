import sys,importlib
sys.path.insert(0,'tools');import playtest
playtest.CART='.tools/routes.p8'
m=importlib.import_module('tests.l7');playtest.SCENARIOS['L7:outcrops']=m.SCENARIOS['outcrops'];playtest.run('L7:outcrops',True)
