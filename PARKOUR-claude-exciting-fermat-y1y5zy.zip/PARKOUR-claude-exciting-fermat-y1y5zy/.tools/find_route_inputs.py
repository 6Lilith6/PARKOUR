import sys,importlib,contextlib,io
sys.path.insert(0,'tools');import playtest
playtest.CART='.tools/routes.p8'
for n in (2,3,5,7):
 m=importlib.import_module('tests.l'+str(n)); playtest.SCENARIOS.update({'L%d:%s'%(n,k):v for k,v in m.SCENARIOS.items()})
for key in ('L2:pallet_f1','L7:outcrops'):
 start,old,check=playtest.SCENARIOS[key]
 found=False
 for lead in (0,10,20,30):
  for hold in (1,10,25,45):
   for gap in (20,35,50,65,80):
    steps=[(lead,'up')]+[(hold,'up+z'),(gap,'up')]*12
    playtest.SCENARIOS[key]=(start,steps,check)
    with contextlib.redirect_stdout(io.StringIO()) as buf: ok=playtest.run(key)
    if ok:
     print(key,lead,hold,gap,buf.getvalue(),flush=True);found=True;break
   if found:break
  if found:break
 if not found:print(key,'NO MATCH',flush=True)
for k,steps in {
'L3:long_jump':[(1,'flow=1'),(1,'spd=8.5'),(430,'up+ax+ej')],
'L3:silo_goal':[(30,'up+z'),(10,'up')]*5+[(30,'up')],
'L5:billboard_cable':[(1,'flow=.5'),(340,'up+ax+ej+pj')]
}.items():
 start,_,check=playtest.SCENARIOS[k];playtest.SCENARIOS[k]=(start,steps,check);playtest.run(k,True)
