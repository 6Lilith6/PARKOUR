pico-8 cartridge // http://www.pico-8.com
version 42
__lua__
cart_lv,cart_cp,next_lv,lname,nextcart,hints,dt=0,13,4,"old city rooftops","downtown.p8",split("⬆️ run   ⬅️➡️ steer   🅾️ jump|low barriers: run to vault\nroofs and gaps: press 🅾️|❎ while running: slide|❎ just before landing: roll\nhigh drops without it hurt|jump at a ledge to grab it\n⬆️ climb  ⬅️➡️ shimmy  ❎ drop\n⬇️+🅾️ jump away|ladders and fixed drainpipes\nhold ⬆️ to climb|hold 🅾️ into a wall: run up it\nhold 🅾️ along a wall: wallrun|on a wall press 🅾️: kick off\n(tic-tac / wall jump)|narrow beams: ⬅️➡️ keep balance|red awnings bounce you high|keep moving to build flow\nflow = higher top speed|three ways up: ladder,\nsteps, or run up the wall|wallrun, 🅾️ wall jump, wallrun\nor take the cable / skybridge|clock house: climb, then east\nbridge leads to the courtyard","|"),.01667

function _init()
 cartdata"pk_parkour_3"
 menuitem(1,"restart level",restart)
 menuitem(2,"last checkpoint",respawn)
 menuitem(3,"level select",function() load"parkour_menu.p8" end)

 menuitem(4,"perf overlay",function() dbg=not dbg end)
 mode="play"
 setlv(cart_lv)

 if (dget(8)==lv+1) spd=mid(3,dget(9),9) vx,vz,started=cos(ang)*spd,sin(ang)*spd,true dset(8,0)
end

function restart()
 cpi,tm,score,cp,started=0,0,0,spawn
 worldreset()
 musphase=nil
 scoremusic()
 respawn()
end

function respawn()
 px,py,pz,ang=unpack(cp)
 for k in all(split"vx,vy,vz,spd,flow,chain,idle,bal,balv,heavy,ngrab,jbuf,rbuf,coy,kicks,aph,shake,stun,popt,splt,shy,wrs,lc,lvy,oh") do _ENV[k]=0 end
 peak,pop,fade,bang,crouch,gb,wupd,lastwr,gnd=py,"",12,ang
 setst"ground"
 nearupd()
 camreset()
end

function inp()
 local o,x=jz,xx
 jz,xx,iu,id=btn(4),btn(5),btn(2),btn(3)
 jzp,xp,turn=jz and not o,xx and not x,(btn(0)and 1or 0)-(btn(1)and 1or 0)
end

function _update()
 inp()
 menu()
 step()
 jzp,xp=nil
 step()
end

function menu()
 if mode=="done" do
  if (jzp) load(nextcart)
  if (xp) mode="play" restart()
 end
end

function scoremusic()
 local p=min(cpi*4/(cart_cp+1)\1,3)*8
 if (p~=musphase) musphase=p music(p,400,7)
end

function step()
 if mode=="play" do
  if (btn()>0) started=true
  if (started) tm=min(tm+dt,32760)
  fade,splt,popt=max(fade-1),max(splt-dt),max(popt-dt)
  worldupd()
  pupd()
  trigupd()
 end
 camupd()
end

function trigupd()
 hint=nil
 for b in all(trig) do
  if inside(b,px,pz,0) and py>b[2]-1 and py<b[5] do
   if b.m==11 and b.k>cpi do
    cpi,cp,splt=b.k,{(b[1]+b[4])/2,b[2],(b[3]+b[6])/2,ang},2.5
    scoremusic()
    sfx(6)
   elseif b.m==12 and (b.k==0 or gnd and gnd.ev and gnd.ev[1]<2) do

    mode,best="done",dget(lv)
    newbest=best==0 or tm<best
    if (newbest) dset(lv,tm)
    sfx(9)
    if (dget(10)>0 and lv~=7) dset(8,next_lv+1) dset(9,hs()) load(nextcart)
   elseif b.m==13 do
    hint=b.k+1
   end
  end
 end
end

function ft(f)
 local s=f\1
 return s\60 ..":"..sub("0"..s%60,-2).."."..sub("0"..f%1*100\1,-2)
end

function pr(s,y,c,x)
 x=x or 64-#s*2
 for d=-1,1,2 do ?s,x+d,y,0
?s,x,y+d,0 
end
 ?s,x,y,c
end

function _draw()
 render()

 pr(ft(tm),2,7,2)
 if (dget(lv)>0) pr(ft(dget(lv)),9,5,2)

 if (splt>0) pr("checkpoint "..cpi,20,11)

 rectfill(2,121,2+hs()/9*40,124,flow>.6 and 10 or flow>.3 and 9 or 13)
 rect(1,120,43,125,5)

 if (popt>0) pr(pop,112,7)
 if (hint) rectfill(1,97,126,117,1) ?hints[hint],3,99,7
 if (fade>0) fillp(fade>6 and 0 or 23130) rectfill(0,0,127,127,0) fillp()
 if (mode=="done") rectfill(16,34,111,96,0) rect(16,34,111,96,7) pr(lname,40,10) pr("time  "..ft(tm),52,7) pr(newbest and "new best!" or "best  "..ft(best),60,newbest and 11 or 6) pr("flow score "..score,72,12) pr("🅾️ continue  ❎ retry",86,7)
 if (dbg) ?stat(7).." "..stat(1).." "..#nb,1,9,7
end

mflag=split"1,1,1,1,1,3,1,5,1,1,8,8,8,1,1"

function rd(n)
 ra+=n
 return n>1 and peek2(ra-2) or peek(ra-1)
end

function setlv(l)
 lv,ra=cart_lv,peek2(0)
 for i=0,15 do pal(i,rd(1),1) end
 sk,mats,boxes,trig,dl,movers={},{},{},{},{},{}
 for i=1,11 do sk[i]=rd(1) end
 for i=1,15 do mats[i]={rd(1),rd(1),rd(1),mflag[i],rd(1)} end
 for i=1,rd(2) do
  local x,z,y,w,h,d,m=rd(2)/8,rd(2)/8,rd(2)/8,rd(1)/4,rd(1)/4,rd(1)/4,rd(1)
  local b={x,y,z,x+w,y+h,z+d,m=m%16,k=m\16,f=mflag[m%16]}
  if b.f&8>0 do
   add(trig,b)
   if (b.m==11 and b.k==0) spawn={x+w/2,y,z+d/2,sk[10]/256}
  else
   add(boxes,b) add(dl,b)
   if (b.k>=12) b.o,b.ev=0,{0,b.k==13and 2or b.k==14and 1or 3,b.k==12and 12or b.k==13and 4or 8,6,3} add(movers,b)
  end
 end

 for i=1,rd(1) do
  local b=boxes[rd(2)]
  if (not b.o) add(movers,b)
  b.o,b.ev=0,{rd(1),rd(1),rd(2)/8,rd(1)/4,rd(1)/4,rd(1),rd(1)/4}
 end

 plb={}
 add(dl,plb)
 restart()
end

function worldreset()
 wt=0
 for b in all(movers) do
  local ax=b.ev[2]
  b[ax]-=b.o b[ax+3]-=b.o b.o,b.ev.t,b.warn,b.dim=0,nil
 end
end

function eventoffset(b,ride)
 local e,k=b.ev,b.ev[1]
 if not e.t do
  local touch=inside(b,px+vx*dt,pz+vz*dt,-r-.12) and py<b[5] and py+ph>b[2]
  if (k==2 or k==3) and ride or k==4 and touch and hs()>=4 or k~=2 and k~=3 and k~=4 and inside(b,px,pz,-e[6]) and abs(py-b[5])<e[6]+3 do
   e.t=0
   if (k>1 and k<5) sfx(8)
  else
   return 0
  end
 end
 e.t=min(e.t+dt,32760)
 if ((k==2 or k==6) and inside(b,px,pz,-r)) e.t=min(e.t,e[7])
 b.warn=(k==2 or k==3 or k==6) and e.t<=e[7]
 if (k==7) b.dim=e.t>e[7] and e.t<e[7]+e[4] return 0
 if (k==4) return e[3]
 local t=max(e.t-e[7])
 if (k==1) t%=2*(e[4]+e[5]) t=min(t,2*e[4]+e[5]-t)
 return e[3]*mid(0,t/e[4],1)
end

function worldupd()
 if (not started) return
 wt=(wt+dt)%24
 local phase,moved=mid(0,min(wt-3,21-wt)/6,1),false
 for b in all(movers) do
  local e=b.ev
  local ax,ride,held=e[2],gnd==b and abs(py-b[5])<.1,hb==b and(st=="hang"or st=="pull")
  local offset=e[1]==0 and phase*e[3] or eventoffset(b,ride)
  local d=b.k==14 and dt*1.2 or offset-b.o
  if (b.k~=14) b[ax]+=d b[ax+3]+=d b.o=offset
  if e[1]<2 and (ride or held) do
   local p={px,py,pz}
   p[ax]+=d
   px,py,pz=unpack(p)
   moved=ride and d~=0 or moved
   if (held and st=="pull") pa[ax]+=d pb[ax]+=d
  elseif e[1]<2 and d~=0 and b.k~=14 and phit()==b do

   if (ax==1) px=d>0 and b[4]+r+.01 or b[1]-r-.01
   if (ax==3) pz=d>0 and b[6]+r+.01 or b[3]-r-.01
   moved=d~=0 or moved
  end
 end

 if (moved) nearupd() if (phit()) respawn()
end

r=.3

function inside(b,x,z,m)
 return x>b[1]+m and x<b[4]-m and z>b[3]+m and z<b[6]-m
end

function nearupd()
 nb={}
 for b in all(boxes) do
  if (inside(b,px,pz,-8) and b[2]<py+8 and b[5]>py-8) add(nb,b)
 end
end

function hit(x0,y0,z0,x1,y1,z1)
 for b in all(nb) do
  if (x0<b[4] and x1>b[1] and y0<b[5] and y1>b[2] and z0<b[6] and z1>b[3]) return b
 end
end

function phit(y)
 y=y or py
 return hit(px-r,y,pz-r,px+r,y+ph,pz+r)
end

function solid(x,y,z)
 return hit(x-.05,y-.05,z-.05,x+.05,y+.05,z+.05)
end

function stepup(b)
 if (st~="air" and st~="wallrun" and b[5]-py<.55 and not phit(b[5]+.01)) py=b[5]+.01 return true
end

function pmove()
 wall,gnd=nil
 local ox,oz=px,pz
 px+=vx*dt
 local b=phit()
 if (b and vx~=0 and not stepup(b)) wnx,wnz=ox<(b[1]+b[4])/2 and -1 or 1,0 px,wall=wnx<0 and b[1]-r-.001 or b[4]+r+.001,b
 pz+=vz*dt
 b=phit()
 if (b and vz~=0 and not stepup(b)) wnx,wnz=0,oz<(b[3]+b[6])/2 and -1 or 1 pz,wall=wnz<0 and b[3]-r-.001 or b[6]+r+.001,b
 py+=vy*dt
 b=phit()
 if b and vy~=0 do
  if vy<0 do
   py,gnd=b[5],b

   for o in all(nb) do
    if (inside(o,px,pz,-r) and o[5]==py and not narrow(o)) gnd=o
   end
  else
   py=b[2]-ph
  end
  vy=0
 end
end

function hs()
 return sqrt(vx*vx+vz*vz)
end

function narrow(b)
 return b and min(b[4]-b[1],b[6]-b[3])<.7
end

function canvault(b)
 if (st~="ground" or not gnd or not iu or xx or jbuf>0 or narrow(gnd) or b.k~=4) return
 local h,dx,dz=b[5]-py,cos(ang),sin(ang)
 if (h<=.55 or h>1.35 or abs(b[2]-py)>.15 or -dx*wnx-dz*wnz<.65) return
 local ix=wnx~=0 and 1 or 3
 if (b[ix+3]-b[ix]>1.6 or b[7-ix]-b[4-ix]<.9) return
 local v=ix==1 and dx or dz
 local d=(b[v>0 and ix+3 or ix]-(ix==1 and px or pz)+(r+.15)*sgn(v))/v
 local x,z=px+dx*d,pz+dz*d
 local floor=solid(x,py-.1,z)
 return floor and abs(floor[5]-py)<.35 and inside(floor,x,z,.35) and not hit(min(px,x)-r,b[5]+.02,min(pz,z)-r,max(px,x)+r,b[5]+1.8,max(pz,z)+r) and not hit(x-r,floor[5]+.02,z-r,x+r,b[5],z+r)
end

function findledge(lo,hi)
 local x,z=px+cos(ang)*.6,pz+sin(ang)*.6
 for b in all(nb) do
  local t=b[5]-py
  if (t>lo and t<hi and inside(b,x,z,0) and not hit(x-.2,b[5]+.05,z-.2,x+.2,b[5]+1,z+.2)) return b
 end
end

function snapface(b,zf,keep)
 if (zf==nil) zf=max(b[1]-px,px-b[4])<=max(b[3]-pz,pz-b[6])
 if (not zf) wnx,wnz=px<b[1] and -1 or 1,0 px=wnx<0 and b[1]-r or b[4]+r else wnx,wnz=0,pz<b[3] and -1 or 1 pz=wnz<0 and b[3]-r or b[6]+r
 if (not keep) ang,vx,vy,vz=atan2(-wnx,-wnz),0,0,0
end

function trick(n,f,s)
 pop,popt,idle=n,1,0
 chain+=1
 score,flow=min(score+5*min(chain,20),32000),mid(0,flow+f,1)
 if (s) sfx(s)
end

function brk(n,s)
 pop,popt,chain,idle=n,1,0,0
 flow*=.4
 if (s) sfx(s)
end

function toair(j)
 peak,airjump,gnd=py,j
 setst"air"
end

function dojump()
 local h,jv=spd,6.2
 if (spd<2.5) h=iu and 3.6 or 0 else jv=6+spd*.2 if (not solid(px+cos(ang)*.8,py-.3,pz+sin(ang)*.8)) h*=1.08 trick("edge jump",.06)
 if (narrow(gb)) jv-=.6
 if (st=="slide" or st=="roll") jv-=.5 trick(st.." jump",.05)
 vx,vy,vz,jbuf=cos(ang)*h,jv,sin(ang)*h,0
 toair(true)
 sfx(1)
end

function startvault(b)
 vtop,vy0,vt=b[5],py,spd<3.6 and 1 or spd<6.3 and 2 or 3

 if (vtop-py>1.15) vt=min(vt,2)
 vdur,vspd=({.38,.2,.12})[vt],({min(spd,2.2),spd*.92,spd*1.04})[vt]
 trick(({"climb over","vault","speed vault"})[vt],vt*.05-.05,7)
 setst"vault"
end

function airgrab()
 if (ngrab>0 or xx or not wall or vy>0) return
 local b=findledge(.65,2.15)
 if b and abs(b[5]-wall[5])<.1 and min(b[4]-b[1],b[6]-b[3])>1.2 do
  if (b[5]-py<1.3 and not airjump) return
  hb,hcat=b,hs()>3
  snapface(b)
  if (b[5]-py<1.3) startpull() trick("mantle",.05,4) return true
  py=b[5]-(hcat and 1.5 or 2.05)
  setst"hang"
  trick(hcat and "cat leap" or "ledge grab",hcat and .1 or 0,4)
  return true
 end
end

function startpull()
 pa,pb,pdur={px,py,pz},{px+cos(ang)*.7,hb[5]+.01,pz+sin(ang)*.7},hcat and.3or.5
 setst"pull"
end

function wallkick(vp,out,n)
 vx,vy,vz,jbuf=-wnz*vp+wnx*out,max(vy,6.6-kicks*1.3),wnx*vp+wnz*out,0
 kicks+=1
 ang=atan2(vx,vz)
 toair(true)
 trick(n,.1,4)
end

function jumpback()
 ang+=.5
 vx,vy,vz,ngrab=cos(ang)*4.5,6.5,sin(ang)*4.5,.25
 toair(true)
 trick("wall jump",.05,4)
end

function bonk()
 vx,vz,spd,shake=0,0,0,.15
 brk("ouch",11)
end

g,s=20,{}

function setst(n)
 st,stt,ph=n,0,1.8
end

function pupd()
 nearupd()
 stt+=dt
 jbuf,rbuf,ngrab=max(jbuf-dt),max(rbuf-dt),max(ngrab-dt)
 if (jzp) jbuf=.12
 if (xp) rbuf=.3
 s[st]()

 if (py<1) sfx(11) respawn()

 shy=-1
 for b in all(nb) do
  if (inside(b,px,pz,0) and b[5]<=py+.05) shy=max(shy,b[5])
 end
 anim()
end

function gvel()
 vx,vy,vz=cos(ang)*spd,-3,sin(ang)*spd
 pmove()
end

s.ground=function()
 local nar,vmax=narrow(gb),6.2+flow*2.8
 if nar do
  vmax=4
  if (balance()) return
 else
  ang+=turn*(.6-min(spd,9)*.04)*dt
 end
 if (heavy>0) heavy-=dt vmax=2.5

 ph=1.8
 crouch=xx and spd<3.5 or phit()
 if (crouch) ph,vmax=1,1.6
 if (iu) spd+=(spd<5 and 9 or 2.2)*dt else spd-=(id and 16 or spd>3 and 4 or 9)*dt
 spd=max(min(spd,max(vmax,spd-6*dt)))

 if (spd>5.8) flow=min(flow+.04*dt,1)
 if (spd<3) flow=max(flow-.5*dt)
 if (spd<1.5) idle+=dt if (idle>1.2) chain=0
 if (jbuf>0 and not crouch) dojump() return
 if (xp and spd>=3.5 and not nar) spd*=1.05 trick("slide",0,3) setst"slide" return
 gvel()
 if (not gnd) coy,vy=.1,0 toair() return
 gb=gnd
 local f=flr(aph*2)
 if (f~=lstep and spd>.5) sfx(0)
 lstep=f
 if wall do
  local into=-cos(ang)*wnx-sin(ang)*wnz
  if wall.f&2>0 and iu and into>.5 do
   startclimb()
  elseif spd>1 and canvault(wall) do
   startvault(wall)
  elseif into>.6 and jz and spd>3 do
   wallup(spd*into)
  elseif into>.7 do
   if (spd>5.5) bonk() stun=.3 setst"land"
   spd=0
  elseif into>0 do

   local tx,tz=-wnz,wnx
   if (cos(ang)*tx+sin(ang)*tz<0) tx,tz=-tx,-tz
   ang=atan2(tx,tz)
   spd*=1-into*.5
  end
 end
end

function balance()
 ang+=angd((gb[4]-gb[1]>gb[6]-gb[3] and (cos(ang)>0 and 0 or .5) or (sin(ang)>0 and .75 or .25))-ang)*.15
 balv=balv*.97+((rnd(2)-1)*(1+spd*.8)+bal*2.5-turn*5)*dt
 bal+=balv*dt

 local lx,lz=-sin(ang)*bal,cos(ang)*bal
 px+=lx*.4*dt
 pz+=lz*.4*dt
 if (abs(bal)>1) vx,vy,vz,bal,balv=lx*2,1,lz*2,0,0 brk("slipped",11) toair() return true
end

s.air=function()
 coy-=dt
 if (jbuf>0 and coy>0) dojump() return
 vy=max(vy-g*dt,-30)

 local da=turn*.2*dt
 local c,sn=cos(da),sin(da)
 ang+=da
 vx,vz=vx*c-vz*sn,vx*sn+vz*c
 if (iu and hs()<3.6) vx+=cos(ang)*5*dt vz+=sin(ang)*5*dt
 if (id) vx*=.97 vz*=.97
 pmove()
 peak=max(peak,py)
 if (gnd) land() return
 if (airgrab()) return

 if not wall and jz and hs()>3.2 do

  for sd in all(split"0,.4,-.4,.8,-.8") do
   local b=solid(px-sin(ang)*sd,py+1,pz+cos(ang)*sd)
   if (b and not wall and b~=lastwr and max(b[4]-b[1],b[6]-b[3])>2) wall=b snapface(b,px>b[1] and px<b[4],1)
  end
 end
 if (not wall) return
 local vin,vp=max(-vx*wnx-vz*wnz),vz*wnx-vx*wnz
 if wall.f&2>0 and iu and vin>.5 do

  startclimb()
 elseif jbuf>0 do

  wallkick(vp,max(3.2,vin*.5),"tic-tac")
 elseif jz and abs(vp)>3.2 and abs(vp)>vin*.7 and wall~=lastwr do

  wrs,lastwr=max(abs(vp),hs()*.85),wall
  wrt=.5+wrs*.12
  wrmax,vy,ang=wrt,mid(vy,1+wrs*.25,3.5),atan2(-wnz*vp,wnx*vp)
  trick("wallrun",.1,5)
  setst"wallrun"
 elseif jz and vin>2 and not wupd do
  wallup(vin)
 else
  if (vin>6.5) bonk()
  vx+=wnx*vin vz+=wnz*vin
 end
end

function land()
 local h,hv=peak-py,hs()
 if (hv>.5) ang=atan2(vx,vz)
 spd,gb,coy,wupd,kicks,lastwr=hv,gnd,0,false,0

 if (gb.f&4>0) toair(true) vy=jz and 12.5 or 11 trick("bounce",.1,10) return
 sfx(2)
 if narrow(gb) do
  spd,bal,balv=min(spd,2.5),0,0
  if (h>.6) trick("precision",.08)
  setst"ground"
  return
 end
 if h>1.6 and rbuf>0 do
  if (h<11) spd=max(spd*.95,4) trick("roll",.12,3) setst"roll" return

  h-=4
 end
 if h>4.6 do
  spd*=.15
  stun,shake,heavy,flow=.6,.3,.6,0
  brk("hard landing",8)
  setst"land"
 elseif h>2.6 do
  spd*=.6
  stun,flow=.15,max(flow-.25)
  setst"land"
 else
  spd*=.97
  setst"ground"
 end
end

s.land,s.roll,s.slide,s.vault,s.wallrun=function()
 spd=max(spd-10*dt)
 gvel()
 ph=1.2
 if (stt>stun) setst"ground"
end,function()spd=max(spd-2*dt)ang+=turn*.25*dt gvel()ph=.9if(not gnd)toair()return
if(jbuf>0and stt>.2and not phit(py+.9))dojump()return
if(stt>.45)setst"ground"
end,function()spd=max(spd-1.6*dt)ang+=turn*.15*dt ph=.8gvel()if(not gnd)toair()return
if(jbuf>0and not phit(py+1))dojump()return
if(wall)spd*=.5
if(not xx and stt>.35or spd<2.5)ph=1.8if(phit())ph,spd=.8,max(spd,2.5)else setst"ground"
end,function()local k=min(stt/vdur,1)py,vx,vy,vz=vy0+(vtop+.05-vy0)*k,cos(ang)*vspd*.3,0,sin(ang)*vspd*.3pmove()if(k>=1)spd=vspd vx,vy,vz=cos(ang)*spd,vt==3and 2.5or 1.5,sin(ang)*spd toair()
end,function()wrt-=dt vy-=g*(.05+(1-wrt/wrmax)*.55)*dt wrs=max(wrs-dt)vx,vz=cos(ang)*wrs-wnx,sin(ang)*wrs-wnz pmove()if(gnd)land()return
if(airgrab())return
if jbuf>0do wallkick((vz*wnx-vx*wnz)*.9,4.8,"wall jump")elseif not wall or wrt<=0or xp do vx+=wnx vz+=wnz setst"air"end peak=py end

function wallup(vin)
 wupd=true
 snapface(wall)
 vy=max(vy,4+vin*.7)
 trick("wall climb",.05)
 setst"wallup"
end

s.wallup,s.hang,s.pull=function()
 vx,vy,vz=-wnx*.5,vy-g*dt,-wnz*.5
 pmove()
 peak=max(peak,py)
 if (gnd) land() return
 if (airgrab()) return
 if jbuf>0 do
  wallkick(0,4.5,"wall jump")
 elseif vy<-1.5 or not wall do
  setst"air"
 end
end,function()if(stt<.12)return
if iu and airjump or jbuf>0and not id do startpull()elseif jbuf>0do jumpback()elseif xp do ngrab=.35toair()elseif turn~=0do local ox,oz,b=px,pz,hb px+=sin(ang)*turn*1.4*dt pz-=cos(ang)*turn*1.4*dt local x,z=px+cos(ang)*.6,pz+sin(ang)*.6if(not inside(b,x,z,.1)or phit())px,pz=ox,oz
aph+=dt*1.5end end,function()local k=min(stt/pdur,1)local a=lerp3(pa,pb,max(k*2-1))px,py,pz=a[1],lerp3(pa,pb,min(k*1.6,1))[2],a[3]if(k>=1)spd,gb=hcat and iu and 4or 1setst"ground"
end

function startclimb()
 cb=wall
 local zf=cb[4]-cb[1]>cb[6]-cb[3]
 snapface(cb,zf)
 if (zf) px=mid(cb[1],px,cb[4]) else pz=mid(cb[3],pz,cb[6])
 setst"climb"
 sfx(4)
end

s.climb,q,poses=function()
 local d=(iu and 1 or 0)-(id and 1 or 0)
 py+=d*2.6*dt
 aph+=d*dt*1.2
 if (py+1.9>cb[5]) py=cb[5]-1.9 if (d>0) hb,hcat=cb startpull() return
 if (d<0 and solid(px,py-.05,pz)) setst"ground" spd=0 return
 if jbuf>0 do
  jumpback()
 elseif xp or py<cb[2]-1.5 do
  ngrab=.35
  toair()
 end
end,split"0,0,.93,0,.07,0,.07,0,.1,0,.1,0,0,0",{}
for row in all(split("push;.06,0,.95,-.3,.12,.2,.4,.15,.15,-.1,.15,.04,0|up;.04,0,.95,-.1,.3,.15,.35,.12,.2,.05,.2,.08,0|fall;.02,0,.95,0,.18,.1,.12,.15,.15,.12,.15,.15,0|reach;.04,0,.93,.14,.08,.02,.12,.12,.12,.08,.12,.12,0|slide;-.1,.03,.45,.75,.07,-.05,.07,-.12,.05,.15,.2,.1,0|roll;.15,0,.6,.15,.4,.1,.35,.3,.3,.3,.3,0,0|land;.14,0,.56,.18,.07,-.12,.07,.12,.15,.08,.15,.06,0|v1;.15,0,1,.15,.45,.05,.5,.1,.08,.12,.08,0,0|v2;.1,.08,1,.25,.4,.15,.45,.06,.04,.08,.04,.08,.12|v3;.08,.12,1,.3,.45,.2,.5,.06,.02,.15,.12,.12,.2|cat;0,0,.95,.25,.45,.25,.4,.46,.03,.46,.03,0,0|hang;0,0,.95,.04,.1,-.03,.12,.46,.03,.46,.03,0,0|wallup;.02,0,.95,.3,.4,.24,.15,.38,.12,.42,.12,.05,0|climb;0,0,.95,.2,.3,.2,.3,.42,.1,.42,.1,0,0|pull;0,0,.95,.04,.1,0,.12,.46,.2,.46,.2,0,0","|")) do
 local p=split(row,";",false)
 poses[p[1]]=p[2]
end

function gait(t,h)
 local f=1.1+h*.13

 rt=.75
 aph+=f*dt
 local d=min(.6,.5*f/h)
 local s=h*d/f

 t[3]=sqrt(.757-s*s/4)+.07-(.5-d)*.06*cos(aph*2-d)
 for i=0,1 do
  local p,x,u=(aph+i/2)%1,0,.07
  if (p<d) x=s/2-s*p/d else p=(p-d)/(1-d) x,u=sin(p)*.15-cos(p/2)*s/2,.07-sin(p/2)*(1.3-p)*(.08+h*.025)

  local j=4+i*2
  t[j],t[j+1],t[j+4],t[j+5]=x,u,.03-x*.22,.14+h*.008
 end
 t[1]=.01+h*.004
end

function anim()
 rt=.3

 local h,n,tu=hs(),st=="air" and (vy>0 and (stt<.12 and "push" or "up") or py-shy<1.2 and "reach" or "fall") or st=="vault" and "v"..vt or st=="hang" and hcat and "cat" or st,angd(ang-bang)
 local t=split(poses[n] or "0,0,.93,.04,.07,-.04,.07,.03,.08,.03,.08,.03,0")
 add(t,0)

 bang+=tu*.25
 if st=="ground" do
  if (h>.3) gait(t,h) t[1]+=mid(-.04,(h-oh)*.25,.03) else t[3]+=sin(time()/4)*.004
  if (crouch) t[3]-=.3 t[1]+=.1

  if (lvy<-4) lc=(-lvy-4)*.03
  t[3]-=lc
  if (narrow(gb)) t[8],t[10],t[12],tu=0,0,.25,bal*-.06
 elseif st=="wallrun" do
  gait(t,wrs)

  local w=wnx*sin(bang)-wnz*cos(bang)
  t[2],t[12],t[13]=w*.04,.14,w*.2
 elseif st=="climb" do
  local w=sin(aph)*.12
  t[5]+=w t[7]-=w t[8]-=w/3 t[10]+=w/3
 elseif st=="pull" do

  local k=stt/pdur
  t[1],t[8],t[10]=k*.15,.46-k*.42,.46-k*.42
  if (k>.35) t[6],t[7]=.3,min(hb[5]-py,.5)+.07
 end
 lvy,oh,lc=st=="air" and vy or 0,h,lc*.85

 t[2]-=tu*(h+3)*.12
 if (n=="roll") t[14]=min(stt/.45,1)
 for i=1,13 do q[i]+=(t[i]-q[i])*rt end
 q[14]=t[14]
end

function jp(p)
 local f,u,s=unpack(p)
 local ur=u-q[3]
 f,u=f*pcr+ur*psr,ur*pcr-f*psr+q[3]
 local c={tocam(px+bfx*f-bfz*s,py+u,pz+bfz*f+bfx*s)}
 if (c[3]>near) local p=proj(c) p[3]=c[3] return p
end

function seg(o,a,l,sp,sd)
 return {o[1]-sin(a)*cos(sp)*l,o[2]-cos(a)*cos(sp)*l,o[3]-sin(sp)*sd*l}
end

function spn(t,f,s)
 return {sdf*t+lcf*f,q[3]+sdu*t+lsf*f,sds*t+s+sh}
end

function cap(a,b,r,c)
 if (a and b) add(bp,{(a[3]+b[3])/2,a,b,r,c})
end

function drawplayer()
 local l,sl,hp=q[1],q[2],q[3]
 bfx,bfz,pcr,psr,bp,sdf,sdu,sds,lcf,lsf,sh=cos(bang),sin(bang),cos(q[14]),-sin(q[14]),{},-sin(l),cos(l)*cos(sl),-sin(sl),cos(l),sin(l),(q[5]-q[7])*.06

 if (shy>0) local sc={} for i=0,3 do add(sc,{tocam(px+cos(i/4)*.35,shy+.02,pz+sin(i/4)*.35)}) end cpoly(sc,5)
 local head=jp(spn(.76,0,0))
 if (not head) return

 local cs,lg=(cpos[1]-px)*-bfz+(cpos[3]-pz)*bfx>0 and 1 or -1,{}
 for sd=-1,1,2 do
  local i,nr,h,az=sd<0 and 4 or 6,sd==cs,(q[6]-q[4])*sd*.05,sd*.12+q[13]
  local f,u=q[i]-h,q[i+1]-hp
  local d=max(sqrt(f*f+u*u),.05)
  local x=(.0176+d*d)/2/d
  local y=sqrt(max(.2025-x*x))
  local k,an={h+(x*f-y*u)/d,hp+(x*u+y*f)/d,sd*.15+az/2+sh/2},{h+f,hp+u,az}

  add(lg,{jp{h,hp,sd*.17+sh},jp(k),jp(an),jp{an[1]-(an[2]-k[2])*.46,max(an[2]+(an[1]-k[1])*.46,.02),az},nr})

  local so=spn(.47,0,sd*.24)
  local el=seg(so,q[i+4],.28,q[12],sd)
  local je=jp(el)
  cap(jp(so),je,.065,nr and 8 or 2)
  cap(je,jp(seg(el,q[i+4]+q[i+5],.26,q[12],sd)),.055,15)
 end

 local a,b=lg[1],lg[2]
 if a[1] and b[1] do
  local sg=sgn(b[1][1]-a[1][1])
  for i=1,4 do
   local p,o=a[i],b[i]
   if (p and o) local m=max(.22*fl/p[3]+2-abs(o[1]-p[1]))/2*sg p[1]-=m o[1]+=m
  end
 end
 for g in all(lg) do
  local c=g[5] and 1 or 0
  cap(g[1],g[2],.1,c)
  cap(g[2],g[3],.08,c)
  cap(g[3],g[4],.06,7)
 end

 for p in all{split"0,.04,.15,1,0",split".18,.42,.19,8,0",split".22,.36,.12,5,-.12",split".5,.76,.05,15,0"} do
  cap(jp(spn(p[1],p[5],0)),jp(spn(p[2],p[5],0)),p[3],p[4])
 end

 cap(head,head,.15,15)
 local hb=jp(spn(.78,-.05,0))
 cap(hb,hb,.14,0)

 isort(bp,1)
 for p in all(bp) do
  local a,b,r,c=unpack(p,2)

  local ra,rb=r*fl/a[3],r*fl/b[3]
  for t=0,1,.2 do
   circfill(a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t,ra+(rb-ra)*t,c)
  end
 end
end

function angd(a)
 return (a+.5)%1-.5
end

function camreset()
 cyaw,fl,cam,look=ang,70,{px-cos(ang)*4,py+3,pz-sin(ang)*4},{px,py+1,pz}
 camupd()
end

function camupd()
 local h=hs()
 cyaw+=angd(ang-cyaw)*(st=="hang" and .03 or .05+h*.005)
 local d,fx,fz=2.8+h*.14,cos(cyaw),sin(cyaw)

 local t,w,lk={px,py+1.4,pz},{px-fx*d,py+2.8+h*.04,pz-fz*d},{px+cos(ang)*(1+h*.4),py+.9,pz+sin(ang)*(1+h*.4)}
 if (st=="wallrun") w[1]+=wnx*.9 w[3]+=wnz*.9

 for k=.15,1,.15 do
  if (solid(unpack(lerp3(t,w,k)))) w=k<.55 and {px-fx*.3,py+3,pz-fz*.3} or lerp3(t,w,k-.15) break
 end
 cam,look=lerp3(cam,w,.18),lerp3(look,lk,.2)
 fl+=(72-h*1.7-fl)*.1
 shake=max(shake-dt)
 cpos={cam[1]+rnd(shake)-shake/2,cam[2]+rnd(shake),cam[3]}
 local lx,ly,lz=look[1]-cpos[1],look[2]-cpos[2],look[3]-cpos[3]
 local yaw,pit=atan2(lx,lz),atan2(sqrt(lx*lx+lz*lz),ly)
 ccy,csy,ccp,csp=cos(yaw),sin(yaw),cos(pit),sin(pit)
 cfw={ccy*ccp,csp,csy*ccp}
end

function tocam(x,y,z)
 x-=cpos[1] y-=cpos[2] z-=cpos[3]
 local f=x*ccy+z*csy
 return z*ccy-x*csy,y*ccp-f*csp,f*ccp+y*csp
end

function proj(c)
 local z=c[3]
 c.s=c.s or {64+c[1]*fl/z,64-c[2]*fl/z}
 return c.s
end

near,fr=.2,0

function poly(v,c)
 local l,rr,y0,y1={},{},999,-1
 for i=1,#v do
  local a,b,t=v[i],v[i%#v+1],l
  local ax,ay,bx,by=a[1],a[2],b[1],b[2]
  if (ay>by) ax,ay,bx,by,t=bx,by,ax,ay,rr
  local sl,ya,yb=(bx-ax)/(by-ay),max(ceil(ay)),min(ceil(by)-1,127)
  local x=ax+(ya-ay)*sl
  for y=ya,yb do
   t[y]=x
   x+=sl
  end
  y0,y1=min(y0,ya),max(y1,yb)
 end
 for y=y0,y1 do rectfill(l[y] or 0,y,rr[y] or 0,y,c) end
end

function cpoly(vs,c)
 local o,n={},#vs
 for i=1,n do
  local a,b=vs[i],vs[i%n+1]
  if (a[3]>=near) add(o,proj(a))
  if (a[3]<near~=(b[3]<near)) local t=(near-a[3])/(b[3]-a[3]) local c=lerp3(a,b,t) c[3]=near add(o,proj(c))
 end
 if (#o>2) poly(o,c)
end

function isort(t,k)
 for i=2,#t do
  local p,j=t[i],i-1
  while (j>0 and t[j][k]<p[k]) t[j+1]=t[j] j-=1
  t[j+1]=p
 end
end

function lerp3(a,b,t)
 local v={}
 for i=1,3 do v[i]=a[i]+(b[i]-a[i])*t end
 return v
end

function fp(q,u,t)
 return lerp3(lerp3(q[1],q[4],u),lerp3(q[2],q[3],u),t)
end

function fq(q,u,t,v,w)
 return {fp(q,u,t),fp(q,u,w),fp(q,v,w),fp(q,v,t)}
end

faces,ci,cj,ck,fpat,dpat={split"1,3,7,5",split"1,2,6,5",split"1,3,4,2"},split"1,4,1,4,1,4,1,4",split"2,2,5,5,2,2,5,5",split"3,3,3,3,6,6,6,6",split"0x3333,0x5555,0x7777,0x5a5a",split"0,0xf0f0,0,0x3333,0,0,0,0xa5a5"

function behind(a,b)
 local r
 for i=1,3 do
  local c,s=cpos[i]
  if a[i+3]<=b[i] do
   s=c>=b[i] and 1 or c<=a[i+3] and 0 or 2
  elseif b[i+3]<=a[i] do
   s=c<=b[i+3] and 1 or c>=a[i] and 0 or 2
  end
  if s do
   if (s==2 or r and r~=s) r=2 break
   r=s
  end
 end
 return r==1 or not r and a.d>b.d
end

function render()
 sky()

 plb={px-r,py,pz-r,px+r,py+ph,pz+r}
 dl[#dl]=plb

 local v={}
 for k=1,#dl do
  local b,d,e,f=dl[k],0,0,0
  for i=1,3 do
   local c,m=cpos[i],(b[i]+b[i+3])/2
   d+=abs(m-c)
   e+=max(max(b[i]-c,c-b[i+3]))
   f+=(m-c)*cfw[i]+abs((b[i+3]-b[i])*cfw[i])/2
  end
  b.d,b.e=d,e
  if e<sk[8]+24 and f>near do
   local x0,y0,x1,y1,cs=999,999,-999,-999,{}
   for i=1,8 do
    local c={tocam(b[ci[i]],b[cj[i]],b[ck[i]])}
    cs[i]=c
    if (c[3]<near) x0,y0,x1,y1=-999,-999,999,999 else local s=proj(c) x0,y0,x1,y1=min(x0,s[1]),min(y0,s[2]),max(x1,s[1]),max(y1,s[2])
   end
   b.cs,b.bx=cs,{x0,y0,x1,y1}

   if (x1>=0 and x0<128 and y1>=0 and y0<128) if e<sk[8]+10 do add(v,b) elseif x0>-999 do rectfill(x0,y0,x1,y1,sk[7]) end
  end
 end

 isort(v,"d")
 fr+=1
 local function visit(b)
  if b.mk~=fr do
   b.mk=fr
   local x0,y0,x1,y1=unpack(b.bx)
   for i=1,#v do
    local a=v[i]
    local p=a.bx
    if (a.mk~=fr and p[1]<x1 and p[3]>x0 and p[2]<y1 and p[4]>y0 and behind(a,b)) visit(a)
   end
   if (b==plb) drawplayer() else drawbox(b)
  end
 end
 for b in all(v) do visit(b) end
end

function drawbox(b)
 local m,cs,fog=mats[b.m],b.cs,b.e>sk[8]
 for ax=1,3 do
  local sd=cpos[ax]>b[ax+3] and 1 or 0
   if cpos[ax]<b[ax] or sd==1 do
    local q={}
    for k in all(faces[ax]) do add(q,cs[k+sd*(ax==3 and 4 or ax)]) end
    local c=ax==2 and sd==1 and m[1] or m[ax==1 and 2 or 3]
    if (fog) fillp(23130) c+=sk[7]*16
    cpoly(q,c)
    fillp()
    if (b.warn) cpoly(fq(q,.47,0,.53,1),0)

    if (ax~=2 and not fog and stat(1)<.9) deco(b,m[5],q,c)
   end
 end
end

function deco(b,dk,q,c)
 if (b.dim and b.m==7) return
 local h,t,k=b[5]-b[2],dk%16,dk\16
 if t==1 and h>3 do
  fillp(fpat[flr(b[1]+b[3])%3+1])
  for y=1.4,h-1.2,3 do
   cpoly(fq(q,.06,y/h,.94,(y+1.3)/h),c+k*16)
  end
 elseif t==3 and h>1.5 do
  fillp(fpat[b.k%4+1])
  cpoly(fq(q,.08,.15,.92,.85),split"0xa9,0x7c,0xeb,0xb3"[b.k%4+1])
 elseif t==5 do
  fillp(3855)
  cpoly(fq(q,.2,.25,.8,.75),c+k*16)
 elseif t==7 do
  for i=1,2 do
   local a,e=q[i],q[i+2]
   if (a[3]<near or e[3]<near) return
   a,e=proj(a),proj(e)
   line(a[1],a[2],e[1],e[2],k)
  end
 elseif t>0 do
  fillp(dpat[t])
  cpoly(q,c+k*16)
 end
 fillp()
end

function sky()
 local hy=mid(-20,64+fl*csp/ccp,150)
 cls(sk[1])
 fillp(23130)
 rectfill(0,hy-34,127,hy-18,sk[1]+sk[2]*16)
 fillp()
 rectfill(0,hy-18,127,hy,sk[2])
 if (sk[6]>0) circfill(64-angd(.1-atan2(ccy,csy))*fl*6,hy-30,7,sk[6])

 rectfill(0,hy,127,127,sk[5])
end
__gfx__
01000000000000000000000000000000001020384850687080f878b8c8d8e8f0c090d04050a0d0a1000c8060402011d0e0401060d050555000000060d0500060
50502050e020308020204740402000c0101000000000000000000000000000d050101a00402084de0000000000000005838810840080000700808080b0800040
00070084c061d080000300070084c081d18100840007006040403444008400070060404034070084000700604040340000080007000530205480000900070084
c001d200004b0087000510105002004b00070010401050e7004b0007001040105087000d0007001080109087006e00070010801090e8000d00070010801090e8
006e000700108010906700ec000800e0a0e09001000d0007004020403480000e00070003c081d30100821000000503862001008310060005c080b10100051006
0005c082da820086100600012001a0070086100600012001a001000a10060005c0c0db23006f1006006001106002008b10060061c0f1d587008b100600804060
3407008d10060001a00110c6000a100600a1c0c1d407008d10470001c001d7c4008b10060001c0f1d602008f100000050447e002000020080005c080b2040003
200800604040340600052008008050403403000720080001c08110090004200800108110508c0002200000014303200c000a20e700811010500f000a20870010
40105089000920080041c041d80b00ec20480082e010700d000d200000102410508e000d2000001024105008008b20080081c041d60f000020000084c387104f
0000208700a0c087b3821003208700012081a0031009208700604040340510092087006040403485100120870001c001e002104120090081c010710210412087
0010c01040e4104120870010c0104006100420870001c083d308100c204600a010c040081089204500a010c0400a1004200000844207200e1008208400804060
3400200b208400604040344a10e1308400204210600a108f208400a0c031d50c1001300500011080804e1041306700011060404b100e208400e1c081d9071002
3000000584871007108230090005c080b4081006300900604040340a1006300900604040340c1006300900604040340e10063009006040403407100930890005
10105009100930090010401050ee10093009001040105009108b300900012001a00d108b300900012001a087100e3009001080109087106f30090010801090e8
100e30090010801090e8106f300900108010906710ed300a00e0a0e0900d100f3009000241107208108240000004c344200810824087000480c1200810064068
00041081900810094087000480012008100640870020708120cf100640870020708120891005408800805080340d100a408800604040340a100b406800101001
400a100d4087001080104006100d40000004c3841006100e40870004c080b5071001508700604040340b1081508700802001a006100350870002c081dc0d1006
508600c08043100d1006508700106043506e1006508700106043508d10095087006030403409100650670010104350e7108550c7001001c171e7108750000010
e31050e9108850080010014272e9108a5000001004105005108c5000000504c42005100e50080005c080b68610806008006040403405100060080005c0c1dd06
1006600000044503e00810846008004060c0108810846008004040c0100910846008004020c0100610846008000180c010a610e560090060c010608b10046008
0080c0a0108b100260080080506034081008608a000210815008100860aa0002c081b70c100b608a00108110504900cf00070040a040f041004e10060040a040
f08f008d20870040a040f040200040090040a040f0ce108940880040a040f081008c10c7000410105081008c10060010e0105089008c10060010e01050c1008c
10670050301071a8008c1067005030107209ff00000000828587e00aff02100000828288200bff05200000828609100d0000000000838487200e000110000083
020610000000300000060306200d0002300000040686e005200320000004050ae0032009300000838386200c00064000008405871001200b400000830646e00c
0008500000048606e001200a5000008305871004100f600000068883200d0006600000830486100f0005000900810110730e108860c9000460c0200e1088608a
00044010500e10e9608a0004401050062003600000844585200a2086608a0030408234023003600000080289100f2009606800c01002400f2009600000103410
406030ec60000010341040ee208a60880010016060803009606600c010024080300960000010331040e130ec6000001033104060308a60860010016060833089
60040042c0c1b80a300760040082c002200a308c6004004040c19404300270a4000610205004300270040010502050ef30027004001050205002300670000008
0386208630e570040060011060023006700600c1812020883006700600c4812020c14006700600208186200230c2800600088120200230067006002081032002
3000800600208181200230067009000820869082308b70a600a710209082308b70060010812090a1408b700600108120900a308d700600404081940930467006
002001e19009300d700600200102908b3087700600023080900e300f700600c140819085308770060081c0c0b908200a7000000403861000300d70c500012001
9000308080e5000110105002200b700000038586e00820828006001082606008200c70e700c0104140082000808900c010014083208c700b0081414073822082
800b0042c002ba0c1083800a000380c01004100b7000000485c710051086800b000230205404100c80000004c4062004108a8069008010c04004108a80000010
b4c040061001902a008210205006100190890010502050ea10019089001050205005100d80890003c0c0bb85108a800000c283c02085108a802800c210c07085
108a8007001090c090ea108a8007001090c09006100b800700024040940b10cb800700104120608d100f800000c68484200c1006906900c01080908d10069009
001030809002200f8009004040433406208090a90020104350062080900900205010500620e6900900205010500d200f800000844445100b208690e800011020
400d2086908800103020408e2001908800c2c0c1bc0d20899000008445c620013069908800600110600d208f908a00433020540a2003a04a008120c0400d1000
a0000086450510051002a00000040704e00d1084a08a0010c16060812081a02b0020104350812081a08a00205010508120e7a08a0020501050052082a08a0002
c041bd061008a00e0003c1407308000aa0000004ca05a00f100da00000040c05e0861083a00e0042c0c1c020240020202fff300000602b001020efff40403000
__sfx__
000300001e62500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
00020000164311d430224250000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000300000e64508625000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000400002062424630216250000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
00020000282352d225000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000300001a6251c6151a6251c61500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0005000024040280402b0403004500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000200001c63522625000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000500000a665066550c0530000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0007000024540285402b540305502b530305550000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0003000014041200412c0350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
00050000123530c345000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
001420000c1350c1050c1050c1050c1050c1050c1050c105131350c1050c1050c1050c1050c1050c1050c1050c1350c1050c1050c1050c1050c1050c1050c105131350c1050c1050c1050c1050c1050c1050c105
0014200015135151051510515105151051510515105151051b1351510515105151051510515105151051510515135151051510515105151051510515105151051b13515105151051510515105151051510515105
001420001113511105111051110511105111051110511105181351110511105111051110511105111051110511135111051110511105111051110511105111051813511105111051110511105111051110511105
0014200013135131051310513105131051310513105131051a1351310513105131051310513105131051310513135131051310513105131051310513105131051a13513105131051310513105131051310513105
001320000c1350c1050c1050c1050c1350c1050c1050c105131350c1050c1050c1050c1350c1050c1050c1050c1350c1050c1050c1050c1350c1050c1050c105131350c1050c1050c1050c1350c1050c1050c105
0013200015135151051510515105151351510515105151051b1351510515105151051513515105151051510515135151051510515105151351510515105151051b13515105151051510515135151051510515105
001320001113511105111051110511135111051110511105181351110511105111051113511105111051110511135111051110511105111351110511105111051813511105111051110511135111051110511105
0013200013135131051310513105131351310513105131051a1351310513105131051313513105131051310513135131051310513105131351310513105131051a13513105131051310513135131051310513105
001420000c1350c1050c1050c1050c1350c1050c1050c105131350c1050c1050c1050c1350c1050c1050c1050c1350c1050c1050c1050c1350c1050c1050c105131350c1050c1050c1050c1350c1050c1050c105
0014200015135151051510515105151351510515105151051b1351510515105151051513515105151051510515135151051510515105151351510515105151051b13515105151051510515135151051510515105
001420001113511105111051110511135111051110511105181351110511105111051113511105111051110511135111051110511105111351110511105111051813511105111051110511135111051110511105
0014200013135131051310513105131351310513105131051a1351310513105131051313513105131051310513135131051310513105131351310513105131051a13513105131051310513135131051310513105
001220000c1350c1050c1050c1050c1350c1050c1050c105131350c1050c1050c1050c1350c1050c1350c1050c1350c1050c1050c1050c1350c1050c1050c105131350c1050c1050c1050c1350c1050c1350c105
0012200015135151051510515105151351510515105151051b1351510515105151051513515105151351510515135151051510515105151351510515105151051b13515105151051510515135151051513515105
001220001113511105111051110511135111051110511105181351110511105111051113511105111351110511135111051110511105111351110511105111051813511105111051110511135111051113511105
0012200013135131051310513105131351310513105131051a1351310513105131051313513105131351310513135131051310513105131351310513105131051a13513105131051310513135131051313513105
00142000180251800518005180051b0051b0051b0051b0051f0251f0051f0051f005220252200522005220051f0051f0051f0051f0051b0251b0051b0051b0051a0251a0051a0051a0051d0051d0051d0051d005
0014200024025240052400524005270052700527005270052b0252b0052b0052b0052702527005270052700524005240052400524005220252200522005220052602526005260052600521005210052100521005
00142000240252400524005240052700527005270052700524025240052400524005210252100521005210051f0051f0051f0051f005220252200522005220051d0251d0051d0051d00521005210052100521005
0014200029025290052900529005260052600526005260052202522005220052200521025210052100521005240052400524005240051f0251f0051f0051f0052202522005220052200526005260052600526005
00142000220252200522005220051f0051f0051f0051f0051d0251d0051d0051d00521025210052100521005160051600516005160051a0251a0051a0051a0051d0251d0051d0051d00521005210052100521005
001420002702527005270052700526005260052600526005290252900529005290052402524005240052400522005220052200522005260252600526005260052902529005290052900526005260052600526005
00142000220252200522005220052600526005260052600521025210052100521005240252400524005240052200522005220052200526025260052600526005220252200522005220051f0051f0051f0051f005
00142000270252700527005270052200522005220052200526025260052600526005290252900529005290052700527005270052700524025240052400524005210252100521005210051f0051f0051f0051f005
001320001f0251f0051f0051f005220052200522025220051f0251f0051f0051f0051b0051b0051b0251b0051a0051a0051a0251a0051d0051d0051d0051d005180251800518005180051b0251b0051b0051b005
001320002b0252b0052b0052b00527005270052702527005240252400524005240052200522005220252200526005260052602526005210052100521005210052402524005240052400527025270052700527005
0013200024025240052400524005210052100521025210051f0251f0051f0051f005220052200522025220051d0051d0051d0251d005210052100521005210052402524005240052400527025270052700527005
001320002202522005220052200521005210052102521005240252400524005240051f0051f0051f0251f00522005220052202522005260052600526005260052902529005290052900526025260052600526005
001320001d0251d0051d0051d005210052100521025210051b0251b0051b0051b0051f0051f0051f0251f0051d0051d0051d0251d005210052100521005210051d0251d0051d0051d0051a0251a0051a0051a005
001320002902529005290052900524005240052402524005270252700527005270052b0052b0052b0252b00529005290052902529005260052600526005260052202522005220052200521025210052100521005
001320002102521005210052100524005240052402524005270252700527005270052b0052b0052b0252b005220052200522025220051f0051f0051f0051f0051d0251d0051d0051d00521025210052100521005
0013200026025260052600526005290052900529025290052d0252d0052d0052d00529005290052902529005210052100521025210051f0051f0051f0051f005220252200522005220051d0251d0051d0051d005
001420002b0252b0052b0052b00527005270052700527005260052600526025260052900529005290052900524025240052400524005270052700527025270052b0052b0052b0052b0052e0252e0052e0052e005
00142000300253000530005300052e0052e0052e0052e005320053200532025320052d0052d0052d0052d00530025300053000530005330053300533025330053700537005370053700533025330053300533005
001420002b0252b0052b0052b0052e0052e0052e0052e005290052900529025290052d0052d0052d0052d0053002530005300053000533005330053302533005300053000530005300052d0252d0052d0052d005
00142000300253000530005300052b0052b0052b0052b0052e0052e0052e0252e0053200532005320053200535025350053500535005320053200532025320052e0052e0052e0052e0052d0252d0052d0052d005
00142000270252700527005270052b0052b0052b0052b0052e0052e0052e0252e0053200532005320053200529025290052900529005260052600526025260052400524005240052400527025270052700527005
0014200033025330053300533005370053700537005370053a0053a0053a0253a005370053700537005370052e0252e0052e0052e0052d0052d0052d0252d005300053000530005300052b0252b0052b0052b005
0014200033025330053300533005370053700537005370053300533005330253300530005300053000530005290252900529005290052d0052d0052d0252d005270052700527005270052b0252b0052b0052b005
00142000390253900539005390053500535005350053500532005320053202532005300053000530005300052e0252e0052e0052e005290052900529025290052d0052d0052d0052d00530025300053000530005
001220001a0251a0051a0051a0051d0251d0051d0251d005180051800518005180051b0251b0051b0051b0051f0251f0051f0051f005220252200522005220051f0051f0051f0251f0051b0251b0051b0051b005
00122000260252600526005260052102521005210252100524005240052400524005270252700527005270052b0252b0052b0052b005270252700527005270052400524005240252400522025220052200522005
001220001d0251d0051d0051d00521025210052102521005240052400524005240052702527005270052700524025240052400524005210252100521005210051f0051f0051f0251f00522025220052200522005
00122000220252200522005220052602526005260252600529005290052900529005260252600526005260052202522005220052200521025210052100521005240052400524025240051f0251f0051f0051f005
001220002202522005220052200526025260052602526005220052200522005220051f0251f0051f0051f005180251800518005180051b0251b0051b0051b005160051600516025160051a0251a0051a0051a005
001220002e0252e0052e0052e0052b0252b0052b0252b0052700527005270052700526025260052600526005240252400524005240051f0251f0051f0051f0052200522005220252200526025260052600526005
00122000270252700527005270052402524005240252400522005220052200522005260252600526005260051b0251b0051b0051b0051f0251f0051f0051f0052200522005220252200526025260052600526005
001220002602526005260052600524025240052402524005270052700527005270052202522005220052200521025210052100521005240252400524005240052700527005270252700524025240052400524005
001420001202300000346150000000000000003461500000120230000034615000000000000000346150000012023000003461500000000000000034615000001202300000346150000000000000003461500000
001320001203300000346150000000000000003461500000120330000034615000000000000000346150000012033000003461500000000000000034615000001203300000346150000000000000003461500000
001420001203300000000000000000000000000000000000120330000000000000000000000000000000000012033000000000000000000000000000000000001203300000000000000000000000000000000000
001220001203300000000000000000000000000000000000120330000000000000000000000000000000000012033000000000000000000000000000000000001203300000000001203300000000000000000000
__music__
01 1c0c3c40
00 1d0d3c40
00 1e0e3c40
00 1f0f3c40
00 200c3c40
00 210d3c40
00 220e3c40
02 230f3c40
01 24103d40
00 25113d40
00 26123d40
00 27133d40
00 28103d40
00 29113d40
00 2a123d40
02 2b133d40
01 2c143e40
00 2d153e40
00 2e163e40
00 2f173e40
00 30143e40
00 31153e40
00 32163e40
02 33173e40
01 34183f40
00 35193f40
00 361a3f40
00 371b3f40
00 38183f40
00 39193f40
00 3a1a3f40
02 3b1b3f40
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
__label__
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
cccc777c777c777c7c7cc777777c777cccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
cccc7c7c7c7c7c7c7c7c777777777c7ccccccccccccccccccccccccccccccccccc550505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
cccc777c777c77cc77c77777777777cccccccccccccccccccccccccccbcccccccc550505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
6c6c7c6c7c7c7c7c7c7777777777777c6c6c6c6c6c6c6c6c6c6c6c6cbbbc6c6c6c550505000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c676c6767676767677777777777776c6c6c6c6c6c6c6c6c6c666c6cbc6c6c6c65505050006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6c6c6c6c6c6c6c67777777777777776c6c6c6c6c6c6c6c6c66666c6c6c6c6c6c555505000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6c6c6c6c6c6c6c777777777777777c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c65555050006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6caaac6c6cac6caaa7a7a7aaa7a7776aac6c6c6aacaaac6c66aaacac6c6aacaca55505000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6a6a6c6c6a6c6a777a7a7a777a777a6c6c6c6a6a6a6c6c6c6a6c6a6c6a6a6a6a555050006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6caaac6c6cac6caa77a7a7aa77a777aaac6c6cacacaa6c6c66aa6cac6cacacaca55505000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6a6a6c6c6a6c6a677aaa7a777a776c6a6c6c6a6a6a6c6c6c6a6c6a6c6a6a6aaa550050006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6caaac6c6caaacaaa77a77aaa7aaacaa6c6c6caa6cac6c6c66a66caaacaa6caaa55005000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6c6c6c6c6c6c6c6c77777777777c6c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c655500500c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6c6c6c6c6c6c6c6c6c777777777c6c6c6c6c6c6c6c6c6c6c66666c6c6c6c6c6c555005006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6c6c6c6c6c6c6c6c6c6777776c6c6c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c655500500c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c66666c6c6c6c6c6c555005006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
6666c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c655500500c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6666666666666
66666c6c6c6c6c6c6666666666666c6c6c6c6c6c6c6c6c6c6c66666c6c6c6c6c6c555005006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c666666666666
6666c6c6c6c6c6c666666666666666c6c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c655500500c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6666666666666
66666666666666666666666666666666666666666666666666666666666666666655500500666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666655500500666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666655505500666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666655505500666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666655505500666666666666666666666666666666666666666666666666666666
6666666666666666666666666666666666666666666666666660a906666666666655505500666666666666666666666666666666666666666666666666666666
6666666666666666666666666666666666666666666666666660a906666666666655505500666666666666666666666666666666666666666666666666666666
6666666666666666666666666666666666666666666666666660a9006666666666555055006666666666666dddddddd666666666666666666666666666666666
6666666666666666666666666666666666666666666666666660a9009666666666555055006666666666666dddddddd66666666666666666dddddddd66666666
6666666666666666666666666666666666666666666666666660a9009966666666555055006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660a9009966666666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660a9009906666666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660a9009900666666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660aa009900666666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660aa009900966666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660aa009900966666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666646464646464646464646460aa009900946464555050006464646464666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666664646464646464646464640aa009900964646555050004646464646466dddddddd66666666666666666dddddddd66666666
6666666666666666666666666666646464646464646464646460aa00990094646455505004646464646466666666666666666666666666666666666666666666
6666666666666666666666666666664646464646464646464640aa00990096464655505006464646464646666666666666666666666666666666666666666666
6666666666666666666666666666666464646464646464646460aa00990094646455505004646464646466666666666666666666666666666666666666666666
4444444444444444444444444444444646464646464646464640aa00990096464655505006464646464644444444444444444444444444444444444444444444
4444444444444444444444444444446464646464646464646464aa00990094646455505004646464646464444444444444444444444444444444444444444444
4444444444444444444444444444444646464646464646464646aa00990096464655505006464646464644444444444444444444444444444444444444444444
4444444444444444444444444444446464646464646464636363aa00990094646455505004646464646444444444444444444444444444444444444444444444
4444444444444444444444444444444646464646464646463636aa00990096464655505006464646464644444444444444444444444444444444444444444444
4444444444444444444444444666666666666666666666666666aa00990096666655505006666666666666644444444444444444444444444444444444444444
444444444444444444444446d6d6d6d6d6d6d6d6d6d6d6d6d6d6aa0099009444445550500449d6d6d6d6d6d6d444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990044444455505004449944466666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990044444445505004444994466666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990044444445505004444499466666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990444444444505004444444996666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990444444444505004444444499666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00994444444444505004444444449996666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00994444444444505004444444444999666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00944444400044445004444444464449996444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00944444000004445004444444466444999444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00944444000004455004444444466644499944444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00444444000004455004444444466664449999444444444444444444444444444444444444
44444444444444444444444666666666664444444444444444444444444444f000f4455004444444466666444499944444444444444444444444444444444444
444444444444444444444446666666666644444444444444444444444444444fff44455004444444466666664449999444444444444444444444444444444444
44444444444444444444444666666666664444444444444444444444444444488844455004444444466666666444999944444444444444444444444444444444
44444444444444444444444666666666664444444444444444444444444244888884844444444444466666666444499999444444444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228855588884444444444466666666444444999944444444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228555558884444444444466666666444444499994444444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228555558884444444444466666666444444449999944444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228555558888444444444466666666444444444999994444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228555558484444444444466666666444444444449999944444444444444444444444
4444444444444444444444466666666666444444444444444444444444f248555558444444444444466666666444444444444999994444444444444444444444
44444444444444444444444666666666664444444444444444444444444448855588444444444444466666666444444444444499999944444444444444444444
44444444444444444444444666666666664444444444444444444444444440111111444444444444466666666444444444444449999994444444444444444444
44444444444444444444444666666666664444444444444444444444444400111111144444444444466666666444444444444444499999444444444444444444
66666666666666666666666666666666666666666666666666666666666000111111666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666000611111166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666606666611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666000666611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666000666661666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666600066611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666660666611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666600066661666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666600066611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666660666611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666555561666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666665555511166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666555555511166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666665555555711556666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666655555111666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666665555516666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666555566666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
