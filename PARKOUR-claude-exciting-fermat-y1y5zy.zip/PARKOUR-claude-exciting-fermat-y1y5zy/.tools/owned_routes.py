import sys,importlib
sys.path.insert(0,'tools');import playtest
playtest.CART='.tools/routes.p8'
res=[]
for n in (2,3,5,6,7,8):
 m=importlib.import_module('tests.l'+str(n))
 for k,v in m.SCENARIOS.items():
  name='L%d:%s'%(n,k);playtest.SCENARIOS[name]=v;res.append(playtest.run(name))
print('%d/%d passed'%(sum(res),len(res)))
