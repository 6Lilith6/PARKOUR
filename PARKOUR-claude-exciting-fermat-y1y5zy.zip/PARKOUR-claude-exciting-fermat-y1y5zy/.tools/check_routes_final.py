import sys,importlib,os
sys.path.insert(0,'tools');import playtest,build
playtest.CART=build.build(os.path.abspath('.tools/routes.p8'))[0]
for n in (2,3,5,6,7,8):
 m=importlib.import_module('tests.l'+str(n));playtest.SCENARIOS.update({'L%d:%s'%(n,k):v for k,v in m.SCENARIOS.items()})
for k in ('L2:pallet_f1','L3:catwalk_to_containers','L3:pump_service_pier','L3:long_jump','L3:silo_goal','L5:billboard_cable','L6:rail_deck','L7:outcrops','L7:gorge_beams'):playtest.run(k,True)
