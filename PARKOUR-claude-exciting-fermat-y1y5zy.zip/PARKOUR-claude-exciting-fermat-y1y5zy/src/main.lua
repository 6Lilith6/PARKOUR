-- parkour: rooftops
-- third-person 3d parkour
-- main loop, game flow,
-- checkpoints, timer, hud

dt=1/60

function _init()
 cartdata"pk_parkour_3"
 menuitem(1,"restart level",restart)
 menuitem(2,"last checkpoint",respawn)
 menuitem(3,"level select",function() load"parkour_menu.p8" end)
 -- debug: fps, cpu, collision
 -- boxes near the runner
 menuitem(4,"perf overlay",function() dbg=not dbg end)
 mode="play"
 setlv(cart_lv)
 -- The previous cartridge saves only intent and horizontal speed. Entry is
 -- the authored spawn, with ordinary physics and full control from frame 1.
 if dget(8)==lv+1 then
  spd=mid(0,dget(9),9)
  vx,vz=cos(ang)*spd,sin(ang)*spd
  started=true
  dset(8,0)
 else
  dset(10,0)
 end
end

function restart()
 cpi,tm,score,cp,started=0,0,0,spawn
 worldreset()
 musphase=nil
 scoremusic()
 respawn()
end

-- reset player at checkpoint
function respawn()
 px,py,pz,ang=unpack(cp)
 for k in all(split"vx,vy,vz,spd,flow,chain,idle,bal,balv,heavy,ngrab,jbuf,rbuf,coy,kicks,aph,shake,stun,popt,splt,shy,wrs,lc,lvy,oh") do _ENV[k]=0 end
 peak,pop,fade,bang,crouch,gb,wupd,lastwr,gnd=py,"",12,ang
 setst"ground"
 nearupd()
 camreset()
end

function inp()
 local o,x=jz,xx
 jz,xx,iu,id=btn(4),btn(5),btn(2),btn(3)
 jzp,xp=jz and not o,xx and not x
 turn=(btn(0) and 1 or 0)-(btn(1) and 1 or 0)
end

-- 30 fps: one drawn frame runs
-- two fixed 1/60s steps, so the
-- physics never depends on how
-- long drawing takes
function _update()
 inp()
 menu()
 step()
 jzp,xp=nil
 step()
end

function menu()
 if mode=="done" then
  if jzp then load(nextcart) end
  if xp then mode="play" restart() end
 end
end

-- Four movements, each eight phrases. Music keeps three channels;
-- movement and landing sounds always have the fourth available.
function scoremusic()
 local p=min(cpi*4/(cart_cp+1)\1,3)*8
 if p~=musphase then
  musphase=p
  music(p,400,7)
 end
end

function step()
 if mode=="play" then
  if btn()>0 then started=true end
  if started then tm=min(tm+dt,32760) end
  fade,splt,popt=max(fade-1),max(splt-dt),max(popt-dt)
  worldupd()
  pupd()
  trigupd()
 end
 camupd()
end

function trigupd()
 hint=nil
 for b in all(trig) do
  if inside(b,px,pz,0) and py>b[2]-1 and py<b[5] then
   if b.m==11 and b.k>cpi then
    cpi,cp,splt=b.k,{(b[1]+b[4])/2,b[2],(b[3]+b[6])/2,ang},2.5
    scoremusic()
    sfx(6)
   elseif b.m==12 and (b.k==0 or gnd and gnd.ev and gnd.ev[1]<2) then
    -- finish line
    mode,best="done",dget(lv)
    newbest=best==0 or tm<best
    if newbest then
     dset(lv,tm)
    end
    sfx(9)
    if dget(10)>0 and lv~=7 then
     dset(8,next_lv+1)
     dset(9,hs())
     load(nextcart)
    end
   elseif b.m==13 then
    hint=b.k+1
   end
  end
 end
end

-- m:ss.cc from seconds; long levels do not overflow fixed-point time.
function ft(f)
 local s=f\1
 return s\60 ..":"..sub("0"..s%60,-2).."."..sub("0"..(f%1*100\1),-2)
end

-- outlined text (centered if no x)
function pr(s,y,c,x)
 x=x or 64-#s*2
 for d=-1,1,2 do print(s,x+d,y,0) print(s,x,y+d,0) end
 print(s,x,y,c)
end

function _draw()
 render()
 -- timer, best time
 pr(ft(tm),2,7,2)
 if dget(lv)>0 then pr(ft(dget(lv)),9,5,2) end
 -- checkpoint split vs best
 if splt>0 then
  pr("checkpoint "..cpi,20,11)
 end
 -- speed + flow meter
 rectfill(2,121,2+hs()/9*40,124,flow>.6 and 10 or flow>.3 and 9 or 13)
 rect(1,120,43,125,5)
 -- A fixed move label keeps the landing zone visually quiet.
 if popt>0 then
  pr(pop,112,7)
 end
 if hint then
  rectfill(1,97,126,117,1)
  print(hints[hint],3,99,7)
 end
 if fade>0 then
  fillp(fade>6 and 0 or 0x5a5a)
  rectfill(0,0,127,127,0)
  fillp()
 end
 if mode=="done" then
  rectfill(16,34,111,96,0)
  rect(16,34,111,96,7)
  pr(lname,40,10)
  pr("time  "..ft(tm),52,7)
  pr(newbest and "new best!" or "best  "..ft(best),60,newbest and 11 or 6)
  pr("flow score "..score,72,12)
  pr("🅾️ continue  ❎ retry",86,7)
 end
 if dbg then print(stat(7).." "..stat(1).." "..#nb,1,9,7) end
end
