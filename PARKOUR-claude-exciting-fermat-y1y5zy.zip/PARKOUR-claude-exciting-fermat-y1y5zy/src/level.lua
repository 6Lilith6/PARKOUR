-- level data, written into cart
-- memory by tools/build.py.
-- 0x0000: single 2-byte level address (the cart owns one level).
-- level block:
--  16 display palette
--  11 sky: top,haze,sil a,sil b,
--     ground,sun,fog col,fog dist,
--     hint base,spawn heading,
--     silhouette height
--  15 materials x 4: top,side x,
--     side z,deco (lo=type hi=col)
--  2 box count, boxes x 10 bytes:
--  x,z,y:2 (/8) w,h,d:1 (/4)
--  mat:1 (lo=material hi=arg)
-- material flags (fixed per id):
-- 1 solid 2 climb 4 bouncy 8 trigger
mflag=split"1,1,1,1,1,3,1,5,1,1,8,8,8,1,1"

-- read an n-byte value
function rd(n)
 ra+=n
 return n>1 and peek2(ra-2) or peek(ra-1)
end

function setlv(l)
 lv=cart_lv
 ra=peek2(0)
 for i=0,15 do pal(i,rd(1),1) end
 sk,mats,boxes,trig,dl,movers={},{},{},{},{},{}
 for i=1,11 do sk[i]=rd(1) end
 for i=1,15 do mats[i]={rd(1),rd(1),rd(1),mflag[i],rd(1)} end
 for i=1,rd(2) do
  local x,z,y=rd(2)/8,rd(2)/8,rd(2)/8
  local w,h,d,m=rd(1)/4,rd(1)/4,rd(1)/4,rd(1)
  local b={x,y,z,x+w,y+h,z+d,m=m%16,k=m\16,f=mflag[m%16]}
  if b.f&8>0 then
   add(trig,b)
   if b.m==11 and b.k==0 then spawn={x+w/2,y,z+d/2,sk[10]/256} end
  else
   add(boxes,b) add(dl,b)
   if b.k>=12 then
    b.o=0
    b.ev={0,b.k==13 and 2 or b.k==14 and 1 or 3,b.k==12 and 12 or b.k==13 and 4 or 8,6,3}
    add(movers,b)
   end
  end
 end
 -- An event owns an existing solid body. Its collision, visible model and
 -- rider attachment always use exactly the same transformed coordinates.
 -- index:u16, kind:u8, axis:u8, travel:s16/8, duration/dwell:u8/4,
 -- activation range:u8, warning delay:u8/4.
 for i=1,rd(1) do
  local b=boxes[rd(2)]
  if not b.o then add(movers,b) end
  b.o,b.ev=0,{rd(1),rd(1),rd(2)/8,rd(1)/4,rd(1)/4,rd(1),rd(1)/4}
 end
 -- player pseudo-box, sorted
 -- with the world for drawing
 plb={}
 add(dl,plb)
 restart()
end

-- Transport has a timetable, with dwell at each end. The same boxes
-- participate in rendering, collision and rider attachment.
function worldreset()
 wt=0
 for b in all(movers) do
  local ax=b.ev[2]
  b[ax]-=b.o b[ax+3]-=b.o b.o=0
  b.ev.t,b.warn,b.dim=nil
 end
end

-- Scripts move architecture, never the runner. Crumbling supports wait for
-- the entire player footprint to clear; weak floors intentionally do not
-- carry their rider, so ordinary gravity and roll rules handle the drop.
function eventoffset(b,ride)
 local e,k=b.ev,b.ev[1]
 if not e.t then
  local touch=inside(b,px+vx*dt,pz+vz*dt,-r-.12) and py<b[5] and py+ph>b[2]
  if (k==2 or k==3) and ride or k==4 and touch and hs()>=4 or k~=2 and k~=3 and k~=4 and inside(b,px,pz,-e[6]) and abs(py-b[5])<e[6]+3 then
   e.t=0
   if k>1 and k<5 then sfx(8) end
  else
   return 0
  end
 end
 e.t=min(e.t+dt,32760)
 if (k==2 or k==6) and e.t<e[7]+dt*2 and inside(b,px,pz,-r) then e.t=min(e.t,e[7]) end
 b.warn=(k==2 or k==3 or k==6) and e.t<=e[7]
 if k==7 then
  b.dim=e.t>e[7] and e.t<e[7]+e[4]
  return 0
 end
 if k==4 then return e[3] end
 local t=max(e.t-e[7])
 if k==1 then t%=2*(e[4]+e[5]) t=min(t,2*e[4]+e[5]-t) end
 return e[3]*mid(0,t/e[4],1)
end

function worldupd()
 if not started then return end
 wt=(wt+dt)%24
 local phase,moved=mid(0,min(wt-3,21-wt)/6,1),false
 for b in all(movers) do
  local e=b.ev
  local ax=e[2]
  local ride=gnd==b and abs(py-b[5])<.1
  local held=hb==b and (st=="hang" or st=="pull")
  local offset=e[1]==0 and phase*e[3] or eventoffset(b,ride)
  local d=b.k==14 and dt*1.2 or offset-b.o
  if b.k~=14 then
   b[ax]+=d b[ax+3]+=d b.o=offset
  end
  if e[1]<2 and (ride or held) then
   local p={px,py,pz}
   p[ax]+=d
   px,py,pz=unpack(p)
   moved=ride and d~=0 or moved
   if held and st=="pull" then pa[ax]+=d pb[ax]+=d end
  elseif e[1]<2 and d~=0 and b.k~=14 and phit()==b then
   -- A slow vehicle pushes toward its direction of travel instead of
   -- swallowing the runner. A blocked exit uses the last safe checkpoint.
   if ax==1 then px=d>0 and b[4]+r+.01 or b[1]-r-.01 end
   if ax==3 then pz=d>0 and b[6]+r+.01 or b[3]-r-.01 end
   moved=d~=0 or moved
  end
 end
 -- Recheck against the current world, including newly arrived vehicles.
 if moved then
  nearupd()
  if phit() then respawn() end
 end
end
