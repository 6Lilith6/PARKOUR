-- A small independent launcher. Every destination also runs on its own.
names=split"old city,downtown,subway,construction,factory,neon,mountain,megastructure"
files=split"old_city,downtown,subway,construction,factory,neon,mountain,megastructure"
ids=split"0,4,3,1,2,5,6,7"
styles=split"courtyards / rooftops,streets to a running train,stations / train roofs,climb the unfinished tower,momentum / machinery,night bridges / speed,village to high cliffs,from the depths to the crown"
colors=split"9,7,12,9,4,14,3,13"

function _init()
 cartdata"pk_parkour_3"
 sel=1
 t=0
 menuitem(1,"start selected",launch)
end

function launch()
 dset(10,1)
 dset(8,ids[sel]+1)
 dset(9,0)
 load(files[sel]..".p8","level select")
end

function _update()
 t+=1/30
 if btnp(2) or btnp(0) then sel=(sel+6)%8+1 end
 if btnp(3) or btnp(1) then sel=sel%8+1 end
 if btnp(4) or btnp(5) then launch() end
end

function _draw()
 cls(1)
 rectfill(0,0,127,26,0)
 print("\^w\^tparkour",25,5,7)
 print("eight places. find your line.",8,20,6)
 for i=1,8 do
  local y=30+(i-1)*9
  if i==sel then rectfill(4,y-1,123,y+7,5) end
  rectfill(7,y+1,9,y+4,colors[i])
  print(i.."  "..names[i],15,y+1,i==sel and 7 or 6)
  if dget(ids[i])>0 then print("*",114,y+1,11) end
 end
 rectfill(0,104,127,127,0)
 print(styles[sel],4,107,colors[sel])
 print("⬆️⬇️ choose   🅾️ begin",17,118,7)
end
