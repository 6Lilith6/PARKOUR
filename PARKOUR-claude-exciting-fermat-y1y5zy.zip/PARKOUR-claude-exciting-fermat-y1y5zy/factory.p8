pico-8 cartridge // http://www.pico-8.com
version 42
__lua__
cart_lv,cart_cp,lname,nextcart,hints,dt=2,10,"factory","subway.p8",split("factory: long straights build\nflow - keep moving, keep speed|the catwalk is the sprint lane:\nladder or crate steps up|container tops: chain the jumps\nwithout stopping|hold 🅾️ along the tank: wallrun\nonto the pipe rack|❎ slide under the pipes,\nvault the valve|pit: pump pier or long jump\nservice bridge below is safer","|"),.01667

function _init()
 cartdata"pk_parkour_3"
 menuitem(1,"restart level",restart)
 menuitem(2,"last checkpoint",respawn)
 menuitem(3,"level select",function() load"parkour_menu.p8" end)

 menuitem(4,"perf overlay",function() dbg=not dbg end)
 mode="title"
 setlv(cart_lv)
end

function restart()
 cpi,tm,splits,score,cp,started=0,0,{},0,spawn
 worldreset()
 musphase=nil
 scoremusic()
 respawn()
end

function respawn()
 px,py,pz,ang=unpack(cp)
 for k in all(split"vx,vy,vz,spd,flow,chain,idle,bal,balv,heavy,ngrab,jbuf,rbuf,coy,kicks,aph,shake,stun,popt,splt,shy,wrs,lc,lvy,oh") do _ENV[k]=0 end
 peak,pop,fade,bang,crouch,gb,wupd,lastwr,gnd=py,"",12,ang
 setst"ground"
 nearupd()
 camreset()
end

function inp()
 local o,x=jz,xx
 jz,xx,iu,id=btn(4),btn(5),btn(2),btn(3)
 jzp,xp,turn=jz and not o,xx and not x,(btn(0)and 1or 0)-(btn(1)and 1or 0)
end

function _update()
 inp()
 menu()
 step()
 jzp,xp=nil
 step()
end

function menu()
 if mode=="title" do
  ang+=.0016
  if (jzp) mode="play" restart()
 elseif mode=="done" do
  if (jzp) load(nextcart)
  if (xp) mode="play" restart()
 end
end

function scoremusic()
 local p=min(cpi*4/(cart_cp+1)\1,3)*8
 if (p~=musphase) musphase=p music(p,400,7)
end

function step()
 if mode=="play" do
  if (btn()>0) started=true
  if (started) tm=min(tm+dt,32760)
  fade,splt,popt=max(fade-1),max(splt-dt),max(popt-dt)
  worldupd()
  pupd()
  trigupd()
 end
 camupd()
end

function trigupd()
 hint=nil
 for b in all(trig) do
  if inside(b,px,pz,0) and py>b[2]-1 and py<b[5] do
   if b.m==11 and b.k>cpi do
    cpi,cp,splt=b.k,{(b[1]+b[4])/2,b[2],(b[3]+b[6])/2,ang},2.5
    splits[cpi]=tm
    scoremusic()
    sfx(6)
   elseif b.m==12 do

    mode,best="done",dget(lv)
    newbest=best==0 or tm<best
    if (newbest) dset(lv,tm)
    sfx(9)
   elseif b.m==13 do
    hint=b.k+1
   end
  end
 end
end

function ft(f)
 local s=f\1
 return s\60 ..":"..sub("0"..s%60,-2).."."..sub("0"..f%1*100\1,-2)
end

function pr(s,y,c,x)
 x=x or 64-#s*2
 for d=-1,1,2 do ?s,x+d,y,0
?s,x,y+d,0 
end
 ?s,x,y,c
end

function _draw()
 render()
 if mode=="title" do
  rectfill(0,30,127,74,0)
  pr("⁶w⁶tparkour",36,7,36)
  pr(lname,50,9)
  pr("press 🅾️ to start",64,7)
  rectfill(0,90,127,112,0)
  ?"⬅️➡️ steer  ⬆️ run  ⬇️ brake\n🅾️ jump, hold on walls\n❎ slide / roll / drop",6,92,6
  if (dget(lv)>0) pr("best "..ft(dget(lv)),116,10)
  return
 end

 pr(ft(tm),2,7,2)
 if (dget(lv)>0) pr(ft(dget(lv)),9,5,2)

 if (splt>0) pr("checkpoint "..cpi,20,11)

 rectfill(2,121,2+hs()/9*40,124,flow>.6 and 10 or flow>.3 and 9 or 13)
 rect(1,120,43,125,5)

 if (popt>0) pr(pop,112,7)
 if (hint) rectfill(1,97,126,117,1) ?hints[hint],3,99,7
 if (fade>0) fillp(fade>6 and 0 or 23130) rectfill(0,0,127,127,0) fillp()
 if (mode=="done") rectfill(16,34,111,96,0) rect(16,34,111,96,7) pr(lname,40,10) pr("time  "..ft(tm),52,7) pr(newbest and "new best!" or "best  "..ft(best),60,newbest and 11 or 6) pr("flow score "..score,72,12) pr("🅾️ continue  ❎ retry",86,7)
 if (dbg) ?stat(7).." "..stat(1).." "..#nb,1,9,7
end

mflag=split"1,1,1,1,1,3,1,5,1,1,8,8,8,1,1"

function rd(n)
 ra+=n
 return n>1 and peek2(ra-2) or peek(ra-1)
end

function setlv(l)
 lv,ra=cart_lv,peek2(0)
 for i=0,15 do pal(i,rd(1),1) end
 sk,mats,boxes,trig,dl,movers={},{},{},{},{},{}
 for i=1,11 do sk[i]=rd(1) end
 for i=1,15 do mats[i]={rd(1),rd(1),rd(1),mflag[i],rd(1)} end
 for i=1,rd(2) do
  local x,z,y,w,h,d,m=rd(2)/8,rd(2)/8,rd(2)/8,rd(1)/4,rd(1)/4,rd(1)/4,rd(1)
  local b={x,y,z,x+w,y+h,z+d,m=m%16,k=m\16,f=mflag[m%16]}
  if b.f&8>0 do
   add(trig,b)
   if (b.m==11 and b.k==0) spawn={x+w/2,y,z+d/2,sk[10]/256}
  else
   add(boxes,b) add(dl,b)
   if (b.k>=12) b.o=0 add(movers,b)
  end
 end

 plb={}
 add(dl,plb)
 restart()
end

function worldreset()
 wt=0
 for b in all(movers) do
  local ax=b.k==13 and 2 or 3
  b[ax]-=b.o b[ax+3]-=b.o b.o=0
 end
end

function worldupd()
 if (not started) return
 wt=(wt+dt)%24
 local phase,moved=mid(0,min(wt-3,21-wt)/6,1),false
 for b in all(movers) do
  local ax,offset=b.k==13 and 2 or b.k==14 and 1 or 3,phase*(b.k==12and 12or b.k==13and 4or 8)
  local d,ride,held=b.k==14 and dt*1.2 or offset-b.o,gnd==b and abs(py-b[5])<.1,hb==b and(st=="hang"or st=="pull")
  if (b.k~=14) b[ax]+=d b[ax+3]+=d b.o=offset
  if ride or held do
   local p={px,py,pz}
   p[ax]+=d
   px,py,pz=unpack(p)
   moved=ride and d~=0 or moved
   if (held and st=="pull") pa[ax]+=d pb[ax]+=d
  elseif d~=0 and b.k~=14 and phit()==b do

   if (ax==3) pz=d>0 and b[6]+r+.01 or b[3]-r-.01
   moved=d~=0 or moved
  end
 end

 if (moved) nearupd() if (phit()) respawn()
end

r=.3

function inside(b,x,z,m)
 return x>b[1]+m and x<b[4]-m and z>b[3]+m and z<b[6]-m
end

function nearupd()
 nb={}
 for b in all(boxes) do
  if (inside(b,px,pz,-8) and b[2]<py+8 and b[5]>py-8) add(nb,b)
 end
end

function hit(x0,y0,z0,x1,y1,z1)
 for b in all(nb) do
  if (x0<b[4] and x1>b[1] and y0<b[5] and y1>b[2] and z0<b[6] and z1>b[3]) return b
 end
end

function phit(y)
 y=y or py
 return hit(px-r,y,pz-r,px+r,y+ph,pz+r)
end

function solid(x,y,z)
 return hit(x-.05,y-.05,z-.05,x+.05,y+.05,z+.05)
end

function stepup(b)
 if (st~="air" and st~="wallrun" and b[5]-py<.55 and not phit(b[5]+.01)) py=b[5]+.01 return true
end

function pmove()
 wall,gnd=nil
 local ox,oz=px,pz
 px+=vx*dt
 local b=phit()
 if (b and vx~=0 and not stepup(b)) wnx,wnz=ox<(b[1]+b[4])/2 and -1 or 1,0 px,wall=wnx<0 and b[1]-r-.001 or b[4]+r+.001,b
 pz+=vz*dt
 b=phit()
 if (b and vz~=0 and not stepup(b)) wnx,wnz=0,oz<(b[3]+b[6])/2 and -1 or 1 pz,wall=wnz<0 and b[3]-r-.001 or b[6]+r+.001,b
 py+=vy*dt
 b=phit()
 if b and vy~=0 do
  if vy<0 do
   py,gnd=b[5],b

   for o in all(nb) do
    if (inside(o,px,pz,-r) and o[5]==py and not narrow(o)) gnd=o
   end
  else
   py=b[2]-ph
  end
  vy=0
 end
end

function hs()
 return sqrt(vx*vx+vz*vz)
end

function narrow(b)
 return b and min(b[4]-b[1],b[6]-b[3])<.7
end

function canvault(b)
 if (st~="ground" or not gnd or not iu or xx or jbuf>0 or narrow(gnd) or b.k~=4) return
 local h,dx,dz=b[5]-py,cos(ang),sin(ang)
 if (h<=.55 or h>1.35 or abs(b[2]-py)>.15 or -dx*wnx-dz*wnz<.65) return
 local ix=wnx~=0 and 1 or 3
 if (b[ix+3]-b[ix]>1.6 or b[7-ix]-b[4-ix]<.9) return
 local v=ix==1 and dx or dz
 local d=(b[v>0 and ix+3 or ix]-(ix==1 and px or pz)+(r+.15)*sgn(v))/v
 local x,z=px+dx*d,pz+dz*d
 local floor=solid(x,py-.1,z)
 return floor and abs(floor[5]-py)<.35 and inside(floor,x,z,.35) and not hit(min(px,x)-r,b[5]+.02,min(pz,z)-r,max(px,x)+r,b[5]+1.8,max(pz,z)+r) and not hit(x-r,floor[5]+.02,z-r,x+r,b[5],z+r)
end

function findledge(lo,hi)
 local x,z=px+cos(ang)*.6,pz+sin(ang)*.6
 for b in all(nb) do
  local t=b[5]-py
  if (t>lo and t<hi and inside(b,x,z,0) and not hit(x-.2,b[5]+.05,z-.2,x+.2,b[5]+1,z+.2)) return b
 end
end

function snapface(b,zf,keep)
 if (zf==nil) zf=max(b[1]-px,px-b[4])<=max(b[3]-pz,pz-b[6])
 if (not zf) wnx,wnz=px<b[1] and -1 or 1,0 px=wnx<0 and b[1]-r or b[4]+r else wnx,wnz=0,pz<b[3] and -1 or 1 pz=wnz<0 and b[3]-r or b[6]+r
 if (not keep) ang,vx,vy,vz=atan2(-wnx,-wnz),0,0,0
end

function trick(n,f,s)
 pop,popt,idle=n,1,0
 chain+=1
 score,flow=min(score+5*min(chain,20),32000),mid(0,flow+f,1)
 if (s) sfx(s)
end

function brk(n,s)
 pop,popt,chain,idle=n,1,0,0
 flow*=.4
 if (s) sfx(s)
end

function toair(j)
 peak,airjump,gnd=py,j
 setst"air"
end

function dojump()
 local h,jv=spd,6.2
 if (spd<2.5) h=iu and 3.6 or 0 else jv=6+spd*.2 if (not solid(px+cos(ang)*.8,py-.3,pz+sin(ang)*.8)) h*=1.08 trick("edge jump",.06)
 if (narrow(gb)) jv-=.6
 if (st=="slide" or st=="roll") jv-=.5 trick(st.." jump",.05)
 vx,vy,vz,jbuf=cos(ang)*h,jv,sin(ang)*h,0
 toair(true)
 sfx(1)
end

function startvault(b)
 vtop,vy0,vt=b[5],py,spd<3.6 and 1 or spd<6.3 and 2 or 3

 if (vtop-py>1.15) vt=min(vt,2)
 vdur,vspd=({.38,.2,.12})[vt],({min(spd,2.2),spd*.92,spd*1.04})[vt]
 trick(({"climb over","vault","speed vault"})[vt],vt*.05-.05,7)
 setst"vault"
end

function airgrab()
 if (ngrab>0 or xx or not wall or vy>0) return
 local b=findledge(.65,2.15)
 if b and abs(b[5]-wall[5])<.1 and min(b[4]-b[1],b[6]-b[3])>1.2 do
  if (b[5]-py<1.3 and not airjump) return
  hb,hcat=b,hs()>3
  snapface(b)
  if (b[5]-py<1.3) startpull() trick("mantle",.05,4) return true
  py=b[5]-(hcat and 1.5 or 2.05)
  setst"hang"
  trick(hcat and "cat leap" or "ledge grab",hcat and .1 or 0,4)
  return true
 end
end

function startpull()
 pa,pb,pdur={px,py,pz},{px+cos(ang)*.7,hb[5]+.01,pz+sin(ang)*.7},hcat and.3or.5
 setst"pull"
end

function wallkick(vp,out,n)
 vx,vy,vz,jbuf=-wnz*vp+wnx*out,max(vy,6.6-kicks*1.3),wnx*vp+wnz*out,0
 kicks+=1
 ang=atan2(vx,vz)
 toair(true)
 trick(n,.1,4)
end

function jumpback()
 ang+=.5
 vx,vy,vz,ngrab=cos(ang)*4.5,6.5,sin(ang)*4.5,.25
 toair(true)
 trick("wall jump",.05,4)
end

function bonk()
 vx,vz,spd,shake=0,0,0,.15
 brk("ouch",11)
end

g,s=20,{}

function setst(n)
 st,stt,ph=n,0,1.8
end

function pupd()
 nearupd()
 stt+=dt
 jbuf,rbuf,ngrab=max(jbuf-dt),max(rbuf-dt),max(ngrab-dt)
 if (jzp) jbuf=.12
 if (xp) rbuf=.3
 s[st]()

 if (py<1) sfx(11) respawn()

 shy=-1
 for b in all(nb) do
  if (inside(b,px,pz,0) and b[5]<=py+.05) shy=max(shy,b[5])
 end
 anim()
end

function gvel()
 vx,vy,vz=cos(ang)*spd,-3,sin(ang)*spd
 pmove()
end

s.ground=function()
 local nar,vmax=narrow(gb),6.2+flow*2.8
 if nar do
  vmax=4
  if (balance()) return
 else
  ang+=turn*(.6-min(spd,9)*.04)*dt
 end
 if (heavy>0) heavy-=dt vmax=2.5

 ph=1.8
 crouch=xx and spd<3.5 or phit()
 if (crouch) ph,vmax=1,1.6
 if (iu) spd+=(spd<5 and 9 or 2.2)*dt else spd-=(id and 16 or spd>3 and 4 or 9)*dt
 spd=max(min(spd,max(vmax,spd-6*dt)))

 if (spd>5.8) flow=min(flow+.04*dt,1)
 if (spd<3) flow=max(flow-.5*dt)
 if (spd<1.5) idle+=dt if (idle>1.2) chain=0
 if (jbuf>0 and not crouch) dojump() return
 if (xp and spd>=3.5 and not nar) spd*=1.05 trick("slide",0,3) setst"slide" return
 gvel()
 if (not gnd) coy,vy=.1,0 toair() return
 gb=gnd
 local f=flr(aph*2)
 if (f~=lstep and spd>.5) sfx(0)
 lstep=f
 if wall do
  local into=-cos(ang)*wnx-sin(ang)*wnz
  if wall.f&2>0 and iu and into>.5 do
   startclimb()
  elseif spd>1 and canvault(wall) do
   startvault(wall)
  elseif into>.6 and jz and spd>3 do
   wallup(spd*into)
  elseif into>.7 do
   if (spd>5.5) bonk() stun=.3 setst"land"
   spd=0
  elseif into>0 do

   local tx,tz=-wnz,wnx
   if (cos(ang)*tx+sin(ang)*tz<0) tx,tz=-tx,-tz
   ang=atan2(tx,tz)
   spd*=1-into*.5
  end
 end
end

function balance()
 ang+=angd((gb[4]-gb[1]>gb[6]-gb[3] and (cos(ang)>0 and 0 or .5) or (sin(ang)>0 and .75 or .25))-ang)*.15
 balv=balv*.97+((rnd(2)-1)*(1+spd*.8)+bal*2.5-turn*5)*dt
 bal+=balv*dt

 local lx,lz=-sin(ang)*bal,cos(ang)*bal
 px+=lx*.4*dt
 pz+=lz*.4*dt
 if (abs(bal)>1) vx,vy,vz,bal,balv=lx*2,1,lz*2,0,0 brk("slipped",11) toair() return true
end

s.air=function()
 coy-=dt
 if (jbuf>0 and coy>0) dojump() return
 vy=max(vy-g*dt,-30)

 local da=turn*.2*dt
 local c,sn=cos(da),sin(da)
 ang+=da
 vx,vz=vx*c-vz*sn,vx*sn+vz*c
 if (iu and hs()<3.6) vx+=cos(ang)*5*dt vz+=sin(ang)*5*dt
 if (id) vx*=.97 vz*=.97
 pmove()
 peak=max(peak,py)
 if (gnd) land() return
 if (airgrab()) return

 if not wall and jz and hs()>3.2 do

  for sd in all(split"0,.4,-.4,.8,-.8") do
   local b=solid(px-sin(ang)*sd,py+1,pz+cos(ang)*sd)
   if (b and not wall and b~=lastwr and max(b[4]-b[1],b[6]-b[3])>2) wall=b snapface(b,px>b[1] and px<b[4],1)
  end
 end
 if (not wall) return
 local vin,vp=max(-vx*wnx-vz*wnz),vz*wnx-vx*wnz
 if wall.f&2>0 and iu and vin>.5 do

  startclimb()
 elseif jbuf>0 do

  wallkick(vp,max(3.2,vin*.5),"tic-tac")
 elseif jz and abs(vp)>3.2 and abs(vp)>vin*.7 and wall~=lastwr do

  wrs,lastwr=max(abs(vp),hs()*.85),wall
  wrt=.5+wrs*.12
  wrmax,vy,ang=wrt,mid(vy,1+wrs*.25,3.5),atan2(-wnz*vp,wnx*vp)
  trick("wallrun",.1,5)
  setst"wallrun"
 elseif jz and vin>2 and not wupd do
  wallup(vin)
 else
  if (vin>6.5) bonk()
  vx+=wnx*vin vz+=wnz*vin
 end
end

function land()
 local h,hv=peak-py,hs()
 if (hv>.5) ang=atan2(vx,vz)
 spd,gb,coy,wupd,kicks,lastwr=hv,gnd,0,false,0

 if (gb.f&4>0) toair(true) vy=jz and 12.5 or 11 trick("bounce",.1,10) return
 sfx(2)
 if narrow(gb) do
  spd,bal,balv=min(spd,2.5),0,0
  if (h>.6) trick("precision",.08)
  setst"ground"
  return
 end
 if h>1.6 and rbuf>0 do
  if (h<11) spd=max(spd*.95,4) trick("roll",.12,3) setst"roll" return

  h-=4
 end
 if h>4.6 do
  spd*=.15
  stun,shake,heavy,flow=.6,.3,.6,0
  brk("hard landing",8)
  setst"land"
 elseif h>2.6 do
  spd*=.6
  stun,flow=.15,max(flow-.25)
  setst"land"
 else
  spd*=.97
  setst"ground"
 end
end

s.land,s.roll,s.slide,s.vault,s.wallrun=function()
 spd=max(spd-10*dt)
 gvel()
 ph=1.2
 if (stt>stun) setst"ground"
end,function()spd=max(spd-2*dt)ang+=turn*.25*dt gvel()ph=.9if(not gnd)toair()return
if(jbuf>0and stt>.2and not phit(py+.9))dojump()return
if(stt>.45)setst"ground"
end,function()spd=max(spd-1.6*dt)ang+=turn*.15*dt ph=.8gvel()if(not gnd)toair()return
if(jbuf>0and not phit(py+1))dojump()return
if(wall)spd*=.5
if(not xx and stt>.35or spd<2.5)ph=1.8if(phit())ph,spd=.8,max(spd,2.5)else setst"ground"
end,function()local k=min(stt/vdur,1)py,vx,vy,vz=vy0+(vtop+.05-vy0)*k,cos(ang)*vspd*.3,0,sin(ang)*vspd*.3pmove()if(k>=1)spd=vspd vx,vy,vz=cos(ang)*spd,vt==3and 2.5or 1.5,sin(ang)*spd toair()
end,function()wrt-=dt vy-=g*(.05+(1-wrt/wrmax)*.55)*dt wrs=max(wrs-dt)vx,vz=cos(ang)*wrs-wnx,sin(ang)*wrs-wnz pmove()if(gnd)land()return
if(airgrab())return
if jbuf>0do wallkick((vz*wnx-vx*wnz)*.9,4.8,"wall jump")elseif not wall or wrt<=0or xp do vx+=wnx vz+=wnz setst"air"end peak=py end

function wallup(vin)
 wupd=true
 snapface(wall)
 vy=max(vy,4+vin*.7)
 trick("wall climb",.05)
 setst"wallup"
end

s.wallup,s.hang,s.pull=function()
 vx,vy,vz=-wnx*.5,vy-g*dt,-wnz*.5
 pmove()
 peak=max(peak,py)
 if (gnd) land() return
 if (airgrab()) return
 if jbuf>0 do
  wallkick(0,4.5,"wall jump")
 elseif vy<-1.5 or not wall do
  setst"air"
 end
end,function()if(stt<.12)return
if iu and airjump or jbuf>0and not id do startpull()elseif jbuf>0do jumpback()elseif xp do ngrab=.35toair()elseif turn~=0do local ox,oz,b=px,pz,hb px+=sin(ang)*turn*1.4*dt pz-=cos(ang)*turn*1.4*dt local x,z=px+cos(ang)*.6,pz+sin(ang)*.6if(not inside(b,x,z,.1)or phit())px,pz=ox,oz
aph+=dt*1.5end end,function()local k=min(stt/pdur,1)local a=lerp3(pa,pb,max(k*2-1))px,py,pz=a[1],lerp3(pa,pb,min(k*1.6,1))[2],a[3]if(k>=1)spd,gb=hcat and iu and 4or 1setst"ground"
end

function startclimb()
 cb=wall
 local zf=cb[4]-cb[1]>cb[6]-cb[3]
 snapface(cb,zf)
 if (zf) px=mid(cb[1],px,cb[4]) else pz=mid(cb[3],pz,cb[6])
 setst"climb"
 sfx(4)
end

s.climb,q,poses=function()
 local d=(iu and 1 or 0)-(id and 1 or 0)
 py+=d*2.6*dt
 aph+=d*dt*1.2
 if (py+1.9>cb[5]) py=cb[5]-1.9 if (d>0) hb,hcat=cb startpull() return
 if (d<0 and solid(px,py-.05,pz)) setst"ground" spd=0 return
 if jbuf>0 do
  jumpback()
 elseif xp or py<cb[2]-1.5 do
  ngrab=.35
  toair()
 end
end,split"0,0,.93,0,.07,0,.07,0,.1,0,.1,0,0,0",{}
for row in all(split("push;.06,0,.95,-.3,.12,.2,.4,.15,.15,-.1,.15,.04,0|up;.04,0,.95,-.1,.3,.15,.35,.12,.2,.05,.2,.08,0|fall;.02,0,.95,0,.18,.1,.12,.15,.15,.12,.15,.15,0|reach;.04,0,.93,.14,.08,.02,.12,.12,.12,.08,.12,.12,0|slide;-.1,.03,.45,.75,.07,-.05,.07,-.12,.05,.15,.2,.1,0|roll;.15,0,.6,.15,.4,.1,.35,.3,.3,.3,.3,0,0|land;.14,0,.56,.18,.07,-.12,.07,.12,.15,.08,.15,.06,0|v1;.15,0,1,.15,.45,.05,.5,.1,.08,.12,.08,0,0|v2;.1,.08,1,.25,.4,.15,.45,.06,.04,.08,.04,.08,.12|v3;.08,.12,1,.3,.45,.2,.5,.06,.02,.15,.12,.12,.2|cat;0,0,.95,.25,.45,.25,.4,.46,.03,.46,.03,0,0|hang;0,0,.95,.04,.1,-.03,.12,.46,.03,.46,.03,0,0|wallup;.02,0,.95,.3,.4,.24,.15,.38,.12,.42,.12,.05,0|climb;0,0,.95,.2,.3,.2,.3,.42,.1,.42,.1,0,0|pull;0,0,.95,.04,.1,0,.12,.46,.2,.46,.2,0,0","|")) do
 local p=split(row,";",false)
 poses[p[1]]=p[2]
end

function gait(t,h)
 local f=1.1+h*.13

 rt=.75
 aph+=f*dt
 local d=min(.6,.5*f/h)
 local s=h*d/f

 t[3]=sqrt(.757-s*s/4)+.07-(.5-d)*.06*cos(aph*2-d)
 for i=0,1 do
  local p,x,u=(aph+i/2)%1,0,.07
  if (p<d) x=s/2-s*p/d else p=(p-d)/(1-d) x,u=sin(p)*.15-cos(p/2)*s/2,.07-sin(p/2)*(1.3-p)*(.08+h*.025)

  local j=4+i*2
  t[j],t[j+1],t[j+4],t[j+5]=x,u,.03-x*.22,.14+h*.008
 end
 t[1]=.01+h*.004
end

function anim()
 rt=.3

 local h,n,tu=hs(),st=="air" and (vy>0 and (stt<.12 and "push" or "up") or py-shy<1.2 and "reach" or "fall") or st=="vault" and "v"..vt or st=="hang" and hcat and "cat" or st,angd(ang-bang)
 local t=split(poses[n] or "0,0,.93,.04,.07,-.04,.07,.03,.08,.03,.08,.03,0")
 add(t,0)

 bang+=tu*.25
 if st=="ground" do
  if (h>.3) gait(t,h) t[1]+=mid(-.04,(h-oh)*.25,.03) else t[3]+=sin(time()/4)*.004
  if (crouch) t[3]-=.3 t[1]+=.1

  if (lvy<-4) lc=(-lvy-4)*.03
  t[3]-=lc
  if (narrow(gb)) t[8],t[10],t[12],tu=0,0,.25,bal*-.06
 elseif st=="wallrun" do
  gait(t,wrs)

  local w=wnx*sin(bang)-wnz*cos(bang)
  t[2],t[12],t[13]=w*.04,.14,w*.2
 elseif st=="climb" do
  local w=sin(aph)*.12
  t[5]+=w t[7]-=w t[8]-=w/3 t[10]+=w/3
 elseif st=="pull" do

  local k=stt/pdur
  t[1],t[8],t[10]=k*.15,.46-k*.42,.46-k*.42
  if (k>.35) t[6],t[7]=.3,min(hb[5]-py,.5)+.07
 end
 lvy,oh,lc=st=="air" and vy or 0,h,lc*.85

 t[2]-=tu*(h+3)*.12
 if (n=="roll") t[14]=min(stt/.45,1)
 for i=1,13 do q[i]+=(t[i]-q[i])*rt end
 q[14]=t[14]
end

function jp(p)
 local f,u,s=unpack(p)
 local ur=u-q[3]
 f,u=f*pcr+ur*psr,ur*pcr-f*psr+q[3]
 local c={tocam(px+bfx*f-bfz*s,py+u,pz+bfz*f+bfx*s)}
 if (c[3]>near) local p=proj(c) p[3]=c[3] return p
end

function seg(o,a,l,sp,sd)
 return {o[1]-sin(a)*cos(sp)*l,o[2]-cos(a)*cos(sp)*l,o[3]-sin(sp)*sd*l}
end

function spn(t,f,s)
 return {sdf*t+lcf*f,q[3]+sdu*t+lsf*f,sds*t+s+sh}
end

function cap(a,b,r,c)
 if (a and b) add(bp,{(a[3]+b[3])/2,a,b,r,c})
end

function drawplayer()
 local l,sl,hp=q[1],q[2],q[3]
 bfx,bfz,pcr,psr,bp,sdf,sdu,sds,lcf,lsf,sh=cos(bang),sin(bang),cos(q[14]),-sin(q[14]),{},-sin(l),cos(l)*cos(sl),-sin(sl),cos(l),sin(l),(q[5]-q[7])*.06

 if (shy>0) local sc={} for i=0,3 do add(sc,{tocam(px+cos(i/4)*.35,shy+.02,pz+sin(i/4)*.35)}) end cpoly(sc,5)
 local head=jp(spn(.76,0,0))
 if (not head) return

 local cs,lg=(cpos[1]-px)*-bfz+(cpos[3]-pz)*bfx>0 and 1 or -1,{}
 for sd=-1,1,2 do
  local i,nr,h,az=sd<0 and 4 or 6,sd==cs,(q[6]-q[4])*sd*.05,sd*.12+q[13]
  local f,u=q[i]-h,q[i+1]-hp
  local d=max(sqrt(f*f+u*u),.05)
  local x=(.0176+d*d)/2/d
  local y=sqrt(max(.2025-x*x))
  local k,an={h+(x*f-y*u)/d,hp+(x*u+y*f)/d,sd*.15+az/2+sh/2},{h+f,hp+u,az}

  add(lg,{jp{h,hp,sd*.17+sh},jp(k),jp(an),jp{an[1]-(an[2]-k[2])*.46,max(an[2]+(an[1]-k[1])*.46,.02),az},nr})

  local so=spn(.47,0,sd*.24)
  local el=seg(so,q[i+4],.28,q[12],sd)
  local je=jp(el)
  cap(jp(so),je,.065,nr and 8 or 2)
  cap(je,jp(seg(el,q[i+4]+q[i+5],.26,q[12],sd)),.055,15)
 end

 local a,b=lg[1],lg[2]
 if a[1] and b[1] do
  local sg=sgn(b[1][1]-a[1][1])
  for i=1,4 do
   local p,o=a[i],b[i]
   if (p and o) local m=max(.22*fl/p[3]+2-abs(o[1]-p[1]))/2*sg p[1]-=m o[1]+=m
  end
 end
 for g in all(lg) do
  local c=g[5] and 1 or 0
  cap(g[1],g[2],.1,c)
  cap(g[2],g[3],.08,c)
  cap(g[3],g[4],.06,7)
 end

 for p in all{split"0,.04,.15,1,0",split".18,.42,.19,8,0",split".22,.36,.12,5,-.12",split".5,.76,.05,15,0"} do
  cap(jp(spn(p[1],p[5],0)),jp(spn(p[2],p[5],0)),p[3],p[4])
 end

 cap(head,head,.15,15)
 local hb=jp(spn(.78,-.05,0))
 cap(hb,hb,.14,0)

 isort(bp,1)
 for p in all(bp) do
  local a,b,r,c=unpack(p,2)

  local ra,rb=r*fl/a[3],r*fl/b[3]
  for t=0,1,.2 do
   circfill(a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t,ra+(rb-ra)*t,c)
  end
 end
end

function angd(a)
 return (a+.5)%1-.5
end

function camreset()
 cyaw,fl,cam,look=ang,70,{px-cos(ang)*4,py+3,pz-sin(ang)*4},{px,py+1,pz}
 camupd()
end

function camupd()
 local h=hs()
 cyaw+=angd(ang-cyaw)*(st=="hang" and .03 or .05+h*.005)
 local d,fx,fz=2.8+h*.14,cos(cyaw),sin(cyaw)

 local t,w,lk={px,py+1.4,pz},{px-fx*d,py+2.8+h*.04,pz-fz*d},{px+cos(ang)*(1+h*.4),py+.9,pz+sin(ang)*(1+h*.4)}
 if (st=="wallrun") w[1]+=wnx*.9 w[3]+=wnz*.9

 for k=.15,1,.15 do
  if (solid(unpack(lerp3(t,w,k)))) w=k<.55 and {px-fx*.3,py+3,pz-fz*.3} or lerp3(t,w,k-.15) break
 end
 cam,look=lerp3(cam,w,.18),lerp3(look,lk,.2)
 fl+=(72-h*1.7-fl)*.1
 shake=max(shake-dt)
 cpos={cam[1]+rnd(shake)-shake/2,cam[2]+rnd(shake),cam[3]}
 local lx,ly,lz=look[1]-cpos[1],look[2]-cpos[2],look[3]-cpos[3]
 local yaw,pit=atan2(lx,lz),atan2(sqrt(lx*lx+lz*lz),ly)
 ccy,csy,ccp,csp=cos(yaw),sin(yaw),cos(pit),sin(pit)
 cfw={ccy*ccp,csp,csy*ccp}
end

function tocam(x,y,z)
 x-=cpos[1] y-=cpos[2] z-=cpos[3]
 local f=x*ccy+z*csy
 return z*ccy-x*csy,y*ccp-f*csp,f*ccp+y*csp
end

function proj(c)
 local z=c[3]
 c.s=c.s or {64+c[1]*fl/z,64-c[2]*fl/z}
 return c.s
end

near,fr=.2,0

function poly(v,c)
 local l,rr,y0,y1={},{},999,-1
 for i=1,#v do
  local a,b,t=v[i],v[i%#v+1],l
  local ax,ay,bx,by=a[1],a[2],b[1],b[2]
  if (ay>by) ax,ay,bx,by,t=bx,by,ax,ay,rr
  local sl,ya,yb=(bx-ax)/(by-ay),max(ceil(ay)),min(ceil(by)-1,127)
  local x=ax+(ya-ay)*sl
  for y=ya,yb do
   t[y]=x
   x+=sl
  end
  y0,y1=min(y0,ya),max(y1,yb)
 end
 for y=y0,y1 do rectfill(l[y] or 0,y,rr[y] or 0,y,c) end
end

function cpoly(vs,c)
 local o,n={},#vs
 for i=1,n do
  local a,b=vs[i],vs[i%n+1]
  if (a[3]>=near) add(o,proj(a))
  if (a[3]<near~=(b[3]<near)) local t=(near-a[3])/(b[3]-a[3]) local c=lerp3(a,b,t) c[3]=near add(o,proj(c))
 end
 if (#o>2) poly(o,c)
end

function isort(t,k)
 for i=2,#t do
  local p,j=t[i],i-1
  while (j>0 and t[j][k]<p[k]) t[j+1]=t[j] j-=1
  t[j+1]=p
 end
end

function lerp3(a,b,t)
 local v={}
 for i=1,3 do v[i]=a[i]+(b[i]-a[i])*t end
 return v
end

function fp(q,u,t)
 return lerp3(lerp3(q[1],q[4],u),lerp3(q[2],q[3],u),t)
end

function fq(q,u,t,v,w)
 return {fp(q,u,t),fp(q,u,w),fp(q,v,w),fp(q,v,t)}
end

faces,ci,cj,ck,fpat,dpat={split"1,3,7,5",split"1,2,6,5",split"1,3,4,2"},split"1,4,1,4,1,4,1,4",split"2,2,5,5,2,2,5,5",split"3,3,3,3,6,6,6,6",split"0x3333,0x5555,0x7777,0x5a5a",split"0,0xf0f0,0,0x3333,0,0,0,0xa5a5"

function behind(a,b)
 local r
 for i=1,3 do
  local c,s=cpos[i]
  if a[i+3]<=b[i] do
   s=c>=b[i] and 1 or c<=a[i+3] and 0 or 2
  elseif b[i+3]<=a[i] do
   s=c<=b[i+3] and 1 or c>=a[i] and 0 or 2
  end
  if s do
   if (s==2 or r and r~=s) r=2 break
   r=s
  end
 end
 return r==1 or not r and a.d>b.d
end

function render()
 sky()

 plb={px-r,py,pz-r,px+r,py+ph,pz+r}
 dl[#dl]=plb

 local v={}
 for k=1,#dl do
  local b,d,e,f=dl[k],0,0,0
  for i=1,3 do
   local c,m=cpos[i],(b[i]+b[i+3])/2
   d+=abs(m-c)
   e+=max(max(b[i]-c,c-b[i+3]))
   f+=(m-c)*cfw[i]+abs((b[i+3]-b[i])*cfw[i])/2
  end
  b.d,b.e=d,e
  if e<sk[8]+24 and f>near do
   local x0,y0,x1,y1,cs=999,999,-999,-999,{}
   for i=1,8 do
    local c={tocam(b[ci[i]],b[cj[i]],b[ck[i]])}
    cs[i]=c
    if (c[3]<near) x0,y0,x1,y1=-999,-999,999,999 else local s=proj(c) x0,y0,x1,y1=min(x0,s[1]),min(y0,s[2]),max(x1,s[1]),max(y1,s[2])
   end
   b.cs,b.bx=cs,{x0,y0,x1,y1}

   if (x1>=0 and x0<128 and y1>=0 and y0<128) if e<sk[8]+10 do add(v,b) elseif x0>-999 do rectfill(x0,y0,x1,y1,sk[7]) end
  end
 end

 isort(v,"d")
 fr+=1
 local function visit(b)
  if b.mk~=fr do
   b.mk=fr
   local x0,y0,x1,y1=unpack(b.bx)
   for i=1,#v do
    local a=v[i]
    local p=a.bx
    if (a.mk~=fr and p[1]<x1 and p[3]>x0 and p[2]<y1 and p[4]>y0 and behind(a,b)) visit(a)
   end
   if (b==plb) drawplayer() else drawbox(b)
  end
 end
 for b in all(v) do visit(b) end
end

function drawbox(b)
 local m,cs,fog=mats[b.m],b.cs,b.e>sk[8]
 for ax=1,3 do
  local sd=cpos[ax]>b[ax+3] and 1 or 0
   if cpos[ax]<b[ax] or sd==1 do
    local q={}
    for k in all(faces[ax]) do add(q,cs[k+sd*(ax==3 and 4 or ax)]) end
    local c=ax==2 and sd==1 and m[1] or m[ax==1 and 2 or 3]
    if (fog) fillp(23130) c+=sk[7]*16
    cpoly(q,c)
    fillp()

    if (ax~=2 and not fog and stat(1)<.9) deco(b,m[5],q,c)
   end
 end
end

function deco(b,dk,q,c)
 local h,t,k=b[5]-b[2],dk%16,dk\16
 if t==1 and h>3 do
  fillp(fpat[flr(b[1]+b[3])%3+1])
  for y=1.4,h-1.2,3 do
   cpoly(fq(q,.06,y/h,.94,(y+1.3)/h),c+k*16)
  end
 elseif t==3 and h>1.5 do
  fillp(fpat[b.k%4+1])
  cpoly(fq(q,.08,.15,.92,.85),split"0xa9,0x7c,0xeb,0xb3"[b.k%4+1])
 elseif t==5 do
  fillp(3855)
  cpoly(fq(q,.2,.25,.8,.75),c+k*16)
 elseif t==7 do
  for i=1,2 do
   local a,e=q[i],q[i+2]
   if (a[3]<near or e[3]<near) return
   a,e=proj(a),proj(e)
   line(a[1],a[2],e[1],e[2],k)
  end
 elseif t>0 do
  fillp(dpat[t])
  cpoly(q,c+k*16)
 end
 fillp()
end

function sky()
 local hy=mid(-20,64+fl*csp/ccp,150)
 cls(sk[1])
 fillp(23130)
 rectfill(0,hy-34,127,hy-18,sk[1]+sk[2]*16)
 fillp()
 rectfill(0,hy-18,127,hy,sk[2])
 if (sk[6]>0) circfill(64-angd(.1-atan2(ccy,csy))*fl*6,hy-30,7,sk[6])

 rectfill(0,hy,127,127,sk[5])
end
__gfx__
0100000000000000000000000000000000102038405068708098a0b8485890f0c090d0005000d0810000e060d05040303010819040205560505070d0505000a0
909020a0a09040b030308340402000c0c01040000000000000000000000000d0000000904020425a000bff0bff00000f8087e009100bff00000f800ae007300b
ff00000a800ae082500bff0000c8800ae0cfff0bff0100208287100000c90001008c82201000000bff01008c82201000000bff06008c208710800081000100c0
c001b000004bff010002c0e4d006004bff0100604065740b004bff8100402065500b00c5000100404020400f00000001006050819403100fff010081c0823409
004bff010001c065d402000800e2000b10e040e10048000100100160600700850001008050809007008600010080a0809001000600010081c0e1d108108bff01
00c0c007b1861087000300c0c001b10a10080001000341a0f00220080001000341a0a00a20080001000341a0f00c108500010002a0a0a003208500010002a0a0
f009208500010002a0a0a00b10850001008050a0900f1081000100c0508034852000000100804002900c200fffa1004020c2500c200fff0100405020400c2044
0001004050204009100800830001c0a0d200308bff0100c0c0c9b20130490001007203022008308a000100028202200e300cff0100028202200e200800830001
c0a0d30530080043000b20a0500530860043000b202050053086000100402141400d308600010040214140044086000100402141408a408600010040214140e4
3028000100104160600c3006000400402082500140c70083006040a0340640060004004020c1500c300600010040812040064006000100408120400830060083
0081c0c1d4094008008300c0c0a0b3094066008300c0c040b309408bff0100c0c045b30b4003008000c34020408c40c7000000a0b1c0208e40870063004710e0
7e8e40c700000040b1a0400650c700000040b1a0408c50c700000040b1a0400350670001006041106008400600830081c0c1d50e500600010002028220ed5007
000100100260608b50c70083008050a0908e508600050081c002b40a0004100000c087c020032009100000c00ac010014086100000c0c8c0200a5004100000c0
46c0100e1001ff0000c087c020064001ff0000c007c01000000f0000000a0405100d20041000008705051004600bff000005840a100d500b00c4004120c9400d
500c000000206220404f500c000000206220400d5004100000206220404f5004100000206220400d500d100000206220404f500d1000002062204002500f0000
0088800ce08350821001000303c4200a50002001008242c2200e508510a500c01030504f5085100500205030400d5089100500414040348f500c100100c10185
100d508e10c2000320c0400d508e10010020e0c040e260022001001001606000600220030041c041b50050072000008981491000500720030087822010c26007
20030020824910005049300300898220100050072003002082061000508630030020828110005007200800892049108f500a200300a14040748f508e20a300a1
1040508f508e2003001050404009500920030042c0043084508c2003008101c230055005300300405022944050873065004910e0400160673003006041106080
600a20e700801001a003508630e700011040a08b508330030081c081b602400d2000000780c7e0034081300100850182100540863001004101c0100e400330e2
00011040400a4005300300c1a0a0f003408e2001008001606002408c3000008f80c0e001608c3000000180c0e002400e3000008e8006e0034008300100858207
200640e7300300608110608a408630030041c0c0308a40873084004150403084400b30060004c0c1b70e408340c500892001500e400140e500891020508e4001
40010020624240065001400100206242400f500140010020624240045083400600404001340a508340a600401001500a504540010040d2204005508c30010082
81c1200c508640010002c1c12001608c3000008e808ce001600240c4008820c17e01600240010020e1c14088600240010020e1c14080700240010020e1c14081
60e140010060021060047002400100c34181f089600240050043c081b8047007400100c44285100770e640830060011060047005400100804101100670054001
008141011085700b408500c340403486708840850082c001b901600b4001008843451002700e4065000110014002708e408500100160600c600b402800401004
500c600b408700405020400c60c25087004050204005608b4087004040c3340e500f4067008110014005500c400000840505100e500f40870010416060855083
500a0043c080a002608e408700c2c0c1ba07508d400a0082c002c000000000000000000000000000000000000000000000000000000000000000000000000000
__sfx__
000300001e62500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
00020000164311d430224250000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000300000e64508625000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000400002062424630216250000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
00020000282352d225000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000300001a6251c6151a6251c61500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0005000024040280402b0403004500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000200001c63522625000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
000500000a665066550c0530000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0007000024540285402b540305502b530305550000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0003000014041200412c0350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
00050000123530c345000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
0010200007235072050720507205072050720507205072050e2350720507205072050720507205072050720507235072050720507205072050720507205072050e23507205072050720507205072050720507205
0010200007235072050720507205072050720507205072050e2350720507205072050720507205072050720507235072050720507205072050720507205072050e23507205072050720507205072050720507205
001020000f2350f2050f2050f2050f2050f2050f2050f205162350f2050f2050f2050f2050f2050f2050f2050f2350f2050f2050f2050f2050f2050f2050f205162350f2050f2050f2050f2050f2050f2050f205
001020000c2350c2050c2050c2050c2050c2050c2050c205132350c2050c2050c2050c2050c2050c2050c2050c2350c2050c2050c2050c2050c2050c2050c205132350c2050c2050c2050c2050c2050c2050c205
000f200007235072050720507205072350720507205072050e2350720507205072050723507205072050720507235072050720507205072350720507205072050e23507205072050720507235072050720507205
000f200007235072050720507205072350720507205072050e2350720507205072050723507205072050720507235072050720507205072350720507205072050e23507205072050720507235072050720507205
000f20000f2350f2050f2050f2050f2350f2050f2050f205162350f2050f2050f2050f2350f2050f2050f2050f2350f2050f2050f2050f2350f2050f2050f205162350f2050f2050f2050f2350f2050f2050f205
000f20000c2350c2050c2050c2050c2350c2050c2050c205132350c2050c2050c2050c2350c2050c2050c2050c2350c2050c2050c2050c2350c2050c2050c205132350c2050c2050c2050c2350c2050c2050c205
0010200007235072050720507205072350720507205072050e2350720507205072050723507205072050720507235072050720507205072350720507205072050e23507205072050720507235072050720507205
0010200007235072050720507205072350720507205072050e2350720507205072050723507205072050720507235072050720507205072350720507205072050e23507205072050720507235072050720507205
001020000f2350f2050f2050f2050f2350f2050f2050f205162350f2050f2050f2050f2350f2050f2050f2050f2350f2050f2050f2050f2350f2050f2050f205162350f2050f2050f2050f2350f2050f2050f205
001020000c2350c2050c2050c2050c2350c2050c2050c205132350c2050c2050c2050c2350c2050c2050c2050c2350c2050c2050c2050c2350c2050c2050c205132350c2050c2050c2050c2350c2050c2050c205
000e200007235072050720507205072350720507205072050e2350720507205072050723507205072350720507235072050720507205072350720507205072050e23507205072050720507235072050723507205
000e200007235072050720507205072350720507205072050e2350720507205072050723507205072350720507235072050720507205072350720507205072050e23507205072050720507235072050723507205
000e20000f2350f2050f2050f2050f2350f2050f2050f205162350f2050f2050f2050f2350f2050f2350f2050f2350f2050f2050f2050f2350f2050f2050f205162350f2050f2050f2050f2350f2050f2350f205
000e20000c2350c2050c2050c2050c2350c2050c2050c205132350c2050c2050c2050c2350c2050c2350c2050c2350c2050c2050c2050c2350c2050c2050c205132350c2050c2050c2050c2350c2050c2350c205
0010200013325133051330513305133051330513305133051a3251a3051a3051a30516325163051630516305133051330513305133051b3251b3051b3051b3051a3251a3051a3051a30515305153051530515305
00102000133251330513305133051a3051a3051a3051a30516325163051630516305133251330513305133051b3051b3051b3051b3051a3251a3051a3051a3051532515305153051530513305133051330513305
00102000223252230522305223051f3051f3051f3051f3051b3251b3051b3051b30524325243052430524305223052230522305223051d3251d3051d3051d3051b3251b3051b3051b3051b3051b3051b3051b305
001020001b3251b3051b3051b30518305183051830518305213252130521305213051f3251f3051f3051f3051a3051a3051a3051a30518325183051830518305183251830518305183051f3051f3051f3051f305
00102000163251630516305163051f3051f3051f3051f3051d3251d3051d3051d3051832518305183051830511305113051130511305113251130511305113051832518305183051830515305153051530515305
001020001f3251f3051f3051f3051d3051d3051d3051d305183251830518305183051632516305163051630511305113051130511305183251830518305183051532515305153051530511305113051130511305
0010200026325263052630526305213052130521305213051f3251f3051f3051f3051f3251f3051f3051f305213052130521305213051d3251d3051d3051d3051a3251a3051a3051a30522305223052230522305
001020001d3251d3051d3051d3051b3051b3051b3051b3051b3251b3051b3051b305223252230522305223051a3051a3051a3051a305163251630516305163051f3251f3051f3051f3051d3051d3051d3051d305
000f20001a3251a3051a3051a30516305163051632516305133251330513305133051b3051b3051b3251b3051a3051a3051a3251a305153051530515305153051332513305133051330513325133051330513305
000f200016325163051630516305133051330513325133051b3251b3051b3051b3051a3051a3051a3251a3051530515305153251530513305133051330513305133251330513305133051a3251a3051a3051a305
000f20001b3251b3051b3051b30524305243052432524305223252230522305223051d3051d3051d3251d3051b3051b3051b3251b3051b3051b3051b3051b305223252230522305223051f3251f3051f3051f305
000f2000213252130521305213051f3051f3051f3251f3051a3251a3051a3051a30518305183051832518305183051830518325183051f3051f3051f3051f3051b3251b3051b3051b30518325183051830518305
000f20001d3251d3051d3051d3051830518305183251830516325163051630516305163051630516325163051830518305183251830515305153051530515305113251130511305113051a3251a3051a3051a305
000f20001832518305183051830516305163051632516305163251630516305163051d3051d3051d3251d30515305153051532515305113051130511305113051a3251a3051a3051a30518325183051830518305
000f20001f3251f3051f3051f3051f3051f3051f3251f30526325263052630526305223052230522325223051a3051a3051a3251a30522305223052230522305213252130521305213051b3251b3051b3051b305
000f20001b3251b3051b3051b305223052230522325223051f3251f3051f3051f3051b3051b3051b3251b3051f3051f3051f3251f3051d3051d3051d3051d3051832518305183051830516325163051630516305
001020001f3251f3051f3051f3052730527305273052730526305263052632526305213052130521305213051f3251f3051f3051f3051f3051f3051f3251f3052630526305263052630522325223052230522305
001020002732527305273052730526305263052630526305213052130521325213051f3051f3051f3051f3051f3251f3051f3051f30526305263052632526305223052230522305223051f3251f3051f3051f305
001020002e3252e3052e3052e3052930529305293052930527305273052732527305273052730527305273052e3252e3052e3052e3052b3052b3052b3252b3052730527305273052730530325303053030530305
001020002632526305263052630524305243052430524305243052430524325243052b3052b3052b3052b30527325273052730527305243052430524325243052d3052d3052d3052d3052b3252b3052b3052b305
00102000223252230522305223052230522305223052230529305293052932529305263052630526305263051d3251d3051d3051d30526305263052632526305243052430524305243051f3251f3051f3051f305
001020002232522305223052230529305293052930529305263052630526325263052230522305223052230526325263052630526305243052430524325243051f3051f3051f3051f3051d3251d3051d3051d305
00102000323253230532305323052e3052e3052e3052e3052b3052b3052b3252b305333053330533305333052d3252d3052d3052d305273052730527325273052630526305263052630526325263052630526305
001020002b3252b3052b3052b30527305273052730527305303053030530325303052e3052e3052e3052e30524325243052430524305223052230522325223052230522305223052230529325293052930529305
000e20001a3251a3051a3051a3051532515305153251530513305133051330513305133251330513305133051a3251a3051a3051a30516325163051630516305133051330513325133051b3251b3051b3051b305
000e20001532515305153051530513325133051332513305133051330513305133051a3251a3051a3051a30516325163051630516305133251330513305133051b3051b3051b3251b3051a3251a3051a3051a305
000e20001b3251b3051b3051b3051b3251b3051b3251b305223052230522305223051f3251f3051f3051f3051b3251b3051b3051b30524325243052430524305223052230522325223051d3251d3051d3051d305
000e2000183251830518305183051f3251f3051f3251f3051b3051b3051b3051b30518325183051830518305213252130521305213051f3251f3051f3051f3051a3051a3051a3251a30518325183051830518305
000e20001d3251d3051d3051d3051a3251a3051a3251a305163051630516305163051f3251f3051f3051f30518325183051830518305133251330513305133051130511305113251130511325113051130511305
000e20001a3251a3051a3051a305163251630516325163051f3051f3051f3051f3051d3251d3051d3051d30513325133051330513305113251130511305113051130511305113251130518325183051830518305
000e20001f3251f3051f3051f3052732527305273252730526305263052630526305213252130521305213051a3251a3051a3051a3051a3251a3051a3051a305213052130521325213051d3251d3051d3051d305
000e200024325243052430524305223252230522325223051d3051d3051d3051d3051b3251b3051b3051b305163251630516305163051d3251d3051d3051d3051a3051a3051a3251a30516325163051630516305
001020001202300000346150000000000000003461500000120230000034615000000000000000346150000012023000003461500000000000000034615000001202300000346150000000000000003461500000
000f20001203300000346150000000000000003461500000120330000034615000000000000000346150000012033000003461500000000000000034615000001203300000346150000000000000003461500000
001020001203300000000000000000000000000000000000120330000000000000000000000000000000000012033000000000000000000000000000000000001203300000000000000000000000000000000000
000e20001203300000000000000000000000000000000000120330000000000000000000000000000000000012033000000000000000000000000000000000001203300000000001203300000000000000000000
__music__
01 1c0c3c40
00 1d0d3c40
00 1e0e3c40
00 1f0f3c40
00 200c3c40
00 210d3c40
00 220e3c40
02 230f3c40
01 24103d40
00 25113d40
00 26123d40
00 27133d40
00 28103d40
00 29113d40
00 2a123d40
02 2b133d40
01 2c143e40
00 2d153e40
00 2e163e40
00 2f173e40
00 30143e40
00 31153e40
00 32163e40
02 33173e40
01 34183f40
00 35193f40
00 361a3f40
00 371b3f40
00 38183f40
00 39193f40
00 3a1a3f40
02 3b1b3f40
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
00 40404040
__label__
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
cccc777c777c777c7c7cc777777c777cccccccccccccccccccccccccccccccccccc50505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
cccc7c7c7c7c7c7c7c7c777777777c7ccccccccccccccccccccccccccccccccccc550505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
cccc777c777c77cc77c77777777777cccccccccccccccccccccccccccbcccccccc550505000ccccccccccccccccccccccccccccccccccccccccccccccccccccc
6c6c7c6c7c7c7c7c7c7777777777777c6c6c6c6c6c6c6c6c6c6c6c6cbbbc6c6c6c550505000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c676c6767676767677777777777776c6c6c6c6c6c6c6c6c6c666c6cbc6c6c6c65505050006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6c6c6c6c6c6c6c67777777777777776c6c6c6c6c6c6c6c6c66666c6c6c6c6c6c555505000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6c6c6c6c6c6c6c777777777777777c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c65555050006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6caaac6c6cac6caaa7a7a7aaa7a7776aac6c6c6aacaaac6c66aaacac6c6aacaca55505000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6a6a6c6c6a6c6a777a7a7a777a777a6c6c6c6a6a6a6c6c6c6a6c6a6c6a6a6a6a555050006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6caaac6c6cac6caa77a7a7aa77a777aaac6c6cacacaa6c6c66aa6cac6cacacaca55505000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6a6a6c6c6a6c6a677aaa7a777a776c6a6c6c6a6a6a6c6c6c6a6c6a6c6a6a6aaa550050006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6caaac6c6caaacaaa77a77aaa7aaacaa6c6c6caa6cac6c6c66a66caaacaa6caaa55005000c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6c6c6c6c6c6c6c6c77777777777c6c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c655500500c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6c6c6c6c6c6c6c6c6c777777777c6c6c6c6c6c6c6c6c6c6c66666c6c6c6c6c6c555005006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
c6c6c6c6c6c6c6c6c6c6c6777776c6c6c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c655500500c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c66666c6c6c6c6c6c555005006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c
6666c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c655500500c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6666666666666
66666c6c6c6c6c6c6666666666666c6c6c6c6c6c6c6c6c6c6c66666c6c6c6c6c6c555005006c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c666666666666
6666c6c6c6c6c6c666666666666666c6c6c6c6c6c6c6c6c6c6c666c6c6c6c6c6c655500500c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6666666666666
66666666666666666666666666666666666666666666666666666666666666666655500500666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666655500500666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666655505500666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666655505500666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666655505500666666666666666666666666666666666666666666666666666666
6666666666666666666666666666666666666666666666666660a906666666666655505500666666666666666666666666666666666666666666666666666666
6666666666666666666666666666666666666666666666666660a906666666666655505500666666666666666666666666666666666666666666666666666666
6666666666666666666666666666666666666666666666666660a9006666666666555055006666666666666dddddddd666666666666666666666666666666666
6666666666666666666666666666666666666666666666666660a9009666666666555055006666666666666dddddddd66666666666666666dddddddd66666666
6666666666666666666666666666666666666666666666666660a9009966666666555055006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660a9009966666666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660a9009906666666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660a9009900666666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660aa009900666666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660aa009900966666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666666666666666666666666660aa009900966666555050006666666666666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666646464646464646464646460aa009900946464555050006464646464666dddddddd66666666666666666dddddddd66666666
666666666666ddddddddd6666666664646464646464646464640aa009900964646555050004646464646466dddddddd66666666666666666dddddddd66666666
6666666666666666666666666666646464646464646464646460aa00990094646455505004646464646466666666666666666666666666666666666666666666
6666666666666666666666666666664646464646464646464640aa00990096464655505006464646464646666666666666666666666666666666666666666666
6666666666666666666666666666666464646464646464646460aa00990094646455505004646464646466666666666666666666666666666666666666666666
4444444444444444444444444444444646464646464646464640aa00990096464655505006464646464644444444444444444444444444444444444444444444
4444444444444444444444444444446464646464646464646464aa00990094646455505004646464646464444444444444444444444444444444444444444444
4444444444444444444444444444444646464646464646464646aa00990096464655505006464646464644444444444444444444444444444444444444444444
4444444444444444444444444444446464646464646464636363aa00990094646455505004646464646444444444444444444444444444444444444444444444
4444444444444444444444444444444646464646464646463636aa00990096464655505006464646464644444444444444444444444444444444444444444444
4444444444444444444444444666666666666666666666666666aa00990096666655505006666666666666644444444444444444444444444444444444444444
444444444444444444444446d6d6d6d6d6d6d6d6d6d6d6d6d6d6aa0099009444445550500449d6d6d6d6d6d6d444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990044444455505004449944466666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990044444445505004444994466666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990044444445505004444499466666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990444444444505004444444996666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00990444444444505004444444499666666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00994444444444505004444444449996666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00994444444444505004444444444999666444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00944444400044445004444444464449996444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00944444000004445004444444466444999444444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00944444000004455004444444466644499944444444444444444444444444444444444444
4444444444444444444444466666666666444444444444444444aa00444444000004455004444444466664449999444444444444444444444444444444444444
44444444444444444444444666666666664444444444444444444444444444f000f4455004444444466666444499944444444444444444444444444444444444
444444444444444444444446666666666644444444444444444444444444444fff44455004444444466666664449999444444444444444444444444444444444
44444444444444444444444666666666664444444444444444444444444444488844455004444444466666666444999944444444444444444444444444444444
44444444444444444444444666666666664444444444444444444444444244888884844444444444466666666444499999444444444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228855588884444444444466666666444444999944444444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228555558884444444444466666666444444499994444444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228555558884444444444466666666444444449999944444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228555558888444444444466666666444444444999994444444444444444444444444
44444444444444444444444666666666664444444444444444444444442228555558484444444444466666666444444444449999944444444444444444444444
4444444444444444444444466666666666444444444444444444444444f248555558444444444444466666666444444444444999994444444444444444444444
44444444444444444444444666666666664444444444444444444444444448855588444444444444466666666444444444444499999944444444444444444444
44444444444444444444444666666666664444444444444444444444444440111111444444444444466666666444444444444449999994444444444444444444
44444444444444444444444666666666664444444444444444444444444400111111144444444444466666666444444444444444499999444444444444444444
66666666666666666666666666666666666666666666666666666666666000111111666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666000611111166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666606666611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666000666611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666000666661666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666600066611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666660666611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666600066661666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666600066611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666660666611166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666555561666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666665555511166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666555555511166666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666665555555711556666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666655555111666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666665555516666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666555566666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
