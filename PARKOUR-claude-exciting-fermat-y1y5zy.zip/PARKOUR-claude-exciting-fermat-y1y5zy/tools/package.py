"""Bundle the playable local cartridge set, instructions and current previews."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from levels import CARTRIDGES

ROOT = Path(__file__).resolve().parents[1]


def package():
    files = [ROOT / (name + extension)
             for name in ["parkour_menu", "parkour"] + CARTRIDGES
             for extension in (".p8", ".p8.png")]
    files += [ROOT / "README.md"]
    files += [ROOT / "docs" / name for name in
              ("construction-contrast.png", "levels.png", "expanded-levels.png", "verification.md")]
    assert all(p.is_file() for p in files), 'Build and verify the release first'
    destination = ROOT / "parkour-cartridges.zip"
    with ZipFile(destination, "w", ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, path.relative_to(ROOT).as_posix())
    with ZipFile(destination) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(files)
    print(destination)
    return destination


if __name__ == '__main__':
    package()
