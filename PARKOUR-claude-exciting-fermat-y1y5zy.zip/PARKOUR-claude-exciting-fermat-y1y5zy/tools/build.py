#!/usr/bin/env python3
"""Build a menu and eight self-contained PICO-8 cartridges.

    python tools/build.py              # validate and publish all carts + PNGs
    python tools/build.py construction # build just one playable level
    python tools/build.py --draft       # fast unminified carts in .tools/draft

Each cart contains the unchanged shared parkour engine, its own geometry,
local hints and a 32-phrase score. Geometry uses gfx/map/flag memory only;
all sound and music memory remains available for that level's arrangement.
"""
import argparse
import importlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import p8mem
from hints import HINTS
from levels import ORDER, CARTRIDGES, CAMPAIGN
from music import score

MODULES = ["main", "level", "collide", "parkour", "player", "anim",
           "camera", "render", "fx"]
REGIONS = [(0x0010, 0x3100)]
HINT_STARTS = [0, 14, 21, 27, 32, 39, 44, 50, len(HINTS)]


def level_blob(mod, boxes=None, events=None):
    """Palette(16), sky(11), materials(15x4), count(2), boxes(10 each)."""
    out = bytearray(mod.PALETTE.get(i, i) for i in range(16))
    sky = list(mod.SKY)
    sky[8] = 0  # all hint IDs are local to this cartridge
    out += bytes(sky)
    for m in range(1, 16):
        out += bytes(mod.MATS.get(m, (0, 0, 0, 0)))
    if boxes is None or events is None:
        level_data = mod.build()
        boxes = level_data.boxes if boxes is None else boxes
        events = level_data.events if events is None else events
    out += struct.pack("<h", len(boxes))
    for (x0, y0, z0, x1, y1, z1, m, k) in boxes:
        dims = [(x1 - x0) * 4, (y1 - y0) * 4, (z1 - z0) * 4]
        for v in dims:
            assert v == int(v) and 0 < v < 256, (mod.NAME, x0, y0, z0, x1, y1, z1)
        for v in (x0, y0, z0):
            assert v * 8 == int(v * 8) and -32768 <= v * 8 < 32768, (mod.NAME, x0, y0, z0)
        assert 1 <= m <= 15 and 0 <= k <= 15, (mod.NAME, m, k)
        out += struct.pack("<hhhBBBB", int(x0 * 8), int(z0 * 8), int(y0 * 8),
                           *map(int, dims), m | (k << 4))
    assert len(events) < 256
    out.append(len(events))
    solids = sum(b[6] not in (11, 12, 13) for b in boxes)
    for ref, kind, axis, travel, duration, dwell, radius, delay in events:
        assert 1 <= ref <= solids and 1 <= kind <= 7 and 1 <= axis <= 3
        assert travel * 8 == int(travel * 8) and -32768 <= travel * 8 < 32768
        times = (duration * 4, dwell * 4, radius, delay * 4)
        assert duration > 0 and all(v == int(v) and 0 <= v <= 255 for v in times)
        out += struct.pack("<HBBhBBBB", ref, kind, axis, int(travel * 8), *map(int, times))
    return out, len(boxes)


# sfx: (speed, [(pitch, wave, vol, fx), ...])
SFX = [
    (3, [(30, 6, 2, 5)]),                                   # 0 footstep
    (2, [(22, 4, 3, 1), (29, 4, 3, 0), (34, 4, 2, 5)]),     # 1 jump
    (3, [(14, 6, 4, 5), (8, 6, 2, 5)]),                     # 2 land
    (4, [(32, 6, 2, 4), (36, 6, 3, 0), (33, 6, 2, 5)]),     # 3 roll/slide
    (2, [(40, 2, 3, 5), (45, 2, 2, 5)]),                    # 4 grab/kick
    (3, [(26, 6, 2, 5), (28, 6, 1, 5), (26, 6, 2, 5), (28, 6, 1, 5)]),  # 5 wallrun
    (5, [(36, 0, 4, 0), (40, 0, 4, 0), (43, 0, 4, 0), (48, 0, 4, 5)]),  # 6 checkpoint
    (2, [(28, 6, 3, 5), (34, 6, 2, 5)]),                    # 7 vault
    (5, [(10, 6, 6, 5), (6, 6, 5, 5), (12, 0, 5, 3)]),      # 8 hard landing
    (7, [(36, 5, 4, 0), (40, 5, 4, 0), (43, 5, 4, 0), (48, 5, 5, 0),
         (43, 5, 3, 0), (48, 5, 5, 5)]),                    # 9 finish
    (3, [(20, 0, 4, 1), (32, 0, 4, 1), (44, 0, 3, 5)]),     # 10 bounce
    (5, [(18, 3, 5, 3), (12, 3, 4, 5)]),                    # 11 bonk/fall
]



def sound_rom(rom, level):
    sounds, patterns = score(level)
    sounds.update(enumerate(SFX))
    for sid, (speed, notes) in sounds.items():
        assert 0 <= sid < 64 and 0 < speed < 256 and len(notes) <= 32
        address = p8mem.SFX + sid * 68
        rom[address + 64:address + 68] = bytes((0, speed, 32 if sid >= 12 else 0, 0))
        for n, (pitch, wave, volume, effect) in enumerate(notes):
            assert 0 <= pitch < 64 and 0 <= wave < 8 and 0 <= volume < 8 and 0 <= effect < 8
            value = pitch | wave << 6 | volume << 9 | effect << 12
            struct.pack_into("<H", rom, address + n * 2, value)
    for i in range(64):
        flags, channels = patterns[i] if i < len(patterns) else (0, [0x40] * 4)
        for channel, sid in enumerate(channels):
            rom[p8mem.MUSIC + i * 4 + channel] = sid | ((flags >> channel) & 1) << 7


def source(name):
    return Path(ROOT, "src", name + ".lua").read_text(encoding="utf-8").rstrip()


def quote(value):
    return json.dumps(value, ensure_ascii=False)


def shrinko():
    default = os.path.join(ROOT, ".tools", "shrinko8")
    if not os.path.isdir(default):
        default = "/tmp/shrinko8"
    tool = os.path.join(os.environ.get("SHRINKO8", default), "shrinko8.py")
    if not os.path.isfile(tool):
        raise SystemExit("shrinko8 is required to validate the PICO-8 budget; set SHRINKO8")
    return tool


def minify(path):
    """Keep global names for diagnostics; validate every native cart limit."""
    tool = shrinko()
    subprocess.run([sys.executable, tool, path, path, "-m", "-ot", "--no-minify-rename",
                    "--no-minify-spaces", "--no-minify-lines"], check=True)
    report = subprocess.check_output([sys.executable, tool, path, "--count", "--parsable-count"], text=True)
    for line in report.splitlines():
        if line.startswith("count:"):
            _, _, name, value, limit = line.split(":")
            if int(value) > int(limit):
                raise SystemExit("PICO-8 %s budget exceeded: %s / %s; previous cartridge retained" % (name, value, limit))
    return report


def write_cart(path, code, rom, draft=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    sections = p8mem.rom_to_sections(rom)
    lines = ["pico-8 cartridge // http://www.pico-8.com", "version 42", "__lua__", code]
    for name in ("gfx", "gff", "map", "sfx", "music"):
        lines += ["__%s__" % name] + sections[name]
    label = Path(ROOT, "tools", "label.txt")
    if label.is_file():
        lines += ["__label__"] + label.read_text().split()
    staged = str(path) + ".building.p8"
    Path(staged).write_text("\n".join(lines) + "\n", encoding="utf-8")
    if not draft:
        minify(staged)
        subprocess.run([sys.executable, shrinko(), staged, staged + ".png"], check=True)
        os.replace(staged + ".png", str(path) + ".png")
    os.replace(staged, path)
    return str(path)


def build_level(level, out_path=None, draft=False):
    """Build one level; level is its original zero-based index or cart name.

    Returns (path, [(display_name, box_count, geometry_bytes)], free_bytes).
    draft=True avoids minification/PNG export for fast headless iteration.
    """
    if isinstance(level, str):
        level = CARTRIDGES.index(level)
    assert 0 <= level < len(ORDER)
    mod = importlib.import_module("levels." + ORDER[level])
    boxes = mod.build().boxes
    checkpoints = [b[7] for b in boxes if b[6] == 11]
    assert checkpoints.count(0) == 1, "one spawn checkpoint required"
    assert max(checkpoints) <= 15, "checkpoint IDs occupy four bits"
    hints = list(getattr(mod, "HINTS", HINTS[HINT_STARTS[level]:HINT_STARTS[level+1]]))
    assert len(hints) <= 16
    for box in boxes:
        if box[6] == 13:
            assert box[7] < len(hints), (mod.NAME, "undefined local hint", box[7])
    blob, count = level_blob(mod, boxes)
    start, end = REGIONS[0]
    if len(blob) > end - start:
        raise SystemExit("%s geometry exceeds dedicated cart data memory: %d / %d" %
                         (mod.NAME, len(blob), end - start))
    rom = bytearray(p8mem.ROM_END)
    struct.pack_into("<H", rom, 0, start)
    rom[start:start+len(blob)] = blob
    sound_rom(rom, level)
    position = CAMPAIGN.index(level)
    next_level = CAMPAIGN[position + 1] if position < 7 else -1
    nextcart = CARTRIDGES[next_level] if next_level >= 0 else "parkour_menu"
    header = "\n".join(("cart_lv=%d" % level, "cart_cp=%d" % max(checkpoints),
                         "next_lv=%d" % next_level,
                         "lname=" + quote(mod.NAME), "nextcart=" + quote(nextcart + ".p8"),
                         "hints=split(" + quote("|".join(hints)) + ',"|")'))
    code = "\n-->8\n".join([header] + [source(m) for m in MODULES])
    out_path = out_path or os.path.join(ROOT, ".tools/draft" if draft else "", CARTRIDGES[level] + ".p8")
    path = write_cart(out_path, code, rom, draft)
    return path, [(mod.NAME, count, len(blob))], end - start - len(blob)


def build_menu(out_path=None, draft=False):
    out_path = out_path or os.path.join(ROOT, ".tools/draft" if draft else "", "parkour_menu.p8")
    return write_cart(out_path, source("menu"), bytearray(p8mem.ROM_END), draft)


def build_all(draft=False):
    # Validate the complete release before replacing any distributed files.
    staging = Path(ROOT, ".tools", "draft" if draft else "cart-build")
    staging.mkdir(parents=True, exist_ok=True)
    results = [build_level(i, staging / (name + ".p8"), draft)
               for i, name in enumerate(CARTRIDGES)]
    build_menu(staging / "parkour_menu.p8", draft)
    if not draft:
        for name in CARTRIDGES + ["parkour_menu"]:
            for extension in (".p8", ".p8.png"):
                shutil.copyfile(staging / (name + extension), Path(ROOT, name + extension))
        # Compatibility entry point is the same launcher, never an old
        # combined game with different physics or outdated geometry.
        for extension in (".p8", ".p8.png"):
            shutil.copyfile(Path(ROOT, "parkour_menu" + extension), Path(ROOT, "parkour" + extension))
        results = [(str(Path(ROOT, CARTRIDGES[i] + ".p8")), stats, free)
                   for i, (_, stats, free) in enumerate(results)]
    return results


def build(out_path=None, level=0, draft=False):
    """Compatibility helper: build a single playable cart (Old City default)."""
    return build_level(level, out_path, draft)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("level", nargs="?", choices=CARTRIDGES)
    parser.add_argument("--draft", action="store_true")
    args = parser.parse_args()
    results = [build_level(args.level, draft=args.draft)] if args.level else build_all(args.draft)
    for path, stats, free in results:
        name, boxes, size = stats[0]
        print("%-18s %4d boxes %5d data bytes %5d free -> %s" % (name, boxes, size, free, path))
