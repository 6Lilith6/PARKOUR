"""Locations of the independently playable level cartridges (zero based)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NAMES = ("old_city", "construction", "factory", "subway", "downtown",
         "neon", "mountain", "megastructure")


def cart_path(level=0):
    return str(ROOT / (NAMES[level] + ".p8"))
