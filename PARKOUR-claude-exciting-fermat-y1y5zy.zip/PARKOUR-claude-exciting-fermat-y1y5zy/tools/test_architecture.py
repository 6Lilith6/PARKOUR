"""Authored-world checks: no unsupported static geometry, including scenery.

These check geometric attachment, not engineering load capacity. Thin facade
balconies may cantilever, but each component must connect through another solid
to a ground foundation. Check both travel endpoints for construction/traffic.
"""
import importlib

from levels import ORDER


def unsupported(boxes):
    solids = [b for b in boxes if b[6] not in (11, 12, 13)]
    unseen = set(range(len(solids)))
    islands = []
    while unseen:
        component = {unseen.pop()}
        pending = list(component)
        while pending:
            a = solids[pending.pop()]
            linked = {i for i in unseen if all(
                a[k] <= solids[i][k + 3] and a[k + 3] >= solids[i][k]
                for k in range(3))}
            unseen -= linked
            component |= linked
            pending.extend(linked)
        if not any(solids[i][1] <= 0 for i in component):
            islands.append([solids[i] for i in component])
    return islands


def run():
    for name in ORDER:
        module = importlib.import_module('levels.' + name)
        boxes = module.build().boxes
        for phase in (0, 1):
            posed = []
            for box in boxes:
                b = list(box)
                if b[6] not in (11, 12, 13) and b[7] in (12, 13, 15):
                    axis, travel = {12: (2, 12), 13: (1, 4), 15: (2, 8)}[b[7]]
                    b[axis] += phase * travel
                    b[axis + 3] += phase * travel
                posed.append(b)
            loose = unsupported(posed)
            assert not loose, (module.NAME, phase, loose)
        print(module.NAME + ': all solids attach to foundations at both travel endpoints')


if __name__ == '__main__':
    run()
