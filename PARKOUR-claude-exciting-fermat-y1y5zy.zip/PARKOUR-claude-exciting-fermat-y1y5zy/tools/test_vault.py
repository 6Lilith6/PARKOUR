#!/usr/bin/env python3
"""Cartridge-level parkour regression tests using the headless PICO-8 sim.

Fixtures isolate action intent from authored routes. Run with the same
Python/lupa environment as tools/playtest.py, after tools/build.py.
"""
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".tools" / "python"))
from sim import Pico


class VaultTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pc = Pico(str(ROOT / "old_city.p8"))

    def setUp(self):
        self.pc.g.respawn()
        self.pc.L.execute("""
          function box(x0,y0,z0,x1,y1,z1,k)
           local b={x0,y0,z0,x1,y1,z1,m=3,f=1,k=k or 0}
           add(boxes,b) return b
          end
          boxes={} trig={}
          floor=box(-20,0,-20,20,2,40)
          obstacle=box(-1,2,2,1,3,3,4)
          px,py,pz,ang=0,2,1.699,.75
          vx,vy,vz,spd=0,0,5,5
          wnx,wnz=0,-1
          iu,xx,jz,jzp,xp,id=true,false,false,false,false,false
          gnd,gb,wall=floor,floor,obstacle
          st,mode,jbuf,coy,turn,airjump="ground","play",0,0,0,nil
          nearupd()
        """)
        self.pc.held = self.pc.prev = set()

    def lua(self, code):
        self.pc.L.execute(code)

    def can_vault(self):
        return bool(self.pc.g.canvault(self.pc.g.obstacle))

    def test_supported_low_barrier(self):
        self.assertTrue(self.can_vault())

    def test_forward_intent_required(self):
        for setting in ("iu=false", "xx=true", "jbuf=.1", "ang=0"):
            with self.subTest(setting=setting):
                self.setUp()
                self.lua(setting)
                self.assertFalse(self.can_vault())

    def test_airborne_or_no_ground_never_vaults(self):
        for setting in ('st="air"', "gnd=nil", 'st="wallup"'):
            with self.subTest(setting=setting):
                self.setUp()
                self.lua(setting)
                self.assertFalse(self.can_vault())

    def test_unmarked_landing_surfaces_and_moving_objects(self):
        for arg in (0, 1, 2, 3, 12, 13, 14, 15):
            with self.subTest(arg=arg):
                self.lua(f"obstacle.k={arg}")
                self.assertFalse(self.can_vault())

    def test_height_and_base_must_describe_ground_obstacle(self):
        for setting in ("obstacle[5]=2.5", "obstacle[5]=3.5",
                        "obstacle[2]=0", "obstacle[2]=2.5"):
            with self.subTest(setting=setting):
                self.setUp()
                self.lua(setting)
                self.assertFalse(self.can_vault())

    def test_depth_and_width_reject_landing_shapes_even_if_tagged(self):
        for setting in ("obstacle[6]=5", "obstacle[1]=-.25 obstacle[4]=.25"):
            with self.subTest(setting=setting):
                self.setUp()
                self.lua(setting)
                self.assertFalse(self.can_vault())

    def test_balance_beam_cannot_chain_into_vault(self):
        self.lua("floor[1]=-.25 floor[4]=.25")
        self.assertFalse(self.can_vault())

    def test_gap_after_barrier_requires_real_jump(self):
        self.lua("floor[6]=3")
        self.assertFalse(self.can_vault())

    def test_partial_footing_beyond_barrier_is_not_a_landing(self):
        self.lua("floor[6]=3.5")
        self.assertFalse(self.can_vault())

    def test_overhead_and_exit_clearance(self):
        for bounds in ("-2,4,1,2,4.5,4", "-2,3.8,2.1,2,4.2,2.8",
                       "-2,2,3.2,2,2.5,4"):
            with self.subTest(bounds=bounds):
                self.setUp()
                self.lua(f"box({bounds}) nearupd()")
                self.assertFalse(self.can_vault())

    def test_obstacle_crossable_from_both_axes_and_sides(self):
        cases = (
            "pz=3.301 ang=.25 wnz=1",
            "obstacle[1],obstacle[3],obstacle[4],obstacle[6]=2,-1,3,1 px,pz,ang,wnx,wnz=1.699,0,0,-1,0",
            "obstacle[1],obstacle[3],obstacle[4],obstacle[6]=2,-1,3,1 px,pz,ang,wnx,wnz=3.301,0,.5,1,0",
            "obstacle[1],obstacle[4]=-4,4 ang=.875",
        )
        for setting in cases:
            with self.subTest(setting=setting):
                self.setUp()
                self.lua(setting)
                self.assertTrue(self.can_vault())

    def test_running_crosses_authored_obstacle(self):
        states = []
        for _ in range(100):
            self.pc.step(["up"])
            states.append(self.pc.g.st)
        self.assertIn("vault", states)
        self.assertGreater(self.pc.g.pz, 7)

    def test_jump_input_wins_over_auto_vault(self):
        self.pc.step(["up", "z"])
        self.assertEqual(self.pc.g.st, "air")
        self.assertTrue(self.pc.g.airjump)

    def test_rising_jump_or_no_wall_contact_never_get_air_assistance(self):
        for setting in ("jz=true vy=1", "wall=nil vy=-1"):
            with self.subTest(setting=setting):
                self.setUp()
                self.lua('st="air" obstacle[6]=5 ' + setting)
                self.assertFalse(self.pc.g.airgrab())
                self.assertEqual(self.pc.g.st, "air")

    def test_small_precision_target_never_air_vaults_or_mantles(self):
        self.lua('st="air" jz=true vy=-1')
        self.assertFalse(self.pc.g.airgrab())
        self.assertEqual(self.pc.g.st, "air")

    def test_broad_ledge_rescue_mantle_has_separate_state(self):
        self.lua('st="air" airjump=true jz=false vy=-1 obstacle[6]=5')
        self.assertTrue(self.pc.g.airgrab())
        self.assertEqual(self.pc.g.st, "pull")
        self.assertEqual(self.pc.g.pop, "mantle")

    def test_broad_ledge_behind_abutting_thin_fascia_can_mantle(self):
        self.lua('''
          st="air" airjump=true vy=-1 obstacle[6]=2.25
          box(-1,2,2.25,1,3,5) nearupd()
        ''')
        self.assertTrue(self.pc.g.airgrab())
        self.assertEqual(self.pc.g.st, "pull")

    def test_high_ledge_rescue_catch_preserved(self):
        self.lua('st="air" jz=false vy=-1 obstacle[5]=4 obstacle[6]=5')
        self.assertTrue(self.pc.g.airgrab())
        self.assertEqual(self.pc.g.st, "hang")

    def test_walk_off_cannot_mantle_the_next_broad_platform(self):
        self.lua('st="air" airjump=nil vy=-1 obstacle[6]=5')
        self.assertFalse(self.pc.g.airgrab())
        self.assertEqual(self.pc.g.st, "air")

    def test_walk_off_rescue_hangs_until_explicit_climb_input(self):
        self.lua('st="air" airjump=nil vy=-1 obstacle[5]=4 obstacle[6]=5')
        self.assertTrue(self.pc.g.airgrab())
        self.lua('stt=.2 s.hang()')
        self.assertEqual(self.pc.g.st, "hang")
        self.lua('jbuf=.1 s.hang()')
        self.assertEqual(self.pc.g.st, "pull")

    def test_vault_and_walk_off_reset_jump_intent(self):
        self.lua('airjump=true toair()')
        self.assertFalse(self.pc.g.airjump)

    def test_precision_landing_uses_collision_not_vault(self):
        self.lua('''
          boxes={} floor=box(-2,0,-3,2,2,0)
          obstacle=box(-.4,0,2,.4,2.5,2.75,4)
          px,py,pz,ang=0,3,2.1,.75
          vx,vy,vz=0,-2,0
          st,peak,gnd,gb="air",3.5,nil,nil
          nearupd()
        ''')
        states = []
        for _ in range(18):
            self.pc.step([])
            states.append(self.pc.g.st)
        self.assertNotIn("vault", states)
        self.assertNotIn("pull", states)
        self.assertEqual(self.pc.g.st, "ground")
        self.assertAlmostEqual(self.pc.g.py, 2.5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
