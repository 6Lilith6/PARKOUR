"""LEVEL 5 - DOWNTOWN

Glass offices, a shopping street, rooftop gardens, a parking garage and a
setback tower. Style: URBAN VERTICAL FLOW - street furniture and vehicles
are the first steps up:
  street -> car roof -> van -> awning -> balcony -> fire escape -> roof
  -> cable / skybridge -> next building -> garage -> tower

  street   safe: fire escape ladders right at the start | normal: taxi,
           van, awning bounce, balcony, ladder or run up to the podium
           roof | west: parked car, low awning, shop roofs
  cross    skybridge roof | cable from the shop roofs (balance) | the
           canopy in front of the next office
  office   rooftop playground: AC units, skylight, planters, penthouse,
           water tank, billboard
  garage   top deck: weave between the cars or hop the car roofs
  tower    three 4m setbacks: ladder | AC units / window-washer gondola |
           wall run-up; goal on the crown
"""
from .common import *

NAME = "downtown"
PALETTE = {14: 140, 9: 137, 3: 139}
SKY = (12, 6, 13, 1, 5, 7, 6, 28, 32, 192, 22)
MATS = {
    A: (6, 13, 13, 0x11),     # stone offices, sidewalks
    B: (5, 4, 2, 0x11),       # brick shops
    PROP: (6, 13, 5, 0x55),   # AC units, van
    BEAM: (5, 0, 0, 0),       # fire escapes, balconies
    TRIM: (6, 5, 5, 0),       # rails, cables, canopies
    CLIMB: (6, 5, 5, 0x02),   # galvanized fire escapes
    SIGN: (5, 7, 6, 0x03),    # billboards, bus
    BOUNCE: (8, 8, 2, 0x78),  # striped awnings
    WOOD: (3, 4, 4, 0),       # planters
    GLASS: (13, 12, 14, 0x11),  # glass offices
    DARK: (5, 5, 0, 0),       # asphalt, garage
    ACCENT: (14, 14, 1, 0x05),  # cars
}


def build():
    L = Level()
    box, P = L.box, L.prop
    # ---------- street (z -10..44) ----------
    box(-14, 0, -10, 40, 2, 46, DARK)
    box(-14, 0, 46, 40, 2, 100, DARK)
    box(-14, 0, 100, 40, 2, 140, DARK)
    box(0, 2, -6, 3, 2.25, 44, A)                     # sidewalks
    box(13, 2, -6, 16, 2.25, 44, A)
    box(-12, 2, -10, 30, 14, -6, B)                   # street end
    box(-12, 2, -6, 0, 6.5, 18, B)                    # shops W1
    box(-12, 2, 18, 0, 10.5, 44, B)                   # shops W2
    box(16, 2, -6, 30, 11, 44, A)                     # office podium
    box(22, 11, -6, 30, 30, 20, GLASS)                # office tower
    L.cp(6, 2, 0, 9, 3, 0)
    L.hint(3, 2, -6, 13, 5, 0)
    # safe: fire escape
    box(13.75, 6.25, 2, 16, 6.5, 8, BEAM)
    box(14, 2.25, 1.75, 15.5, 6.5, 2, CLIMB)
    box(15.75, 6.5, 6, 16, 11, 7.5, CLIMB)
    # normal: taxi -> van -> awning -> balcony -> ladder
    box(9.5, 2, 6, 11.5, 3.5, 10, ACCENT)             # taxi
    box(10.5, 2, 11, 13, 4.25, 17.5, PROP)            # van
    box(12, 4.75, 19, 16, 5, 23, BOUNCE)               # awning
    box(13.5, 7.25, 25, 16, 7.5, 33, BEAM)            # balcony
    box(13.5, 10.75, 33, 16, 11, 39, BEAM)            # fire escape top
    box(14, 7.5, 32.75, 15.5, 11, 33, CLIMB)
    # One bus pulls forward eight metres below the balcony. Its broad roof
    # offers a timed shortcut; fixed ladders and shop roofs remain available.
    box(9.5, 2, 26, 12.5, 5.5, 41, SIGN, 15)
    box(5.5, 2, 38, 8.5, 4.75, 44, PROP)             # delivery truck at loading bay
    box(5.5, 2, 44, 8.5, 4, 46, GLASS)               # truck cab
    box(0, 6.75, 38, 3, 7, 44, BOUNCE)               # west shop loading canopy
    box(0, 9, 43, 2.5, 9.25, 46, BEAM)              # escape landing fixed to W2
    box(0, 7, 43, .25, 9.25, 44.5, CLIMB)            # canopy -> escape
    L.hint(6, 2, 5, 13, 11, 1)
    # west: parked car -> low awning -> shop roofs
    box(3, 2, 3, 5, 3.5, 7, ACCENT)
    box(0, 4.25, 8, 2.5, 4.5, 12, BOUNCE)
    P(-5, 4, 6.5, 2, 1.5, 1.25)                       # AC units
    P(-9, 11, 6.5, 1.5, 2, 1.25)
    box(-3, 6.5, 16, -1, 8.25, 18, PROP)              # step to W2
    box(-8, 10.5, 30, -6, 12, 32, PROP)
    box(-7, 11.75, 36, -1, 15.75, 36.25, SIGN, 2)           # billboard: slide
    for x in (-7, -1.25):
        box(x, 10.5, 36, x + .25, 11.75, 36.25, BEAM)
    # podium roof garden
    box(17, 11, 10, 19, 11.75, 16, WOOD)
    P(18, 20, 11, 2, 1.5, 1.25)
    box(16, 12.25, 24, 22, 12.5, 24.5, TRIM)          # pergola: slide
    box(16, 11, 24, 16.25, 12.25, 24.5, TRIM)
    box(21.75, 11, 24, 22, 12.25, 24.5, TRIM)
    box(23, 11, 26, 28, 11.75, 32, GLASS)             # skylight: jump onto or go around
    box(24, 11, 36, 28, 12.25, 38, PROP)
    L.hint(16, 11, 0, 22, 8, 2)

    # ---------- cross street (z 44..50) ----------
    box(18, 8, 44, 22, 10.75, 49, GLASS)              # skybridge
    box(-2.25, 10.25, 44, -2, 10.5, 49, TRIM)         # cable
    box(-12, 10.75, 49, 30, 11, 52, A)                # canopy
    L.hint(-12, 10.5, 40, 0, 44, 3)
    L.cp(-12, 11, 49, 30, 52, 1)
    # canopy -> office roof (14)
    box(19, 11, 51.75, 20.5, 14, 52, CLIMB)
    P(-3, 50.5, 11, 2, 1.5, 1.25)
    box(6, 11, 50.25, 8.5, 11.75, 51.75, WOOD)

    # ---------- office 2 roof playground (z 52..76) ----------
    box(-12, 2, 52, 30, 14, 76, GLASS)
    box(2, 14, 60, 10, 17.5, 68, B)                   # penthouse
    box(4, 14, 59.75, 5.5, 17.5, 60, CLIMB)
    P(10, 61, 14, 2, 2.5, 1.25)
    box(14, 14, 57, 20, 14.75, 63, GLASS)             # skylight
    box(-9, 14, 56, -7, 14.75, 64, WOOD)              # planters
    box(-4, 14, 58, 0, 14.75, 59.5, WOOD)
    P(22, 56, 14, 3, 2, 1.25)
    L.tank(23, 66, 14, A)                              # water tank
    box(-11, 15.25, 70, -3, 19.25, 70.25, SIGN, 3)      # billboard: slide
    for x in (-11, -3.25):
        box(x, 14, 70, x + .25, 15.25, 70.25, BEAM)
    box(-2, 14, 66, 0, 15.5, 70, PROP)
    box(14, 15.25, 68, 23, 15.5, 68.5, TRIM)          # feed pipe into water tank
    box(14, 14, 68, 14.25, 15.25, 68.5, TRIM)
    L.hint(-12, 14, 52, 30, 56, 4)

    # ---------- parking garage (z 76..112), deck 11 ----------
    box(-8, 2, 76, 24, 10.5, 112, DARK)
    box(-8, 10.5, 76, 24, 11, 112, A)
    for x in (-8, 23.75):
        box(x, 11, 80, x + .25, 12, 112, TRIM)        # parapets
    for z in (82, 90, 98):                            # car rows
        box(-5, 11, z, -3, 12.25, z + 4, ACCENT)
        box(3, 11, z + 2, 5, 12.25, z + 6, PROP)
        box(13, 11, z, 15, 12.25, z + 4, ACCENT)
    box(18, 11, 92, 24, 14, 98, B)                    # stair house
    box(17.75, 11, 93, 18, 14, 94.5, CLIMB)
    box(8, 12.5, 88, 11, 12.75, 88.25, TRIM)          # barrier arm
    box(8, 11, 88, 8.25, 12.5, 88.25, BEAM)         # barrier pedestal
    for z in (86, 102):
        box(9, 11, z, 9.25, 15, z + .25, TRIM)        # lamp posts
    L.cp(-8, 11, 77, 24, 80, 2)
    L.hint(-8, 11, 80, 24, 86, 5)

    # ---------- setback tower (z 112..134) ----------
    box(-8, 2, 112, 24, 15, 134, GLASS)               # base, top 15
    box(2, 15, 118, 18, 19, 134, GLASS)               # setback, top 19
    box(6, 19, 124, 14, 23, 134, GLASS)               # crown, top 23
    box(9.75, 23, 131, 10.25, 30, 131.5, TRIM)        # antenna
    L.cp(-8, 11, 106, 24, 111.5, 3)
    L.hint(-8, 11, 106, 24, 111.5, 6)
    # 11 -> 15
    box(0, 11, 111.75, 1.5, 15, 112, CLIMB)
    box(8, 13, 110, 11, 13.25, 112, WOOD)             # gondola
    for x in (8, 10.75):
        box(x, 13.25, 111.75, x + .25, 15, 112, TRIM)
    box(8, 15, 111.75, 11, 15.25, 112.5, BEAM)       # roof-mounted gondola davit
    # 15 -> 19
    box(3, 15, 117.75, 4.5, 19, 118, CLIMB)
    P(9, 114, 15, 2.5, 2, 1.25)                       # AC steps
    box(9, 15, 116, 11.5, 17.5, 118, PROP)
    # 19 -> 23
    box(7, 19, 123.75, 8.5, 23, 124, CLIMB)
    box(8.5, 21, 121.5, 11.5, 21.25, 124, WOOD)       # gondola
    for x in (8.5, 11.25):
        box(x, 21.25, 123.75, x + .25, 23, 124, TRIM)
    box(8.5, 23, 123.75, 11.5, 23.25, 124.5, BEAM)
    L.cp(6, 23, 125, 14, 133, 4)

    # ---------- skyline ----------
    box(40, 0, 0, 52, 60, 12, GLASS)
    box(-40, 0, 60, -28, 50, 72, A)
    box(40, 0, 70, 55, 45, 85, GLASS)
    box(-34, 0, 110, -20, 40, 124, A)
    box(32, 0, 120, 46, 55, 134, GLASS)
    box(-10, 0, 150, 8, 62, 166, GLASS)
    expand_downtown(L)
    return L


def expand_downtown(L):
    """An office crossing and descent to a second street, followed by a high return.

    The city changes scale six times; the high route looks back onto the shops
    crossed at street level. Existing transport is retained as the rare moving set piece.
    """
    b = L.box
    # 1. Crown -> annex -> a lower office interior. Glass walls explain the route.
    b(14, 21.5, 128, 20, 23, 131, GLASS)
    b(20, 0, 122, 28, 23, 138, GLASS)
    b(18, 0, 141, 36, 19, 183, A)
    b(18, 19, 141, 22, 27, 141.5, GLASS)
    b(28, 19, 141, 36, 27, 141.5, GLASS)
    # The pane is a physical surface until a real fast approach breaks it.
    # Jumping through retains velocity and feeds directly into the desk vault.
    pane = b(22, 19, 141, 28, 24, 141.25, GLASS)
    L.event(pane, 4, 2, 0, .5, 0, 1, 0)
    b(35.5, 19, 141, 36, 27, 183, GLASS)
    b(18, 19, 182.5, 36, 27, 183, GLASS)
    b(18, 19, 141, 18.5, 27, 170, GLASS)
    b(18, 19, 177, 18.5, 27, 183, GLASS)
    b(18, 27, 141, 36, 27.5, 183, A)
    b(22, 19, 152, 30, 20, 153, PROP, 4)  # reception counter, not a floating hurdle
    b(29, 19, 158, 35.5, 23, 166, A)     # central office rooms divert the line west
    b(18.5, 20.25, 164, 29, 20.5, 164.5, TRIM)
    b(18.5, 19, 164, 18.75, 20.25, 164.5, TRIM)
    b(22, 26.75, 146, 26, 27, 148, GLASS)
    door = b(18, 19, 170, 18.25, 22, 177, WOOD)
    L.event(door, 5, 3, 7, .75, 0, 5, 0)
    L.cp(21, 19, 145, 28, 149, 5)
    # 2. Enclosed office bridge opens onto a residents' roof garden.
    b(6, 17.5, 171, 18, 19, 176, GLASS)
    b(6, 19, 171, 18, 20, 171.25, TRIM)
    b(6, 19, 175.75, 18, 20, 176, TRIM)
    b(-18, 0, 168, 6, 19, 195, A)
    b(-12, 19, 180, -4, 23, 188, B)  # stair housing creates two garden lines
    b(-16, 19, 171, -15, 20, 183, WOOD, 4)
    b(-8, 19, 172, -3, 19.75, 173.5, WOOD)
    b(-40, 0, 172, -22, 16, 195, B)
    # A short apartment is a real interior, reached through the east window:
    # living room -> kitchen -> passage -> bedroom -> fire-escape balcony.
    b(-40, 16, 172, -22, 22, 172.5, B)
    b(-40, 16, 172, -39.5, 22, 195, B)
    b(-22.5, 16, 172, -22, 22, 175, B)
    b(-22.5, 16, 181, -22, 22, 195, B)
    b(-40, 16, 194.5, -35, 22, 195, B)
    b(-29, 16, 194.5, -22, 22, 195, B)
    b(-40, 22, 172, -22, 22.5, 195, A)
    b(-30, 16, 172.5, -29.5, 21, 176, A)
    b(-30, 16, 181, -29.5, 21, 188, A)
    b(-39.5, 16, 185, -35, 21, 185.5, A)
    b(-29.5, 16, 174, -24, 16.75, 175.5, WOOD)  # living-room sofa
    b(-37, 16, 173, -31, 17, 174.5, PROP, 4)   # kitchen worktop
    b(-38, 16, 189, -35, 16.75, 193, WOOD)     # bedroom bed
    b(-33, 16, 184, -31, 16.75, 185, WOOD, 4)  # corridor cabinet
    b(-22, 15.75, 190, -18, 16, 192, BEAM)  # lower residents' bridge, safe drop route
    b(-18.25, 16, 190, -18, 19, 192, CLIMB)
    L.cp(-37, 16, 176, -25, 181, 6)
    # 3. Fire escape returns to a real service street, with forgiving large landings.
    b(-42, 0, 195, -4, 2, 246, DARK)
    for z, h in ((195, 12), (199, 8), (203, 4)):
        b(-36, h-.25, z, -28, h, z+4, BEAM)
        b(-36, 2, z, -35.75, h-.25, z+.25, BEAM)
        b(-28.25, 2, z+3.75, -28, h-.25, z+4, BEAM)
        b(-34, h, z-.25, -32.5, h+4, z, CLIMB)
    b(-40, 2, 211, -38, 2.25, 246, A)  # curb
    b(-21, 2, 208, -19, 2.25, 239, A)
    # 4. Parked delivery traffic -> canopy -> the shops above the same street.
    b(-19, 2, 204, -5, 10, 239, B)
    truck = b(-31, 2, 209, -27, 4.5, 217, PROP)
    L.event(truck, 1, 3, 3, 4, 3, 18, 1)
    cab = b(-31, 2, 217, -27, 3.75, 219, ACCENT)
    L.event(cab, 1, 3, 3, 4, 3, 18, 1)
    b(-26, 2, 218, -24, 3.5, 222, ACCENT)
    b(-24, 5.25, 220, -19, 5.5, 226, TRIM)
    b(-23, 2, 220, -22.75, 5.25, 220.25, BEAM)
    b(-19.25, 5.5, 222, -19, 10, 223.5, CLIMB)
    b(-19.25, 2, 234, -19, 10, 235.5, CLIMB)  # slower street fire escape
    b(-17, 10, 215, -13, 11.25, 218, PROP, 4)
    b(-15, 11.25, 228, -5, 11.5, 228.5, TRIM)
    for x in (-15, -5.25):
        b(x, 10, 228, x+.25, 11.25, 228.5, TRIM)
    L.cp(-17, 10, 232, -7, 236, 7)
    # 5. Atrium gardens turn west and then east across two roof levels.
    b(-40, 0, 242, -8, 14, 262, A)
    b(-17, 9.75, 239, -12, 10, 242, BEAM)
    b(-15, 10, 241.75, -13.5, 14, 242, CLIMB)
    b(-35, 14, 245, -26, 18, 255, GLASS)  # skylight, usable top but no forced vault
    b(-21, 14, 249, -12, 15, 250, WOOD, 4)
    b(-8, 13.5, 254, -4, 14, 258, BEAM)
    b(-4, 0, 242, 18, 14, 268, A)
    b(-8, 13.75, 248, -4, 14, 248.5, TRIM)  # optional balanced utility crossing
    b(2, 15.25, 250, 2.5, 15.5, 266, TRIM)
    for z in (250, 265.75):
        b(2, 14, z, 2.5, 15.25, z+.25, TRIM)
    b(18, 0, 242, 56, 18, 261, GLASS)
    b(17.75, 14, 255, 18, 18, 256.5, CLIMB)
    b(24, 18, 244, 25, 19, 258, PROP, 4)
    b(37, 19.25, 247, 38, 19.5, 259, TRIM)
    b(37, 18, 247, 38, 19.25, 247.5, BEAM)
    b(37, 18, 258.5, 38, 19.25, 259, BEAM)
    L.cp(29, 18, 250, 35, 257, 8)
    # 6. Drop to the multi-storey car park and descend to the transport plaza.
    b(40, 0, 265, 64, 11.5, 292, DARK)
    b(40, 11.5, 265, 64, 12, 292, A)
    for x, z in ((42, 271), (53, 274), (43, 284), (56, 284)):
        b(x, 12, z, x+2.5, 13.25, z+5, ACCENT)
    b(59, 12, 267, 63, 15, 272, B)
    b(55, 12, 287, 56, 13, 292, PROP, 4)
    b(64, 0, 256, 107, 2, 308, DARK)
    # The parking ramp is stepped at half-metre intervals, always structural.
    for i in range(20):
        b(64+i, 2, 279, 65+i, 12-i*.5, 285, A)
    b(84, 2, 277, 106, 2.5, 287, A)
    b(89, 2.5, 285, 106, 3, 286, A)
    b(89, 0, 286, 106, 3, 302, A)
    b(103.5, 3, 286, 104, 6, 302, GLASS)
    b(90, 3, 300, 104, 6, 302, GLASS)
    b(96, 3, 289, 97, 4, 299, PROP, 4)  # station entrance desk
    # The final station canopy is a real run-up above the tracks. Climb the
    # side ladder, sprint east, then make the roof landing under your control.
    b(89, 5.75, 287, 104, 6, 302, TRIM)
    b(98, 3, 286.75, 99.5, 6, 287, CLIMB)
    b(97.5, 3, 282, 100, 3.5, 287, A)
    b(104, 0, 284, 115, 2, 328, DARK)
    for x in (109.5, 111.75):
        b(x, 2, 284, x+.25, 2.25, 328, BEAM)
    train = b(109, 2, 290, 112.5, 5.5, 307, SIGN)
    L.event(train, 1, 3, 12, 6, 1, 40, 0)
    # The visible billboard frame is an optional higher take-off/wallrun line.
    b(97, 6, 300.5, 97.25, 10, 300.75, BEAM)
    b(103, 6, 300.5, 103.25, 10, 300.75, BEAM)
    b(97, 7, 300.5, 104, 10, 300.75, SIGN)
    L.cp(58, 12, 279, 64, 285, 9)
    L.cp(98, 6, 289, 103, 296, 10)
    L.goal(109, 5.5, 290, 112.5, 320, k=1)
