"""Shared level-building helpers.

Units are metres, y is up. Every object is an axis-aligned box
(x0, y0, z0, x1, y1, z1, material, arg). Material ids are fixed across
levels (their colours and surface detail are per level):

  1 A  main structure      2 B  secondary structure   3 PROP small props
  4 BEAM steel/iron         5 TRIM pipes, rails, slabs 6 CLIMB fixed climb fixtures
  7 SIGN boards/signs       8 BOUNCE awnings/nets      9 WOOD timber
 10 GLASS                  11 CP checkpoint (arg=n)   12 GOAL
 13 HINT (arg=text)        14 DARK structure          15 ACCENT

For solid boxes arg=4 explicitly marks a low vault obstacle. Unmarked boxes
are never auto-vaulted. Args 12..15 identify transport: service train (+12z),
hoist (+4y), stationary conveyor (carries +x), street bus (+8z). Trigger args
retain their checkpoint/hint meaning. Args 0..3 can select sign decoration.
"""

A, B, PROP, BEAM, TRIM, CLIMB, SIGN, BOUNCE, WOOD, GLASS, CP, GOAL, HINT, DARK, ACCENT = range(1, 16)


class Level:
    def __init__(self):
        self.boxes = []
        self.events = []
        self.solid_count = 0

    def box(self, x0, y0, z0, x1, y1, z1, m, k=0):
        self.boxes.append((x0, y0, z0, x1, y1, z1, m, k))
        if m not in (CP, GOAL, HINT):
            self.solid_count += 1
            return self.solid_count

    def event(self, box_ref, kind, axis=2, travel=0, duration=2,
              dwell=2, radius=8, delay=1):
        """A world-only set piece on an existing physical body.

        box_ref is the solid index returned by box(), axes are 1=x,2=y,3=z.
        Kinds: shuttle, behind-runner crumble, weak floor, glass, door,
        rockfall, sign-light dip. Movement times are seconds; the engine
        never performs a scripted player jump or removes steering.
        """
        assert box_ref is not None and 0 < box_ref <= self.solid_count
        self.events.append((box_ref, kind, axis, travel, duration, dwell, radius, delay))

    def bldg(self, x0, z0, x1, z1, h, m=A, y0=0):
        self.box(x0, y0, z0, x1, y0 + h, z1, m)

    def tall(self, x0, z0, x1, z1, h, m=A, y0=0):
        """building taller than 63.75m: stacked boxes"""
        while h > 0:
            s = min(h, 60)
            self.box(x0, y0, z0, x1, y0 + s, z1, m)
            y0, h = y0 + s, h - s

    def prop(self, x, z, y, w=1.5, d=1, h=1, m=PROP, k=4):
        # Authored obstacles only. Roofs, beams and landing decks use box()
        # without this flag; dimensions alone must never imply a vault.
        self.box(x, y, z, x + w, y + h, z + d, m, k)

    def tank(self, x, z, y, m=WOOD):
        for dx in (0, 2.75):
            for dz in (0, 2.75):
                self.box(x + dx, y, z + dz, x + dx + .25, y + 2, z + dz + .25, m)
        self.box(x - .25, y + 2, z - .25, x + 3.25, y + 4.5, z + 3.25, m)

    def cp(self, x0, y, z0, x1, z1, k):
        self.box(x0, y, z0, x1, y + 3, z1, CP, k)

    def hint(self, x0, y, z0, x1, z1, k):
        self.box(x0, y, z0, x1, y + 3, z1, HINT, k)

    def goal(self, x0, y, z0, x1, z1, k=0):
        self.box(x0, y, z0, x1, y + 3, z1, GOAL, k)
