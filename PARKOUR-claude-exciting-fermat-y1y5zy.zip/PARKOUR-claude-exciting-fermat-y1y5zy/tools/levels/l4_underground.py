"""LEVEL 4 - UNDERGROUND

A working station, maintenance tunnel and pump hall, not a platform course.
The continuous west platform is the safe line. Three stationary carriages
create a faster roof route with real coupling gaps; the adjacent service
train is a single optional moving set piece (k=12, shared 0..12m z motion).
A lit service portal and its cross-track gantry point all lines into the
tunnel. Maintenance walks, equipment housings and a wall ladder climb to
the upper gallery; the final stair and exit sign remain visible on approach.
"""
from .common import *

NAME = "underground"
PALETTE = {12: 129, 6: 134, 13: 133, 10: 135, 3: 131, 11: 139, 4: 132}
SKY = (0, 0, 0, 0, 0, 0, 0, 14, 27, 192, 0)
MATS = {
    A: (6, 13, 13, 0x58),     # concrete floors
    B: (13, 3, 3, 0x51),      # tiled walls, ad bands
    PROP: (9, 4, 2, 0x55),    # benches, signal boxes, vents
    BEAM: (7, 5, 1, 0x07),    # lit steel tops contrast with dirty concrete platforms
    TRIM: (13, 5, 5, 0),      # pipes, ducts, cables
    CLIMB: (10, 9, 9, 0x02),
    SIGN: (11, 11, 3, 0x03),
    WOOD: (4, 4, 2, 0),
    GLASS: (10, 10, 10, 0x75),  # light strips
    DARK: (5, 0, 0, 0),       # track bed, columns
    ACCENT: (6, 9, 9, 0xa1),  # train, lit windows
}


def build():
    L = Level()
    box, P = L.box, L.prop
    # ---------- station A: platform / parked cars / passing service train ----------
    box(-1, 0, -1, 23, 2, 55, DARK)                   # ballast and foundation
    box(0, 2, 0, 9, 3.25, 40, A)                      # platform W
    box(13, 2, 0, 17, 3.25, 54, A)                    # island platform
    box(21, 2, 0, 22, 3.25, 54, A)                    # east service walk
    box(-1, 2, 0, 0, 9, 40, B)
    box(22, 2, 0, 23, 9, 55, B)
    box(-1, 2, -1, 23, 9, 0, B)
    box(-1, 9, -1, 23, 9.5, 55, B)                    # ceiling
    box(-1, 2, 40, 9, 9, 41, B)                       # end walls
    box(17, 2, 54, 23, 9, 55, B)                      # siding buffer wall
    box(13, 2, 53, 17, 9, 54, B)                      # service passage turns west
    for z in (12, 28):
        box(7, 3.25, z, 8, 9, z + 1, DARK)            # columns
        box(14, 3.25, z, 15, 9, z + 1, DARK)
    box(2, 3.25, 12, 3, 4.25, 15, PROP, 4)            # actual low benches
    box(15, 3.25, 22, 16, 4.25, 25, PROP, 4)
    # The Downtown arrival continues on a moving roof immediately. All parts
    # share one schedule, so the couplings keep honest two-metre landing gaps.
    for z in (4, 16, 28):
        car = box(9.25, 2, z, 12.75, 5.5, z + 10, ACCENT)
        L.event(car, 1, 3, 12, 6, 1, 60, 0)
    for z in (14, 26):
        coupling = box(10.5, 2.5, z, 11.5, 3, z + 2, DARK)
        L.event(coupling, 1, 3, 12, 6, 1, 60, 0)
    for z in (6, 19):
        # The adjacent service train departs three seconds later: it catches
        # up alongside the arrival train for a readable lateral opportunity.
        box(17.75, 2, z, 20.75, 5.5, z + 11, ACCENT, 12)
    # Signals and station canopy turn transport into a brief roof route:
    # slide under the signal bridge, transfer trains, jump to the island canopy.
    box(9, 6.75, 24, 21, 7, 24.5, BEAM)
    box(13.25, 3.25, 24, 13.5, 6.75, 24.5, BEAM)
    box(21, 3.25, 24, 21.25, 6.75, 24.5, BEAM)
    box(13, 5.25, 32, 17, 5.5, 38, BEAM)
    for z in (32, 37.5):
        box(15.5, 3.25, z, 16, 5.25, z+.5, DARK)
    for x in (9.75, 12, 18.25, 20):
        box(x, 2, 0, x + .25, 2.25, 54, BEAM)         # both real rail alignments
    box(8, 2, 38.5, 13, 3.25, 41, A)                 # permanent crossing behind parked train
    box(9, 8.75, 40, 13, 9, 41, B)                    # roof jumps fit through the portal
    box(5, 6, 39.75, 9, 7.5, 40, SIGN)               # destination beside the opening
    box(9, 5.25, 41, 17, 5.5, 43, BEAM)              # service gantry, 3m from last roof
    box(16.5, 2, 41, 17, 5.25, 43, DARK)              # anchored to island platform
    box(13, 2, 49, 17, 4.25, 53, A)                  # island joins service tunnel
    box(14, 3.25, 48, 17, 3.75, 49, A)              # service stair from island platform
    for z in (6, 30):
        box(4, 8.75, z, 5, 9, z + 4, GLASS)
        box(17, 8.75, z, 18, 9, z + 4, GLASS)
    L.cp(10, 5.5, 5, 12, 7, 0)
    L.hint(0, 3.25, 0, 9, 6, 0)

    # ---------- maintenance tunnel: slow low track / fast raised walk ----------
    box(8, 0, 41, 14, 2, 90, DARK)                    # tunnel floor
    box(8, 2, 41, 9, 8, 90, B)
    box(13, 2, 41, 14, 5.25, 43, B)                 # cross-track gantry portal
    box(13, 2, 45, 14, 8, 49, B)
    box(13, 2, 53, 14, 8, 90, B)                    # open service door z49..53
    box(8, 9, 41, 14, 9.5, 90, B)
    box(9, 2, 40, 10.25, 3.25, 44, BEAM)             # platform height: no forced vault
    box(9, 2, 44, 10.25, 3.75, 45, A)                # concrete service stair
    for z0, z1 in ((45, 55), (58, 70), (73, 90)):
        box(9, 2, z0, 10.25, 4.25, z1, BEAM)          # walkway
    box(11.5, 2, 48, 12.75, 3, 49, PROP, 4)          # signal equipment pedestal
    box(10.25, 3, 60, 13, 3.5, 60.5, TRIM)            # pipe: slide
    box(9, 5.5, 64, 10.25, 5.75, 64.5, TRIM)          # suspended cable: crouch or slide
    for z in (50, 66, 82):
        box(10.5, 8.75, z, 11.5, 9, z + 2, GLASS)     # ceiling-mounted lights
    L.hint(9, 3.25, 41, 13, 46, 1)
    L.hint(9, 2, 52, 13, 59, 2)
    L.cp(9, 2, 41, 13, 46, 1)

    # ---------- junction room (z 90..116) ----------
    box(-6, 0, 89, 28, 2, 117, DARK)
    box(-7, 2, 89, -6, 15, 117, B)
    box(28, 2, 89, 29, 15, 117, B)
    box(-7, 2, 89, 8, 15, 90, B)
    box(14, 2, 89, 29, 15, 90, B)
    box(-7, 2, 116, 9, 15, 117, B)
    box(13, 2, 116, 29, 15, 117, B)
    box(9, 13.5, 116, 13, 15, 117, B)
    box(-7, 15, 89, 29, 15.5, 117, B)                 # ceiling
    box(-6, 8.5, 111, 28, 9, 116, A)                  # upper landing
    box(-6, 2, 110.75, 28, 8.5, 111, B)               # its face
    box(0, 2, 110.5, 1.5, 9, 110.75, CLIMB)           # ladder (7m)
    box(9, 2, 90, 10.25, 4.25, 100, BEAM)             # walkway goes on
    box(9, 2, 100, 13, 5.5, 103, ACCENT)              # pump housings anchored to floor
    box(9, 2, 104, 13, 6.75, 107, ACCENT)             # each serves the rising mains
    box(9, 2, 108, 13, 8, 111, ACCENT)
    box(12.5, 8, 101, 13, 12, 111, TRIM)              # rising main ties machines to wall
    box(0, 10, 110.5, 4, 11.5, 110.75, SIGN)          # illuminated gallery entrance
    for x in (0, 3.75):
        box(x, 11.5, 110.5, x + .25, 15, 110.75, TRIM)  # sign suspension rods
    for x in (2, 18):
        box(x, 14.75, 96, x + 2, 15, 100, GLASS)
    L.cp(-6, 2, 90, 28, 92, 2)
    L.cp(9, 4.25, 90, 10.25, 92, 2)
    L.hint(-6, 2, 104, 28, 110.5, 3)
    L.cp(-6, 9, 112, 28, 116, 3)

    # ---------- upper service gallery, floor cuts expose ventilation shaft ----------
    box(9, 8.5, 117, 13, 9, 130, A)
    box(9, 8.5, 133, 13, 9, 140, A)                   # pit z 130..133
    box(9, 8.5, 130, 10, 9, 133, BEAM)               # wall-fixed inspection bypass
    box(10, 8.5, 140, 10.5, 9, 148, BEAM)             # beams over shaft
    box(11.5, 8.5, 140, 12, 9, 148, BEAM)
    box(9, 8.5, 148, 13, 9, 166, A)
    box(8, 0, 117, 9, 13.5, 166, B)                   # shaft walls support gallery
    box(13, 0, 117, 14, 13.5, 166, B)
    box(8, 13.5, 117, 14, 14, 166, B)
    box(9, 10, 124, 13, 10.5, 124.5, TRIM)            # duct: slide
    box(9.5, 9, 137, 12.5, 10, 138, PROP, 4)          # raised duct housing: genuine vault
    for z in (121, 135, 152):
        box(10.5, 13.25, z, 11.5, 13.5, z + 2, GLASS)
    L.hint(9, 9, 134, 13, 139.5, 4)
    L.cp(9, 9, 133, 13, 134, 4)

    # ---------- station B exit (z 166..190) ----------
    box(0, 0, 166, 22, 9, 190, A)                    # exit station foundation
    box(-1, 9, 165, 9, 16, 166, B)
    box(13, 9, 165, 23, 16, 166, B)
    box(-1, 9, 166, 0, 16, 190, B)
    box(22, 9, 166, 23, 16, 190, B)
    box(-1, 9, 190, 8, 16, 191, B)
    box(14, 9, 190, 23, 16, 191, B)
    box(8, 9, 190, 14, 14, 191, B)
    box(-1, 16, 165, 23, 16.5, 191, B)
    for x0 in (3, 8.5, 11, 16.5):
        box(x0, 9, 172, x0 + 1.25, 10, 173.5, PROP, 4)  # ticket gates; sides remain open
    for i in range(10):
        box(8, 9, 180 + i, 14, 9.5 + i * .5, 190, A)  # stairs
    box(15, 14, 189.75, 20, 15.5, 190, SIGN)         # transfer sign beside the opening
    L.cp(9, 9, 166, 13, 168, 5)
    L.cp(8, 14, 188, 14, 191, 6)
    expand_network(L)
    return L


def expand_network(L):
    """A transfer concourse, second station and return through the service network.

    The trains are an authored station set piece. The route subsequently leaves
    them for fan halls, ventilation cuts and a high-to-low return to the tracks.
    """
    b = L.box
    # 1. Turn east through the tiled transfer concourse, with ticket barriers.
    b(8, 0, 191, 22, 14, 202, A)
    b(22, 0, 192, 66, 14, 202, A)
    b(8, 14, 201.5, 66, 20, 202, B)
    b(22, 14, 192, 66, 20, 192.5, B)
    b(8, 14, 191, 8.5, 20, 202, B)
    b(8, 20, 191, 66, 20.5, 202, B)
    b(32, 14, 192.5, 33, 15, 201.5, PROP, 4)
    b(47, 15.25, 192.5, 47.5, 15.5, 201.5, TRIM)
    b(47, 14, 192.5, 47.5, 15.25, 192.75, BEAM)
    for x in (24, 52):
        b(x, 19.75, 196, x+5, 20, 197, GLASS)
    L.cp(55, 14, 194, 62, 200, 7)
    # 2. Transfer-station overlook and a full descending stair to the platform.
    b(66, 0, 182, 103, 5.5, 244, DARK)
    b(66, 5.5, 182, 67, 20, 192, B)
    b(66, 5.5, 202, 67, 20, 244, B)
    b(102, 5.5, 182, 103, 20, 244, B)
    b(66, 5.5, 182, 103, 20, 183, B)
    b(66, 20, 182, 103, 20.5, 244, B)
    b(67, 5.5, 183, 78, 7, 244, A)
    b(92, 5.5, 183, 102, 7, 244, A)
    b(66, 13.5, 192, 76, 14, 202, BEAM)
    b(74, 7, 192, 76, 13.5, 193, DARK)
    for i in range(14):
        b(68, 7, 202+i, 74, 14-i*.5, 203+i, A)
    # Two routes across the platforms: normal car gaps, difficult lateral roof transfer.
    for z in (209, 225):
        b(78.5, 5.5, z, 82, 9.25, z+14, ACCENT)
    b(80.25, 6, 223, 81.25, 6.5, 225, DARK)
    b(85, 5.5, 214, 88.5, 9.25, 239, ACCENT)
    for x in (79.5, 81.75, 85.5, 87.75):
        b(x, 5.5, 184, x+.25, 5.75, 244, BEAM)
    for z in (208, 228):
        b(70, 19.75, z, 72, 20, z+5, GLASS)
        b(95, 19.75, z, 97, 20, z+5, GLASS)
    b(67, 7, 223, 74, 8, 224, PROP, 4)
    L.cp(68, 7, 218, 76, 222, 8)
    # The technical divider is the wallrun face; it also supports the service bridge.
    b(77.75, 7, 231, 78, 14, 250, B)
    b(67, 0, 244, 103, 5.5, 253, DARK)
    b(67, 8.75, 247, 96, 9.25, 250, BEAM)
    b(78, 8.75, 243, 96, 9.25, 247, BEAM)
    b(95, 5.5, 243, 96, 8.75, 250, DARK)
    b(67, 7, 243.75, 68.5, 9.25, 244, CLIMB)
    b(67, 7, 240, 76, 9.25, 244, A)  # permanent abutment gives the safe route a climb
    b(67, 5.5, 252, 103, 16, 253, B)
    b(102, 5.5, 244, 103, 20, 253, B)
    b(67, 20, 244, 103, 20.5, 253, B)
    L.cp(69, 9.25, 247, 75, 250, 9)
    # 3. Leave trains behind: west through fan service, then turn north at a door.
    b(28, 0, 247, 67, 9.25, 253, A)
    b(28, 9.25, 247, 67, 15, 247.5, B)
    b(34, 9.25, 252.5, 67, 15, 253, B)
    b(28, 15, 247, 67, 15.5, 253, B)
    b(54, 9.25, 247.5, 55, 10.25, 252.5, PROP, 4)
    door = b(35, 9.25, 247.5, 35.25, 13, 252.5, BEAM)
    L.event(door, 5, 2, 4, .75, 0, 5, 0)
    b(40, 10.5, 247.5, 40.5, 10.75, 252.5, TRIM)
    b(40, 9.25, 247.5, 40.5, 10.5, 247.75, BEAM)
    b(56, 14.75, 249, 61, 15, 250, GLASS)
    # 4. Ventilation gallery: real void below the cut, wall ledge or precision leap.
    b(24, 0, 247, 28, 15, 287, B)
    b(34, 0, 253, 35, 15, 287, B)
    b(28, 8.75, 253, 34, 9.25, 266, A)
    b(28, 8.75, 270, 34, 9.25, 287, A)
    b(28, 8.75, 266, 29, 9.25, 270, BEAM)
    b(24, 15, 253, 35, 15.5, 287, B)
    b(28, 10.5, 278, 34, 10.75, 278.5, TRIM)
    for z in (260, 282):
        b(30, 14.75, z, 31, 15, z+2, GLASS)
    L.cp(28, 9.25, 273, 34, 276, 10)
    # 5. Pump hall changes the scale again and rises to a high transverse balcony.
    b(24, 0, 287, 58, 9.25, 315, A)
    b(24, 9.25, 287, 24.5, 22, 315, B)
    b(24, 9.25, 314.5, 58, 22, 315, B)
    b(34, 9.25, 287, 58, 22, 287.5, B)
    b(57.5, 9.25, 287, 58, 22, 304, B)
    b(57.5, 9.25, 312, 58, 22, 315, B)
    b(24, 22, 287, 58, 22.5, 315, B)
    b(34, 9.25, 292, 45, 13, 298, ACCENT)
    b(48, 9.25, 291, 54, 18, 300, TRIM)
    b(26, 13.75, 306, 58, 14.25, 314.5, BEAM)
    b(26, 9.25, 306, 26.5, 13.75, 314.5, DARK)
    b(29, 9.25, 305.75, 30.5, 14.25, 306, CLIMB)
    b(52, 14.25, 306, 53, 15.25, 314.5, PROP, 4)
    b(30, 21.75, 296, 34, 22, 298, GLASS)
    L.cp(37, 14.25, 308, 45, 313, 11)
    # 6. High service crossing returns east, then stairs turn back south to tracks.
    b(58, 0, 304, 98, 14.25, 312, A)
    b(58, 14.25, 304, 98, 19, 304.5, B)
    b(58, 14.25, 311.5, 98, 19, 312, B)
    b(58, 19, 304, 98, 19.5, 312, B)
    b(73, 15.5, 304.5, 73.5, 15.75, 311.5, TRIM)
    b(73, 14.25, 304.5, 73.5, 15.5, 304.75, BEAM)
    b(87, 14.25, 304.5, 88, 15.25, 311.5, PROP, 4)
    b(98, 0, 266, 118, 4, 322, A)
    b(98, 4, 312, 118, 20, 322, B)
    b(117.5, 4, 266, 118, 20, 285, B)
    b(117.5, 4, 297, 118, 20, 312, B)
    b(97.5, 4, 266, 98, 20, 304, B)
    b(98, 20, 266, 118, 20.5, 322, B)
    b(98, 13.75, 304, 111, 14.25, 312, BEAM)
    b(110.5, 4, 304, 111, 13.75, 312, DARK)
    for i in range(20):
        b(101, 4, 284+i, 107, 4.25+i*.5, 285+i, A)
    train = b(108.5, 4, 268, 112, 7.5, 281, ACCENT)
    L.event(train, 1, 3, 14, 7, 1, 30, 0)
    for x in (109, 111.25):
        b(x, 4, 267, x+.25, 4.25, 300, BEAM)
    # Re-entry is a side jump from the last maintenance stair. The train then
    # brings a broad service landing into view at the daylight construction portal.
    b(113.5, 7, 285, 118, 7.5, 297, BEAM)
    b(117, 4, 285, 118, 7, 297, DARK)
    b(118, 0, 285, 137, 7.5, 297, A)
    b(124, 7.5, 285, 125, 8.5, 293, PROP, 4)
    b(129, 0, 299, 132, 30, 302, BEAM)  # crane mast outside the tunnel
    b(116, 28, 299, 140, 29, 302, BEAM)
    b(135, 7.5, 287, 136, 14, 295, B)
    b(98, 4, 266, 118, 20, 267, B)
    b(98, 4, 276, 104, 5, 277, PROP, 4)
    L.cp(102, 14.25, 305, 109, 310, 12)
    L.cp(100, 4, 268, 106, 274, 13)
    L.goal(130, 7.5, 287, 135, 295)
