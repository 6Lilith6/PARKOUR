"""LEVEL 2 - CONSTRUCTION SITE

A skyscraper frame going up. Style: VERTICAL TECHNICAL parkour - climb a
floor, cross it, step outside, cross to the next structure, climb again.
Concrete slabs, orange girders, yellow cranes, scaffold loading decks
and a working hoist. Falling to the dirt (y<1) respawns.

  start   site-office containers (y5), scaffold deck
  T1      unfinished tower, floors at 9 / 13 / 17. Every 4m climb has:
            ladder | pallets / crates / hanging pallet | formwork wall
            to run up
          F2 has a hole in the slab (jump it or walk around the core),
          F1 has a formwork bar you must slide under (or go round)
  gap     20m between towers at y17: broad loading decks (one real gap)
          | rear scaffold bridge | girder / hoarding wallrun shortcut
  T2      staggered decks rising east 17 / 21 / 25 / 29, each rise:
            ladder | safety net bounce or hanging pallets | wall run-up
  finale  crane mast ladder (or pallet+mantle), then walk the jib 34m
          above the ground to the cab
"""
from .common import *

NAME = "construction site"
PALETTE = {1: 129}  # cold blue-black reserved for depth, never a landing top
# top, haze, sil a, sil b, ground, sun, fog, fog dist, hint base,
# heading, silhouette height
SKY = (12, 13, 5, 1, 1, 7, 1, 32, 14, 192, 6)
MATS = {
    A: (7, 6, 13, 0x58),      # pale landing tops; darker concrete side faces
    B: (9, 4, 4, 0x24),       # formwork panels
    PROP: (6, 12, 5, 0x14),   # pale roofs on blue site offices
    BEAM: (9, 4, 5, 0),       # ochre primer: distinct from concrete and blue-black void
    TRIM: (5, 0, 5, 0),       # rebar, cables
    CLIMB: (10, 9, 9, 0x02),
    SIGN: (10, 10, 9, 0x04),  # hazard panel
    BOUNCE: (11, 3, 3, 0x38), # safety nets
    WOOD: (15, 4, 5, 0),      # sunlit timber tops, brown vertical end grain
    GLASS: (12, 1, 1, 0),
    DARK: (5, 5, 1, 0),       # lift core
    ACCENT: (10, 10, 9, 0x07),  # crane lattice
}


def build():
    L = Level()
    box, P = L.box, L.prop

    # ---------- start: site offices + deck ----------
    box(-2, 0, -2, 8, 5, 8, PROP)
    box(5, 5, -2, 8, 7.5, 4, PROP)
    L.cp(1, 5, 0, 4, 2, 0)
    L.hint(-2, 5, -2, 8, 6, 0)
    box(-2, 4.75, 8, 10, 5, 12, WOOD)                 # scaffold deck
    for x in (-2, 9.75):
        box(x, 0, 11.5, x + .25, 4.75, 11.75, BEAM)

    # ---------- tower T1 ----------
    box(-4, 8.5, 12, 20, 9, 36, A)                    # F1 top 9
    box(-4, 12.5, 12, 20, 13, 22, A)                  # F2 top 13
    box(-4, 12.5, 25, 20, 13, 28, A)                  # (hole z 22..25)
    box(12, 12.5, 22, 20, 13, 25, A)
    box(-4, 16.5, 20, 20, 17, 36, A)                  # F3 top 17
    box(12, 0, 30, 16, 21, 34, DARK)                  # lift core
    for x in (-4, 19.25):
        for z in (12, 35.25):
            box(x, 0, z, x + .75, 16.5, z + .75, A)   # columns
    # climb 5 -> 9 (F1 south face z=12)
    box(0, 5, 11.75, 1.5, 9, 12, CLIMB)              # ladder
    box(4.5, 5, 10, 6.5, 6.25, 12, WOOD)             # pallets
    box(7, 5, 11.75, 10, 9, 12, B)                   # formwork: run up
    L.hint(-2, 5, 8, 10, 11.75, 1)
    L.cp(-4, 9, 13, 20, 15, 1)
    # F1: rebar to vault, bags, a bar to slide under
    box(-4, 9, 18, 6, 9.75, 18.5, TRIM, 4)
    P(13, 20, 9, 3, 2, 1)
    box(-4, 10.25, 25, 8, 10.75, 25.5, TRIM)
    box(-4, 9, 25, -3.75, 10.25, 25.5, TRIM)
    box(7.75, 9, 25, 8, 10.25, 25.5, TRIM)
    L.hint(-4, 9, 21, 8, 24.5, 2)
    # climb 9 -> 13 (F2 north face z=28, 8m strip z 28..36)
    box(1, 9, 28, 2.5, 13, 28.25, CLIMB)
    box(5, 9, 28.5, 7.5, 10.25, 30.5, WOOD)
    box(5, 10.25, 28, 7.5, 11.5, 29.5, WOOD)
    box(-4, 9, 28, 0, 13, 28.25, B)
    # F2: drywall stack, slab hole z 22..25
    P(13, 14, 13, 2, 2, 1)
    # climb 13 -> 17 (F3 south face z=20, strip z 12..20)
    box(15, 13, 19.75, 16.5, 17, 20, CLIMB)
    box(2, 13, 17, 5, 15, 20, WOOD)                 # stored formwork against F3
    # Hoist works between the first two floors; its guide is fixed to T1.
    box(16.5, 9, 28.5, 19.5, 9.5, 30, BEAM, 13)
    box(19.5, 9, 29.5, 19.75, 17, 30, ACCENT)
    box(6, 13, 19.75, 9, 17, 20, B)
    L.hint(-4, 13, 12, 20, 15.5, 3)
    L.cp(-4, 17, 21, 20, 23, 2)

    # ---------- the gap (x 20..40) at y 17 ----------
    for x0, x1 in ((20, 28), (31, 40)):
        box(x0, 16.5, 26, x1, 17, 29, WOOD)         # scaffold loading decks
        for z in (26, 28.75):
            box(x0 + 3, 0, z, x0 + 3.5, 16.5, z + .25, BEAM)
    box(20, 16.5, 33, 40, 17, 35, WOOD)             # safe rear scaffold bridge
    for x in (27, 34):
        box(x, 0, 34.5, x + .5, 16.5, 35, BEAM)
    box(20, 16.75, 30.5, 40, 17, 31, BEAM)           # girder: balance
    box(20, 16, 25.5, 40, 17.5, 26, BEAM)           # hoarding crossmember
    box(22, 17.5, 25.75, 37, 21, 26, SIGN)           # site boundary hoarding
    L.hint(14, 17, 23, 20, 36, 4)
    # ---------- tower T2: staggered decks rising east ----------
    box(40, 16.5, 12, 56, 17, 36, A)                  # D1 17
    box(46, 20.5, 12, 62, 21, 36, A)                  # D2 21
    box(52, 24.5, 12, 68, 25, 36, A)                  # D3 25
    box(58, 28.5, 12, 75.75, 29, 36, A)               # D4 29
    for x, h in ((40, 16.5), (55.25, 16.5), (61.25, 20.5), (67.25, 24.5), (75, 28.5)):
        for z in (12, 35.25):
            box(x, 0, z, x + .75, h, z + .75, A)      # columns
    L.cp(40, 17, 13, 43, 35, 3)
    # rise 1: D1 -> D2 (face x=46)
    box(45.75, 17, 12, 46, 21, 36, B)                # formwork face
    box(45.5, 17, 14, 45.75, 21, 15.5, CLIMB)
    box(43, 17, 20, 45.75, 18.25, 24, WOOD)          # formwork stack
    L.hint(40, 17, 18, 45, 26, 5)
    # rise 2: D2 -> D3 (face x=52)
    box(51.75, 21, 12, 52, 25, 36, B)
    box(51.5, 21, 32, 51.75, 25, 33.5, CLIMB)
    box(48, 21, 20, 51.75, 23, 23, WOOD)            # stored panels, supported by D2
    for i, h in enumerate((1.25, 2.5)):
        box(47.5 + i, 21, 13, 51.75, 21 + h, 16, WOOD)  # crate steps
    # rise 3: D3 -> D4 (face x=58)
    box(57.75, 25, 12, 58, 29, 36, B)
    box(57.5, 25, 14, 57.75, 29, 15.5, CLIMB)
    box(55, 25, 26, 57.75, 26.25, 30, WOOD)
    L.cp(58, 29, 13, 61, 35, 4)
    P(64, 18, 29, 2, 3, 1.25)
    P(66, 28, 29, 3, 2, 1)

    # ---------- finale: crane ----------
    box(76, 0, 22, 78, 34.5, 24, ACCENT)             # mast
    box(75.75, 29, 22.5, 76, 34.5, 23.5, CLIMB)      # mast ladder
    box(52, 34, 22.75, 76, 34.5, 23.25, BEAM)        # jib (walk it)
    box(78, 33, 22, 82, 35, 24, PROP)                # counterweight
    box(70, 31.25, 22, 73, 31.5, 24, WOOD)           # load directly under crane jib
    box(71.375, 31.5, 22.75, 71.625, 34, 23, TRIM)
    L.hint(66, 29, 18, 75.75, 30, 6)
    box(56, 31, 21.75, 60, 34, 24.25, PROP)        # cab under the jib
    L.cp(60, 34.5, 22, 64, 24, 5)

    # ---------- scenery ----------
    box(-20, 0, 40, -8, 12, 52, A)                   # distant frames
    box(-20, 12, 40, -8, 12.5, 52, A)
    box(-20, 16, 40, -8, 16.5, 52, A)
    for x, z in ((-20, 40), (-8.5, 51.5)):
        box(x, 12.5, z, x + .5, 16, z + .5, A)
    box(20, 0, 50, 34, 3, 60, PROP)                  # material heaps
    box(-14, 0, 0, -8, 2, 6, WOOD)
    box(30, 0, 0, 36, 2.5, 3, PROP)                  # excavator
    box(31, 2.5, 0, 34, 4, 3, BEAM)
    box(90, 0, 0, 92, 40, 2, ACCENT)                 # far crane
    box(70, 40, .75, 98, 40.5, 1.25, BEAM)
    box(-30, 0, 70, -10, 30, 90, A)
    box(60, 0, 50, 80, 24, 70, A)
    extend_site(L)
    return L


# The second half circles the neighbouring frame twice at different heights.
# These are loading floors, hoardings and crane access decks, not repeated
# detached stepping stones. The old crane remains visible behind the runner.
HINTS = [
    "site offices -> tower frame\nfollow the crane mast",
    "ladder, formwork or run-up:\nthree ways to the next floor",
    "slide beneath the rebar\nor go around the lift core",
    "hoist or stored formwork:\njump onto the landing deck",
    "loading decks: jump the gap\nor cross the rear scaffold",
    "follow alternating ladders\nup the unfinished floors",
    "cross the crane jib west\nonto the next tower frame",
    "north through the open frame\nthen west over the truss",
    "upper floor: turn east\nabove your earlier crossing",
    "drop into the assembly hall\npress x before landing to roll",
    "shaft: ladder or staged\nwall climbs to the upper deck",
    "external service bridge:\nwallrun or the rear walkway",
    "last frame: climb, turn south\nroof plant marks the finish",
]


def extend_site(L):
    b = L.box

    def frame(x0, z0, x1, z1, y):
        """A concrete floor on four columns, with no artificial solid infill."""
        b(x0, y-.5, z0, x1, y, z1, A)
        for x in (x0, x1-.75):
            for z in (z0, z1-.75):
                L.tall(x, z, x+.75, z+.75, y-.5, A)

    # Crane transfer -> open concrete frame, then climb to a north gallery.
    frame(32, 22, 52, 50, 34)
    # The jib ends at x52; this landing touches it and is half a metre lower.
    b(32, 35.25, 39, 44, 35.75, 39.5, TRIM)
    for x in (32, 43.75):
        b(x, 34, 39, x+.25, 35.25, 39.5, TRIM)
    b(45, 34, 43, 51, 35, 43.75, PROP, 4)
    frame(32, 50, 52, 68, 38)
    b(36, 34, 49.75, 37.5, 38, 50, CLIMB)
    b(40, 34, 49.75, 48, 38, 50, B)
    b(48, 34, 46, 51, 36, 50, WOOD)
    L.cp(35, 38, 55, 43, 60, 6)
    L.hint(35, 34, 27, 51, 36, 7)

    # Cross west: real loading truss with a deck joint, a balancing flange,
    # and a rear two-metre maintenance walkway as the safe alternative.
    for lo, hi in ((0, 18), (21, 32)):
        b(lo, 37.5, 60, hi, 38, 64, WOOD)
    b(0, 37.5, 67, 32, 38, 69, WOOD)
    b(0, 37.75, 65, 32, 38, 65.5, BEAM)
    for x in (0, 16, 31.5):
        for z in (60, 68.5):
            b(x, 0, z, x+.5, 37.5, z+.5, BEAM)
    b(0, 37, 59.5, 32, 37.5, 60, BEAM)
    b(2, 37.5, 59.75, 29, 41.5, 60, B)
    b(8, 38, 60.25, 8.75, 39, 64, PROP, 4)

    # West tower. Turn north to climb; its next floor sends the player east,
    # looking down over the earlier bridge instead of following one axis.
    frame(-32, 52, 0, 68, 38)
    frame(-32, 68, 0, 86, 42)
    L.cp(-27, 38, 59, -20, 64, 7)
    b(-26, 38, 67.75, -24.5, 42, 68, CLIMB)
    b(-20, 38, 67.75, -12, 42, 68, B)
    b(-10, 38, 64, -6, 40, 68, WOOD)
    L.cp(-25, 42, 73, -18, 78, 8)
    L.hint(-31, 42, 72, -4, 80, 8)
    for lo, hi in ((0, 14), (17, 32)):
        b(lo, 41.5, 78, hi, 42, 82, WOOD)
    b(0, 41.5, 84, 32, 42, 86, WOOD)
    for x in (0, 15.5, 31.5):
        b(x, 0, 84, x+.5, 41.5, 84.5, BEAM)
    b(0, 41, 81.5, 32, 41.5, 82, BEAM)

    # Assembly hall below: controlled six-metre drop with a long run-out.
    frame(32, 72, 52, 90, 42)
    L.cp(35, 42, 79, 42, 84, 9)
    L.hint(33, 42, 84, 51, 89, 9)
    frame(32, 90, 52, 114, 36)
    b(32, 36, 90, 32.5, 45, 114, A)
    b(51.5, 36, 90, 52, 45, 114, A)
    b(32, 44.5, 104, 52, 45, 105, BEAM)
    b(33, 36, 107, 39, 37, 108, PROP, 4)
    b(45, 36, 96, 50, 38, 102, WOOD)
    L.cp(36, 36, 108, 43, 112, 10)

    # Lift shaft climb with ladder and two four-metre climbing faces.
    frame(32, 114, 52, 134, 44)
    b(34, 36, 113.75, 35.5, 44, 114, CLIMB)
    b(40, 36, 111, 44, 40, 114, B)
    b(40, 40, 113.75, 44, 44, 114, B)
    L.hint(33, 36, 109, 50, 114, 10)
    L.cp(36, 44, 120, 43, 125, 11)

    # External bridge: one long exposed wallrun line and a permanent rear
    # catwalk; both connect real neighbouring towers, supported at each end.
    for lo, hi in ((52, 60), (67, 80)):
        b(lo, 43.5, 123, hi, 44, 127, WOOD)
    b(52, 43.5, 131, 80, 44, 134, WOOD)
    for x in (52, 79.5):
        for z in (123, 133.5):
            b(x, 0, z, x+.5, 43.5, z+.5, BEAM)
    b(52, 43, 122.5, 80, 43.5, 123, BEAM)
    b(52, 43.5, 122.75, 80, 48, 123, B)
    b(60, 43.75, 127.5, 67, 44, 128, BEAM)
    b(59.5, 43.5, 127, 60, 44, 131, WOOD)
    b(67, 43.5, 127, 67.5, 44, 131, WOOD)
    L.hint(44, 44, 119, 51, 133, 11)
    frame(80, 118, 98, 138, 44)
    L.cp(85, 44, 125, 92, 130, 12)

    # Upper frame: reverse south at roof height, overlooking the first crane.
    frame(80, 96, 98, 118, 50)
    b(86, 44, 118, 87.5, 50, 118.25, CLIMB)
    b(92, 44, 118, 96, 47, 122, B)
    frame(80, 76, 98, 96, 56)
    b(82, 50, 96, 83.5, 56, 96.25, CLIMB)
    b(90, 50, 96, 95, 53, 100, B)
    L.cp(83, 56, 84, 89, 89, 13)
    L.hint(81, 50, 101, 97, 109, 12)
    b(83, 56, 81, 94, 57, 81.75, PROP, 4)
    # Roof mechanical plant provides the final sprint, vault, slide and gap.
    frame(80, 51, 98, 73, 56)
    b(97.5, 55.5, 73, 98, 56, 76, BEAM)  # precise side girder alternative
    b(80, 57.25, 62, 91, 57.75, 62.5, TRIM)
    for x in (80, 90.75):
        b(x, 56, 62, x+.25, 57.25, 62.5, TRIM)
    b(94, 56, 53, 97, 60, 59, PROP)
    b(92, 56, 51, 93, 62, 52, ACCENT)
    L.goal(82, 56, 52, 89, 57)


SECTIONS = [
    ("site offices", (2.5, 5, 1)),
    ("unfinished floors", (8, 17, 25)),
    ("scaffold crossing", (41.5, 17, 24)),
    ("crane jib", (62, 34.5, 23)),
    ("north frame", (39, 38, 58)),
    ("west formwork", (-23, 38, 62)),
    ("upper return", (-21, 42, 75)),
    ("assembly drop", (39, 36, 110)),
    ("lift shaft", (39, 44, 123)),
    ("exterior bridge", (88, 44, 128)),
    ("roof frame", (86, 56, 86)),
    ("mechanical roof", (85, 56, 54)),
]
