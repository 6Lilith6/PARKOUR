"""LEVEL 8 - MEGASTRUCTURE

A colossal industrial tower at dusk: a lit concrete core, catwalks,
orange girders, machine service balconies and fixed pipe racks, a cold black
shaft far below. Style: EVERYTHING - a switchback climb from the
bottom of the pit to the top of the core using every move.

  Catwalk legs alternate sides of the core, each one tier (8m) higher:
    A  y2  west, north   vault, slide, gap (jump | beam)
    B  y10 east, south   slide, 8m gap (panel wallrun | plates | pipe)
    C  y18 west, north   gap (core wallrun | plates | pipe), slide
    D  y26 east, south   bounce pad, gap (core wallrun | pipe), vault
  Every 8m climb: ladders | machinery / wall-mounted service balconies |
  run up a 4m machine block, then run up again.
  First crown (y42): eastward transfer to a second, much taller structure.
  Exterior: south along the wall, climb, north across inspection decks (y58).
  Pipe network: balance routes and broad gratings, then the turbine hall (y66).
  Descent: leave the hall west, drop with a roll, turn south above the old core.
  Upper structure: climb west and run north along the outside gallery (y78).
  Rooftop: eastward crossover, three staged rises, turn north to finish (y90).

Legs never overlap in plan, so a fall drops into the pit and respawns.
"""
from .common import *

NAME = "megastructure"
PALETTE = {12: 140, 9: 137, 6: 134, 14: 136, 3: 131, 13: 141}
SKY = (1, 0, 5, 0, 0, 6, 1, 30, 50, 192, 30)
MATS = {
    A: (7, 5, 0, 0x58),       # pale top faces stand apart from the cold black shaft
    B: (6, 5, 1, 0x51),       # machine blocks
    PROP: (6, 13, 5, 0x55),   # vents
    BEAM: (9, 4, 4, 0x07),    # orange girders
    TRIM: (13, 5, 5, 0),      # pipes, ducts
    CLIMB: (6, 5, 5, 0x02),
    SIGN: (10, 10, 0, 0x04),  # hazard panels
    BOUNCE: (8, 8, 2, 0x78),  # bounce pads
    WOOD: (6, 5, 1, 0),       # service grilles, fixed machinery housings
    GLASS: (0, 0, 1, 0),      # unlit shaft floor: never mistaken for a bright landing
    DARK: (5, 1, 0, 0x18),    # the core
    ACCENT: (8, 8, 2, 0x04),  # containers
}


def build():
    L = Level()
    box, P = L.box, L.prop
    # ---------- the core, the pit, the tier blocks ----------
    box(10, 0, 0, 18, 42, 48, DARK)                   # core, crown at 42
    box(-4, -4, -9, 32, 0, 53, GLASS)                 # reactor glow (pit)
    box(0, 2, 48, 28, 10, 54, A)                      # N1 (10)
    box(0, 10, -8, 28, 18, 0, A)                      # S1 (18)
    box(0, 18, 48, 28, 26, 54, A)                     # N2 (26)
    box(0, 26, -8, 28, 34, 0, A)                      # S2 (34)
    # The outer walks cantilever from the core on real transverse girders.
    for z in (0, 24, 40):
        box(0, 1, z, 10, 1.5, z + .5, BEAM)
        box(18, 9, z, 28, 9.5, z + .5, BEAM)

    # ---------- leg A: y2, x 0..6, north ----------
    box(0, 1.5, -6, 6, 2, 20, A)
    box(0, 1.5, 23, 6, 2, 48, A)                      # gap z 20..23
    box(4.75, 1.75, 20, 5, 2, 23, TRIM)               # beam over it
    L.cp(1, 2, -6, 5, -3, 0)
    L.hint(0, 2, -6, 6, 0, 0)
    P(1, 6, 2, 4, 1.5, 1)                             # vent: vault
    box(0, 3, 14, 6, 3.5, 14.5, TRIM)                 # duct: slide
    box(6, 3, 14, 10, 3.5, 14.5, TRIM)               # duct connection into core
    # climb 1 (2 -> 10, face z 48)
    box(3, 2, 38, 6, 6, 48, B)                        # machine (6)
    box(4.5, 2, 37.75, 6, 6, 38, CLIMB)
    box(4.5, 6, 47.75, 6, 10, 48, CLIMB)
    box(0, 2, 40, 3, 4.5, 42.5, ACCENT)               # containers
    box(0, 2, 42.5, 3, 7, 45, ACCENT)
    box(0, 2, 45, 3, 9.5, 48, ACCENT)
    L.hint(0, 2, 30, 6, 36, 1)
    L.cp(0, 10, 48, 10, 54, 1)
    # Freight lift in the core's open service shaft. Its intermediate
    # inspection balcony is a jump exit during ascent, not a passive ride.
    shaft_lift = box(6, 1.5, 34, 9.5, 2, 38, WOOD)
    L.event(shaft_lift, 1, travel=8, duration=7, dwell=2,
            radius=14, delay=1)
    box(9.5, 0, 34, 10, 14, 34.5, BEAM)
    box(9.5, 0, 37.5, 10, 14, 38, BEAM)
    box(6, 5.5, 40, 10, 6, 44, WOOD)
    box(6, 9.5, 44, 10, 10, 48, WOOD)
    box(8, 6, 43.75, 9.5, 10, 44, CLIMB)

    # ---------- leg B: y10, x 22..28, south ----------
    P(14, 50, 10, 1.5, 3, 1)                          # vent on N1
    box(22, 9.5, 30, 28, 10, 48, A)
    box(22, 9.5, 0, 28, 10, 20, A)                    # gap z 20..30
    box(18, 11, 40, 28, 11.5, 40.5, TRIM)             # core supply duct: slide
    box(28, 11, 18, 28.5, 16, 32, SIGN)               # machinery screen on service gantry
    box(28, 0, 24, 28.5, 11, 24.5, BEAM)             # gantry footing
    box(24, 9.75, 23, 28, 10, 27, WOOD)              # broad maintenance landing
    box(22.5, 9.75, 20, 22.75, 10, 30, TRIM)          # pipe: balance
    L.hint(22, 10, 32, 28, 38, 2)
    P(23, 12, 10, 4, 1.5, 1)                          # vent: vault
    # climb 2 (10 -> 18, face z 0)
    box(26, 10, 0, 27.5, 18, .25, CLIMB)
    box(22, 10, 3.5, 25, 12.5, 6, WOOD)              # pump casing seated on catwalk
    box(22, 10, 0, 25, 15, 3.5, WOOD)                # valve housing against S1
    L.cp(0, 18, -8, 28, -5, 2)

    # ---------- leg C: y18, x 6..10, north ----------
    box(6, 17.5, 0, 10, 18, 12, A)
    box(6, 17.5, 24, 10, 18, 48, A)                   # gap z 12..24
    P(6.5, 3, 18, 3, 1.5, 1)                          # vent
    box(6, 19, 8, 10, 19.5, 8.5, TRIM)                # duct: slide
    box(7, 17.75, 15, 10, 18, 21, WOOD)              # core-mounted inspection balcony
    box(6.25, 17.75, 12, 6.5, 18, 24, TRIM)           # pipe
    L.hint(6, 18, 0, 10, 2, 3)
    # climb 3 (18 -> 26, face z 48)
    box(8, 18, 36, 10, 22, 48, B)                     # machine (22)
    box(6.25, 18, 47.75, 7.75, 26, 48, CLIMB)
    box(6, 20.25, 41, 8, 20.5, 43, WOOD)              # balcony fixed to adjacent machine
    box(6, 22.75, 44.5, 8, 23, 46.5, WOOD)           # upper inspection balcony
    box(8, 22, 44.5, 10, 23, 48, B)                 # upper machine housing supports balcony
    L.cp(0, 26, 48, 28, 54, 3)

    # ---------- leg D: y26, x 18..22, south ----------
    box(18, 25.5, 30, 22, 26, 48, A)
    box(18, 25.5, 0, 22, 26, 18, A)                   # gap z 18..30
    box(19, 26, 41.5, 21, 26.75, 43, PROP, 4)         # low air handling guard: vault
    box(21.5, 25.75, 18, 21.75, 26, 30, TRIM)         # pipe
    box(18, 25.75, 21, 20.5, 26, 27, WOOD)           # core-mounted service balcony
    P(18.5, 10, 26, 3, 1.5, 1)                        # vent: vault
    L.hint(18, 26, 40, 22, 46, 4)
    # climb 4 (26 -> 34, face z 0)
    box(18, 26, 0, 20, 30, 8, B)                      # machine (30)
    box(20.25, 26, 0, 21.75, 34, .25, CLIMB)
    box(20, 28.5, 4, 22, 28.75, 6, WOOD)              # balcony attached to machine
    box(20, 31, 1, 22, 31.25, 3, WOOD)               # upper inspection balcony
    box(18, 30, 0, 20, 31.25, 3, B)                 # housing supports balcony, ladder stays clear
    L.cp(16, 34, -8, 28, -5, 4)

    # ---------- climb 5 (34 -> 42, core face z 0) + crown ----------
    box(15.75, 34, -.25, 17.25, 42, 0, CLIMB)
    box(12.25, 34, -7, 15.25, 36.5, -4.5, ACCENT)     # containers
    box(12.25, 34, -4.5, 15.25, 39, -2, ACCENT)
    box(12.25, 34, -2, 15.25, 41.5, 0, ACCENT)
    box(10, 34, -6, 12, 38, 0, B)                     # machine (38)
    L.hint(0, 34, -8, 28, -5, 5)
    L.cp(10, 42, 0, 18, 3, 5)
    P(11, 14, 42, 6, 1.5, 1)
    box(10, 43.25, 26, 18, 43.75, 26.5, TRIM)
    box(10, 42, 26, 10.25, 43.25, 26.5, TRIM)        # crown pipe riser
    P(12, 36, 42, 4, 1.5, 1.25)
    # ---------- exterior transfer: the first crown is only halfway up ----------
    box(18, 41.5, 42, 35, 42, 48, A)
    box(39, 41.5, 42, 62, 42, 48, A)
    box(35, 41.75, 47, 39, 42, 48, BEAM)          # girder leaves shoulder clearance beside wind screen
    for x in (24, 46, 58):
        box(x, 0, 42, x + 1, 41.5, 43, DARK)
        box(x, 0, 47, x + 1, 41.5, 48, DARK)
    box(18, 42, 48, 62, 46, 48.5, DARK)         # attached wind screen, optional wallrun
    P(25, 43, 42, 1.25, 3, 1)
    L.cp(54, 42, 42, 62, 48, 6)

    # ---------- external tower: south at 42, back north at 50 ----------
    L.tall(64, -12, 72, 42, 82, DARK)
    box(56, 41.5, -12, 62, 42, 42, A)
    for z in (-10, 14, 36):
        box(56, 0, z, 57, 41.5, z + 1, DARK)
        box(56, 40, z, 64, 40.5, z + 1, BEAM)
    P(57, 25, 42, 4, 1.25, 1)
    box(56, 43.25, 12, 64, 43.75, 12.5, TRIM)
    box(56, 42, 12, 56.25, 43.25, 12.5, TRIM)
    box(48, 0, -20, 80, 50, -12, A)
    box(58, 42, -12, 59.5, 50, -11.75, CLIMB)
    # Machinery stepped at the tower base offers repeated cat leaps.
    box(60, 42, -9, 64, 44.5, -6, B)
    box(60, 42, -12, 64, 47, -9, B)
    L.cp(50, 50, -20, 78, -14, 7)
    box(72, 49.5, -12, 80, 50, 12, A)
    box(72, 49.5, 16, 80, 50, 42, A)
    box(79.5, 49.75, 12, 80, 50, 16, BEAM)
    for z in (-8, 28):
        box(72, 48, z, 80, 48.5, z + 1, BEAM)
    P(74, 3, 50, 4, 1.25, 1)
    box(72, 51.25, 27, 80, 51.75, 27.5, TRIM)
    box(79.75, 50, 27, 80, 51.25, 27.5, TRIM)
    box(52, 57.5, 42, 80, 58, 52, A)
    L.tall(52, 51, 53, 52, 57.5, DARK)
    L.tall(79, 51, 80, 52, 57.5, DARK)
    box(75, 50, 41.75, 76.5, 58, 42, CLIMB)
    box(72, 50, 38, 75, 52.5, 42, B)
    box(72, 52.5, 40, 75, 55, 42, B)
    L.cp(52, 58, 44, 79, 51, 8)

    # ---------- pipe network: north over the lower transfer bridge ----------
    # A broad grating is slower but safe. Two real supply pipes are balance
    # shortcuts, and an inspection gap can be crossed against the tower wall.
    box(52, 57.5, 52, 59, 58, 74, WOOD)
    box(52, 57.5, 78, 59, 58, 99, WOOD)
    box(58.5, 57.75, 74, 59, 58, 78, TRIM)
    box(61, 58, 52, 62, 59, 99, TRIM)
    box(65, 58, 52, 66, 59, 99, TRIM)
    for z in (52, 68, 86, 98):
        L.tall(52, z, 53, z + 1, 56.5, DARK)
        box(52, 56.5, z, 66, 57.5, z + 1, BEAM)
        box(61, 57.5, z, 62, 58, z + 1, BEAM)
        box(65, 57.5, z, 66, 58, z + 1, BEAM)
    P(53, 86, 58, 4, 1.25, 1)
    L.tall(48, 99, 70, 112, 66, B)
    box(54, 58, 98.75, 55.5, 66, 99, CLIMB)
    box(60, 59, 96, 66, 61.5, 99, B)
    box(61, 61.5, 98, 66, 64, 99, B)
    L.cp(49, 66, 100, 66, 110, 9)

    # ---------- upper turbine hall: turn west, enter, then leave above the void ----------
    box(0, 65.5, 99, 48, 66, 111, A)
    for x in (0, 18, 36):
        for z in (99, 110):
            L.tall(x, z, x + 1, z + 1, 65.5, DARK)
    box(0, 66, 99, 48, 75, 100, DARK)
    box(0, 66, 110, 48, 75, 111, DARK)
    box(0, 74.5, 99, 48, 75, 111, A)
    P(35, 102, 66, 1.25, 6, 1)
    box(24, 67.25, 100, 24.5, 69, 110, TRIM)
    box(24, 66, 100, 24.5, 67.25, 100.25, TRIM)
    box(24, 66, 109.75, 24.5, 67.25, 110, TRIM)
    box(8, 66, 106, 17, 69, 110, B)             # turbine housing / upper route
    box(17, 66, 107, 17.25, 69, 108.5, CLIMB)
    L.cp(2, 66, 101, 10, 106, 10)

    # ---------- exposed descent: west, drop and turn south ----------
    L.tall(-14, 96, 0, 111, 60, A)
    box(-14, 59.5, 48, -6, 60, 96, A)
    for z in (50, 70, 90):
        L.tall(-14, z, -13, z + 1, 59.5, DARK)
        L.tall(-7, z, -6, z + 1, 59.5, DARK)
    P(-13, 85, 60, 6, 1.25, 1)
    box(-14, 61.25, 72, -6, 61.75, 72.5, TRIM)
    for x in (-14, -6.25):
        box(x, 60, 72, x + .25, 61.25, 72.5, TRIM)
    L.cp(-13, 60, 97, -7, 106, 11)
    # The descent looks down onto the original core, making height gained legible.
    L.tall(-40, 40, -14, 56, 70, B)
    box(-14, 60, 49, -13.75, 70, 50.5, CLIMB)
    box(-14, 60, 53, -10, 62.5, 56, B)
    box(-14, 62.5, 53, -11, 65, 56, B)
    box(-14, 65, 52, -11, 67.5, 55, B)
    L.cp(-38, 70, 42, -17, 53, 12)

    # ---------- high external gallery: north, gaps alternate with broad runways ----------
    box(-46, 69.5, 48, -40, 73, 52, A)          # machinery threshold before gallery
    box(-40.25, 70, 49, -40, 73, 50.5, CLIMB)
    box(-46, 72.5, 52, -40, 73, 75, WOOD)
    box(-46, 72.5, 78, -40, 73, 103, WOOD)
    box(-40.5, 72.75, 75, -40, 73, 78, TRIM)
    for z in (50, 66, 88, 101):
        L.tall(-46, z, -45, z + 1, 72.5, DARK)
        box(-46, 72, z, -36, 72.5, z + 1, BEAM)
    L.tall(-40, 56, -36, 104, 82, DARK)         # exterior wall is a real adjacent tower
    P(-45, 86, 73, 4, 1.25, 1)
    L.tall(-46, 103, -26, 122, 78, A)
    box(-44, 73, 102.75, -42.5, 78, 103, CLIMB)
    L.cp(-45, 78, 105, -29, 114, 13)

    # ---------- upper crossover: east over the turbine hall, then final roof ----------
    box(-26, 77.5, 114, -11, 78, 122, A)
    # Retracting industrial bridge closes a machinery aperture. The fixed
    # northern inspection stringer is visible before the bridge moves.
    upper_bridge = box(-11, 77.5, 114, -6, 78, 121, A)
    L.event(upper_bridge, 1, axis=3, travel=-7, duration=5, dwell=3,
            radius=14, delay=1.25)
    box(-11, 77.5, 121, -6, 78, 122, BEAM)
    box(-6, 77.5, 114, -3, 78, 122, A)
    box(-11, 76.5, 112, -6, 77.5, 114, DARK)    # bridge actuator housing
    for x in (-11, -6.5):
        L.tall(x, 112, x + .5, 113, 76.5, DARK)
    box(1, 77.5, 114, 20, 78, 122, A)
    box(-3, 77.75, 121.5, 1, 78, 122, BEAM)
    for x in (-20, 8):
        L.tall(x, 114, x + 1, 115, 77.5, DARK)
        L.tall(x, 121, x + 1, 122, 77.5, DARK)
    P(-13, 116, 78, 1.25, 4, 1)
    box(12, 79.25, 114, 12.5, 79.75, 122, TRIM)
    box(12, 78, 114, 12.5, 79.25, 114.25, TRIM)
    box(12, 78, 121.75, 12.5, 79.25, 122, TRIM)
    L.tall(20, 106, 24, 130, 82, A)
    L.tall(24, 106, 28, 130, 86, A)
    L.tall(28, 106, 42, 130, 90, A)
    box(19.75, 78, 116, 20, 82, 117.5, CLIMB)
    box(23.75, 82, 116, 24, 86, 117.5, CLIMB)
    box(27.75, 86, 116, 28, 90, 117.5, CLIMB)
    L.tall(38, 126, 40, 128, 108, DARK)
    L.cp(29, 90, 107, 36, 114, 14)
    L.goal(30, 90, 121, 38, 128)

    # ---------- skyline: other towers ----------
    box(-40, 0, -10, -28, 56, 4, DARK)
    box(92, 0, 10, 104, 50, 24, DARK)
    box(-36, 0, 50, -24, 40, 64, A)
    box(92, 0, 60, 104, 60, 72, DARK)
    return L
