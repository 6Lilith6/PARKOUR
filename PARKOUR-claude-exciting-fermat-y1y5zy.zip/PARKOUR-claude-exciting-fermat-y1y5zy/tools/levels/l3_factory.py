"""LEVEL 3 - INDUSTRIAL FACTORY

Steel, rust and smog. Style: MOMENTUM - long straights where flow builds
to full speed, and one long combo line:
  sprint (catwalk) -> jump onto containers -> keep jumping the rows ->
  wallrun along the tank -> pipe rack -> slide under crossing pipes ->
  vault the valve -> long jump over the slag pit -> conveyor -> silo

The factory floor (y2) is the safe, slow lane: conveyors to vault, pipes
to slide under, machines to go round, ladders up to the next level. The
slag pit near the end is the only place you can fall.

  warehouse  ground lane with obstacles | catwalk at y6 (ladder or crate
             steps) = sprint lane
  yard       ground weave | single containers | double stacks at y7 with
             4m gaps
  tanks/rack ladder up to the rack (y8) | wallrun along tank T1 from the
             last container
  pit        plank bridge on the ground + ladder | hook container
             pump service pier | full-flow long jump to the moving conveyor
  silo       ladder | crate | wall run-up; goal on top
"""
from .common import *

NAME = "factory"
PALETTE = {12: 132, 9: 137, 13: 133, 6: 134, 3: 131, 11: 139, 14: 9}
SKY = (12, 9, 13, 0, 5, 0, 13, 24, 21, 0, 14)
MATS = {
    A: (6, 13, 5, 0x04),      # corrugated walls
    B: (3, 3, 1, 0x18),       # tanks, silo
    PROP: (9, 4, 2, 0x55),    # machines
    BEAM: (9, 5, 5, 0x07),    # oxide-coated steel stays distinct from concrete floors
    TRIM: (13, 5, 5, 0),      # pipes
    CLIMB: (10, 9, 9, 0x02),
    SIGN: (10, 10, 9, 0x04),  # hazard / conveyor
    BOUNCE: (11, 3, 3, 0x38),
    WOOD: (4, 4, 2, 0),
    GLASS: (12, 12, 1, 0x04), # rust containers
    DARK: (13, 0, 0, 0),      # factory floor
    ACCENT: (9, 4, 2, 0x24),  # rust containers
}


def cont(L, x0, z0, y0, n=1, length=12, m=ACCENT):
    """container stack n high, along x"""
    L.box(x0, y0, z0, x0 + length, y0 + 2.5 * n, z0 + 2.5, m)


def build():
    L = Level()
    box, P = L.box, L.prop
    # ---------- floor (pit at x 150..165) ----------
    box(-10, 0, -10, 50, 2, 20, DARK)
    box(50, 0, -10, 110, 2, 30, DARK)
    box(110, 0, -10, 150, 2, 30, DARK)
    box(165, 0, -10, 200, 2, 30, DARK)

    # ---------- warehouse ----------
    box(-.5, 2, -10, 0, 12, 20, A)                    # back wall
    box(0, 2, 19.5, 50, 12, 20, A)                    # north wall
    box(0, 2, -10, 50, 12, -9.5, A)                   # south wall
    box(0, 12, -10, 50, 12.5, 20, A)                  # roof
    L.cp(1, 2, 3, 4, 7, 0)
    L.hint(0, 2, -9.5, 8, 10, 0)
    # ground lane
    box(12, 2, -9.5, 13.5, 3, 12, SIGN, 4)            # machine guard: vault
    box(22, 3, -9.5, 23, 3.5, 12, TRIM)               # pipe: slide
    box(22, 2, 11.5, 23, 3, 12, BEAM)                # pipe hanger leg
    box(30, 2, 0, 31.5, 3.25, 6, WOOD, 4)            # packing crate: vault
    P(38, -2, 2, 6, 10, 3)                            # machine
    L.hint(18, 2, -9.5, 22, 12, 4)
    # catwalk sprint lane (y6) + access
    box(4, 5.75, 16, 48, 6, 19.5, BEAM)              # bolted to warehouse north wall
    box(3.75, 2, 16.5, 4, 6, 18, CLIMB)
    box(14, 2, 11, 16, 3.25, 13, WOOD)                # crate steps north
    box(14, 2, 13, 16, 4.5, 15, WOOD)
    L.hint(2, 2, 12, 8, 19.5, 1)
    L.cp(48, 2, -9, 51, 19, 1)
    L.cp(45, 6, 15, 48, 19, 1)

    # ---------- container yard ----------
    cont(L, 52, 16, 2, 2)                             # expert lane y7
    cont(L, 68, 16, 2, 2, m=GLASS)
    cont(L, 84, 16, 2, 2)
    cont(L, 56, 11, 2, 1, 8, GLASS)                   # middle: single
    cont(L, 70, 11, 2, 1, 8)
    cont(L, 82, 11, 2, 1, 8, GLASS)
    box(54, 2, 11, 56, 3.25, 13.5, WOOD)              # step up
    P(62, 3, 2, 3, 2, 1.25)                           # forklift
    box(75, 2, 0, 77, 3, 8, WOOD)
    box(88, 3.25, -2, 89, 3.75, 9, TRIM)              # low pipe
    for z in (-2, 8.5):
        box(88, 2, z, 89, 3.25, z + .5, BEAM)
    L.hint(50, 7, 16, 54, 18.5, 2)
    L.cp(96, 2, -9, 99, 30, 2)

    # ---------- tanks + pipe rack ----------
    box(98, 2, 18.5, 107.75, 14, 26.5, B)             # tank T1: wallrun
    box(112, 2, 21, 120, 12, 29, B)
    box(124, 2, -8, 132, 12, 0, B)
    L.hint(92, 7, 16, 96, 18.5, 3)
    box(106, 6.5, 16, 150, 7, 18.5, TRIM)             # big pipe: rack top
    box(106, 6.5, 13, 150, 7, 13.5, TRIM)             # small pipe: balance
    for x in (106, 122, 136, 149):
        box(x, 2, 13, x + 1, 6.5, 18, BEAM)           # rack frames
    box(105.75, 2, 16.25, 106, 7, 17.75, CLIMB)       # ladder up
    box(120, 8, 12, 121, 8.5, 22, TRIM)               # pipe feeds tank T2
    box(130, 7, 15.5, 131.5, 8, 18, PROP, 4)          # valve housing: vault
    box(140, 8, 12, 141, 8.5, 19, TRIM)
    for x in (120, 140):
        box(x, 2, 12, x + 1, 8, 12.5, BEAM)         # pipe rack uprights
    L.hint(112, 7, 12, 118, 19, 4)
    L.cp(146, 7, 16, 149, 18.5, 3)
    L.cp(146, 7, 12.75, 149, 13.75, 3)
    L.cp(146, 2, -9, 149, 12, 3)

    # ---------- slag pit + finale ----------
    box(150, 1, 6, 165, 2, 6.5, BEAM)                 # plank bridge
    box(153, 0, 15.5, 155.5, 6.75, 18.5, B)          # pit pump service pier
    box(157, 6.75, 15, 186, 7, 18.5, SIGN, 14)        # working conveyor carries runner east
    for x in (157, 172, 185):
        box(x, 0, 15.5, x + 1, 6.75, 18, BEAM)
    box(166, 2, 14.75, 167.5, 7, 15, CLIMB)           # ladder to conveyor
    L.hint(144, 7, 12, 150, 19, 5)
    box(188, 2, 12, 196, 10, 22, B)                   # silo
    box(187.75, 2, 14, 188, 10, 15.5, CLIMB)
    box(183, 7, 15.5, 185, 8.25, 18, WOOD)
    L.cp(189, 10, 13, 195, 21, 4)

    # ---------- skyline ----------
    for i, (x, z, h) in enumerate(((20, 40, 30), (70, 50, 40), (130, 45, 35), (180, 40, 25),
                                   (60, -30, 30), (140, -30, 28))):
        box(x, 0, z, x + 3, h, z + 3, A if i % 2 else B)   # chimneys
    box(0, 0, 30, 40, 16, 50, A)
    box(90, 0, 40, 120, 20, 60, A)
    box(200, 0, -10, 220, 18, 30, A)
    expand_works(L)
    return L


def expand_works(L):
    """North through the pump works, west through packing, then a high return.

    The former straight conveyor ends halfway through the plant. Functional
    industrial spaces alternate open speed, low machinery, precision and climb.
    """
    b = L.box
    # 1. Silo inspection bridge and pump yard, down to the loading mezzanine.
    b(186, 9.5, 22, 191, 10, 61, BEAM)
    for z in (24, 40, 58):
        b(186, 0, z, 186.5, 9.5, z+.5, BEAM)
        b(190.5, 0, z, 191, 9.5, z+.5, BEAM)
    b(164, 0, 30, 198, 2, 78, DARK)
    b(167, 2, 37, 179, 14, 56, B)
    b(180, 2, 64, 190, 11, 75, B)
    b(188, 11.25, 43, 191, 11.5, 43.75, TRIM)
    b(190.5, 10, 43, 191, 11.25, 43.75, BEAM)
    b(186, 10, 51, 191, 11, 52, PROP, 4)
    b(191, 2, 56, 198, 6, 78, A)  # loading mezzanine bolted to next warehouse
    b(186, 5.5, 61, 198, 6, 64, BEAM)
    b(186, 2, 61, 186.5, 5.5, 64, BEAM)
    b(197.75, 2, 68, 198, 6, 69.5, CLIMB)
    L.cp(192, 6, 68, 197, 73, 5)
    # 2. Packing hall: enter from the south, leave through its west loading door.
    b(160, 0, 78, 198, 6, 115, A)
    b(160, 6, 78, 190, 16, 78.5, A)
    b(197.5, 6, 78, 198, 16, 115, A)
    b(160, 6, 114.5, 198, 16, 115, A)
    b(160, 6, 78, 160.5, 16, 102, A)
    b(160, 6, 109, 160.5, 16, 115, A)
    b(160, 16, 78, 198, 16.5, 115, A)
    # Working belt and guards encourage vault -> slide, then a westward turn.
    b(191, 6, 84, 197.5, 7, 85, SIGN, 4)
    b(191, 7.25, 93, 197.5, 7.5, 94, TRIM)
    b(191, 6, 93, 191.25, 7.25, 94, BEAM)
    b(178, 6, 82, 187, 9, 98, PROP)
    b(169, 6, 89, 175, 10, 100, PROP)
    b(170, 6, 106, 171, 7.25, 114.5, WOOD, 4)
    # Upper inspection walk is a faster climb/balance alternative through the hall.
    b(160.5, 10.75, 111, 197.5, 11, 114.5, BEAM)
    b(194, 6, 110.75, 195.5, 11, 111, CLIMB)
    b(193, 15.75, 84, 195, 16, 88, GLASS)
    b(166, 15.75, 109, 170, 16, 110, GLASS)
    L.cp(183, 6, 103, 189, 109, 6)
    # 3. West receiving dock: container precision or a lower concrete apron.
    b(132, 0, 90, 160, 2, 121, DARK)
    b(134, 2, 99, 156, 6, 109, A)
    b(138, 2, 109, 143, 6, 112, A)  # valve-access apron connects the dock to its fixed ladder
    b(156, 5.75, 102, 160, 6, 103, BEAM)
    b(148, 6, 106, 155, 8.5, 108.5, ACCENT)  # cargo leaves the valve-access apron clear
    b(134, 2, 93, 136, 6, 94.5, CLIMB)
    # A tank farm to the north, reached by a ladder or cat leap onto its valve deck.
    b(132, 0, 121, 194, 2, 124, DARK)
    b(194, 0, 121, 198, 2, 124, DARK)
    b(132, 0, 124, 190, 2, 148, DARK)
    b(134, 2, 112, 156, 12, 140, B)
    b(140, 6, 111.75, 141.5, 12, 112, CLIMB)
    b(149, 6, 109, 154, 9, 112, PROP)
    b(149, 9, 111, 154, 10.25, 112, PROP)
    L.cp(137, 12, 118, 153, 125, 7)
    # 4. Eastward pipe bridge over treatment basins, never an unanchored wall.
    b(156, 11.5, 135, 194, 12, 139, TRIM)
    b(156, 11.75, 130, 194, 12, 130.5, TRIM)
    for x in (157, 172, 190):
        b(x, 2, 130, x+.5, 11.5, 139, BEAM)
    b(168, 12, 135, 169, 13, 139, PROP, 4)
    b(180, 13.25, 135, 181, 13.5, 139, TRIM)
    b(180, 2, 138.5, 181, 13.25, 139, BEAM)
    b(170, 2, 121, 180, 8, 128, B)  # treatment vessels explain the traversing pipes
    b(184, 2, 141, 192, 9, 148, B)
    # 5. The outbound loading line drops east onto cargo, then turns north.
    b(194, 0, 121, 252, 2, 171, DARK)
    b(194, 9.5, 132, 228, 10, 139, SIGN, 14)
    for x in (194, 209, 225):
        b(x, 2, 132, x+.5, 9.5, 139, BEAM)
    b(195, 2, 131.75, 196.5, 10, 132, CLIMB)
    b(232, 2, 132, 247, 7, 138, ACCENT)
    L.cp(211, 10, 132, 224, 138, 8)
    b(232, 2, 142, 251, 11, 164, A)
    b(238, 7, 141.75, 239.5, 11, 142, CLIMB)
    b(232, 2, 138, 234, 7, 142, A)  # loading stair enclosure supplies the safe crossing
    b(236, 2, 138, 242, 7, 142, A)  # warehouse loading dock below the fixed ladder
    b(235, 11, 150, 250, 12, 151, PROP, 4)
    L.cp(237, 11, 145, 247, 149, 9)
    # 6. Return west ABOVE the treatment yard: rooftop intake -> control tower.
    b(194, 2, 150, 228, 15, 171, A)
    b(228, 10.75, 156, 232, 11, 160, BEAM)
    b(228, 11, 157, 228.25, 15, 158.5, CLIMB)
    b(216, 16.25, 150, 217, 16.5, 166, TRIM)
    b(216, 15, 150, 217, 16.25, 150.5, BEAM)
    b(216, 15, 165.5, 217, 16.25, 166, BEAM)
    b(202, 15, 151, 203, 16, 166, PROP, 4)
    b(188, 14.75, 158, 194, 15, 162, BEAM)
    b(170, 0, 152, 188, 20, 172, A)
    b(188, 15, 158, 188.25, 20, 159.5, CLIMB)
    b(171, 20, 167, 184, 23, 169, GLASS)
    L.cp(196, 15, 157, 207, 164, 10)
    L.goal(174, 20, 155, 184, 163)
