"""LEVEL 7 - CLIFF VILLAGE

A mountain settlement on rock ledges above a deep valley: stone, white
houses with flat roofs, wooden bridges, old ladders, ropes and beams.
Style: PRECISION AND VERTICALITY - careful hops, balance, cat leaps and
climbs, with long falls if you miss (a fall respawns at the last flag).
The constructed ladders and the marked rock fissure identify the climbs.

  ravine    plank bridge with rope rails | balance on the rope | run the
            house roof and jump for the far house
  cliff     12m face: zig-zag ladders over wooden shelves | the yellow
            rock crack | jump-grab up the stepped outcrops
  gorge     broken plank bridge (one hop) | beams between rock spires |
            cat-leap across three broad eroded rock outcrops
  village   terraced houses: ladders | crate + jump-grabs | run-ups
  summit    long ladder | run up the ledge and the summit wall
  cave      eastward roll descent, low aqueduct arch | exposed upper trail
  gorge     turn north, climb to the switchback ridge, turn west twice
  hamlet    high bridge | natural buttresses, then village roofs | footpath
  tower     climb north along the ridge, cross east over a suspension bridge,
            then a three-sided bell-tower ascent to the real summit
"""
from .common import *

NAME = "cliff village"
PALETTE = {13: 134, 3: 131, 11: 139, 4: 132}
SKY = (12, 7, 6, 13, 3, 7, 6, 30, 44, 192, 26)
MATS = {
    A: (6, 13, 5, 0x58),      # rock
    B: (4, 7, 6, 0x51),       # white houses, flat roofs
    PROP: (4, 4, 2, 0),       # crates, sheds
    BEAM: (4, 2, 2, 0),       # timber beams
    TRIM: (9, 4, 4, 0),       # ropes, rails
    CLIMB: (4, 9, 4, 0x02),   # weathered timber ladders, rock fissure
    SIGN: (8, 12, 10, 0x03),  # prayer flags
    BOUNCE: (8, 8, 2, 0x78),
    WOOD: (4, 4, 2, 0),       # planks, shelves
    GLASS: (7, 6, 6, 0),      # snow
    DARK: (5, 0, 0, 0),
    ACCENT: (11, 3, 3, 0),    # grass ledges
}


def build():
    L = Level()
    box, P = L.box, L.prop
    # ---------- start ledge + ravine ----------
    box(-4, 0, -8, 12, 6, 8, A)                       # ledge R0 (6)
    L.cp(1, 6, -7, 4, -4, 0)
    L.hint(-4, 6, -8, 12, -2, 0)
    box(6, 6, -4, 11, 9, 8, B)                        # house roof 9
    box(7, 6, -6, 10, 7.25, -4, PROP)                 # crate up
    box(.5, 5.75, 8, 2.5, 6, 14, WOOD)                # bridge
    for x in (.25, 2.5):
        box(x, 6.75, 8, x + .25, 7, 14, TRIM)         # rope rails
        for z in (8, 13.75):
            box(x, 5.75, z, x + .25, 7, z + .25, BEAM)
    box(-2.125, 5.75, 8, -1.875, 6, 14, TRIM)         # rope: balance
    L.hint(-4, 6, 2, 6, 8, 1)
    box(-4, 0, 14, 14, 6, 34, A)                      # ledge R1 (6)
    box(6, 6, 14, 11, 8, 20, B)                       # far house, roof 8
    box(-4, 6, 22, 1, 9.5, 27, B)
    P(2, 18, 6, 1.5, 1.5, 1)
    L.cp(-4, 6, 14, 6, 17, 1)

    # ---------- the cliff: 6 -> 18 at z 34 ----------
    box(-6, 0, 34, 14, 18, 60, A)                     # upper ledge R2 (18)
    box(-5, 9.75, 31, 0, 10, 34, WOOD)                # shelf 10
    box(-4, 6, 30.75, -2.5, 10, 31, CLIMB)
    box(0, 13.75, 31, 5, 14, 34, WOOD)                # shelf 14
    box(-5, 6, 31, -4.75, 9.75, 31.25, BEAM)        # cliff scaffold uprights
    box(4.75, 6, 31, 5, 13.75, 31.25, BEAM)
    box(-.25, 10, 32, 0, 14, 33.5, CLIMB)
    box(2, 14, 33.75, 3.5, 18, 34, CLIMB)
    box(5.5, 6, 33.75, 7, 18, 34, CLIMB)              # fixed ladder along natural fissure
    box(9, 6, 29, 13, 8.5, 34, A)                     # outcrops
    box(8.5, 8.5, 30.5, 12.5, 11, 34, A)
    box(9.5, 11, 31.75, 13.5, 13.5, 34, A)
    box(9, 13.5, 32.5, 13, 16, 34, A)               # enough depth for both feet after the cat leap
    L.hint(-4, 6, 26, 14, 30, 2)
    L.cp(-6, 18, 34, 14, 37, 2)
    box(-5, 18, 44, -1, 21, 49, B)
    P(8, 46, 18, 2, 2, 1.25)

    # ---------- the gorge (z 60..86) at 18 ----------
    # Weathered planks separate along the old joints. Each section only
    # falls after the runner has left it; the stone buttress route survives.
    bridge_planks = []
    for z0, z1 in ((60, 65), (65, 70), (70, 72), (74, 80), (80, 86)):
        bridge_planks.append(box(0, 17.75, z0, 1.5, 18, z1, WOOD))
    for plank in bridge_planks:
        L.event(plank, 2, travel=-12, duration=2, dwell=0,
                radius=4, delay=1.25)
    for x in (-.25, 1.5):
        box(x, 18.75, 60, x + .25, 19, 86, TRIM)
    box(0, 18, 85.75, 1.5, 20, 86, CLIMB)
    box(6, 17.75, 60, 6.75, 18, 70, BEAM)             # timber beams + stone piers
    box(5, 0, 70, 7.5, 18.5, 72.5, A)
    box(6, 18.25, 72.5, 6.75, 18.5, 78, BEAM)
    box(5, 0, 78, 7.5, 19, 80.5, A)
    box(6, 18.75, 80.5, 6.75, 19, 86, BEAM)
    # The eastern route crosses eroded buttresses, not a row of tiny squares.
    for x, z, w, d, h in ((9.5, 62, 4, 6, 18.25), (10, 71, 4, 5, 19),
                          (9, 79, 4.5, 5, 19.75)):
        box(x, 0, z, x + w, h, z + d, A)
    for x in (-.25, 1.5):
        for z in (60, 85.75):
            box(x, 18, z, x + .25, 19, z + .25, BEAM)  # suspension rail anchors
    L.hint(-6, 18, 54, 14, 60, 3)

    # ---------- upper village (z 86..112) at 20 ----------
    box(-6, 0, 86, 14, 20, 112, ACCENT)               # grass terrace R3
    L.cp(-6, 20, 86, 14, 89, 3)
    L.hint(-6, 20, 89, 14, 91, 4)
    box(-4, 20, 92, 6, 23, 98, B)                     # terraced houses
    box(-4, 20, 98, 6, 25.5, 104, B)
    box(-4, 20, 104, 6, 28, 112, B)
    box(-3, 20, 91.75, -1.5, 23, 92, CLIMB)           # ladders
    box(-3, 23, 97.75, -1.5, 25.5, 98, CLIMB)
    box(-3, 25.5, 103.75, -1.5, 28, 104, CLIMB)
    box(2, 20, 90, 4, 20.75, 92, PROP)                # crate
    box(6, 22.75, 100, 7.5, 23, 103, WOOD)            # balcony
    box(8, 20, 96, 12, 22.5, 100, PROP)               # goat shed
    box(6, 25.75, 105, 10, 26, 105.25, TRIM)         # washing line, house to stone tower
    box(10, 20, 104, 14, 26, 108, A)                  # stone tower

    # ---------- summit (z 112..150) ----------
    box(-6, 0, 112, 14, 28, 130, A)                   # R4 (28)
    L.cp(-6, 28, 112, 14, 115, 4)
    box(-6, 0, 130, 10, 34, 150, GLASS)               # snowy summit (34)
    box(-2, 28, 129.75, -.5, 34, 130, CLIMB)          # long ladder
    box(4, 28, 128, 9, 31, 130, A)                    # ledge (31)
    L.hint(-6, 28, 120, 14, 126, 5)
    box(0, 34, 140, 4, 37, 144, B)                    # stupa
    for x in (-4, 8):
        box(x, 34, 138, x + .25, 38, 138.25, TRIM)     # flag poles
    box(-3.75, 37.25, 138, 8, 37.5, 138.25, SIGN, 1)  # prayer flags
    L.cp(-4, 34, 132, 8, 137, 5)

    # ---------- eastward descent into the old aqueduct cave ----------
    # The summit was only the first ridge. The bell tower is now visible
    # across the valley; the route drops under a rock overhang to reach it.
    box(10, 29.5, 144, 19, 30, 152, WOOD)
    box(18, 0, 142, 58, 30, 158, A)
    for x in (10, 17):
        box(x, 0, 145, x + 1, 29.5, 146, BEAM)
        box(x, 0, 150, x + 1, 29.5, 151, BEAM)
    box(20, 30, 142, 58, 39, 144, A)
    box(20, 30, 156, 50, 39, 158, A)
    box(20, 37.5, 144, 58, 39, 156, A)
    # A former aqueduct depot is built into the cave mouth. A framed door,
    # work bench, stone partition and opposite exit make this an occupied
    # mountain building; the natural low arch remains deeper inside.
    for z in (144, 152.5):
        box(20, 30, z, 20.5, 34, z + 3.5, B)
    box(20, 33.5, 147.5, 20.5, 36, 152.5, WOOD)
    box(21, 29.75, 144, 34, 30, 156, WOOD)
    box(31, 30, 144, 31.5, 34, 147, B)
    box(31, 30, 153, 31.5, 34, 156, B)
    P(24, 145, 30, 5, 1.25, 1)              # aqueduct maintenance workbench
    box(21, 34, 144, 34, 34.5, 144.5, WOOD)    # timber roof ties in masonry
    # Natural low arch, grounded rock ribs, timber supply crate.
    box(36, 31.25, 144, 38, 37.5, 156, A)
    box(36, 30, 144, 38, 31.25, 144.25, A)
    box(36, 30, 155.75, 38, 31.25, 156, A)
    P(27, 147, 30, 1.25, 6, 1)
    L.cp(22, 30, 145, 29, 155, 6)
    # Upper trail offers exposed cat leaps instead of the cave's low arch.
    box(19.75, 30, 144, 20, 39, 145.5, CLIMB)
    box(25, 39, 142, 29, 41, 145, A)
    box(35, 39, 142, 40, 41, 145, A)

    # ---------- turn north: a walled gorge opens onto the eastern ridge ----------
    box(50, 0, 158, 60, 30, 186, A)
    box(48, 30, 158, 50, 44, 186, A)
    box(60, 0, 158, 66, 40, 186, A)
    # Loose stone sits on the western cliff lip, then drops into the path
    # ahead. An old maintenance ledge on the east is already visible, with
    # a fixed ladder at its approach and room to land after the obstruction.
    rockfall = box(50, 38, 173, 58, 42, 178, A)
    L.event(rockfall, 6, travel=-8, duration=1.5, dwell=0,
            radius=14, delay=2.5)
    box(58, 30, 167, 60, 32.5, 171, A)
    box(58, 32, 171, 60, 32.5, 181, WOOD)
    box(58.5, 30, 166.75, 59.75, 32.5, 167, CLIMB)
    box(50, 30, 186, 62, 34, 202, A)
    box(53, 30, 185.75, 54.5, 34, 186, CLIMB)
    box(57, 30, 184, 60, 32.5, 186, A)          # ledge-grab alternative
    box(50, 0, 186, 62, 30, 202, A)
    L.cp(50, 34, 190, 61, 198, 7)

    # ---------- switchback cliff: turn west and gain another eight metres ----------
    box(38, 0, 194, 50, 38, 210, A)
    box(50, 34, 199, 50.25, 38, 200.5, CLIMB)
    box(26, 0, 202, 38, 42, 216, A)
    box(38, 38, 205, 38.25, 42, 206.5, CLIMB)
    box(18, 0, 204, 26, 42, 218, A)
    # A lower timber maintenance gallery zigzags around the cliff instead.
    box(38, 33.5, 191, 54, 34, 194, WOOD)
    box(35, 33.5, 191, 38, 34, 205, WOOD)
    box(35, 34, 201.75, 36.5, 42, 202, CLIMB)
    for x, z in ((38, 191), (52, 191), (35, 197)):
        box(x, 0, z, x + .5, 33.5, z + .5, BEAM)
    L.cp(19, 42, 205, 26, 213, 8)

    # ---------- high gorge: bridge, balance rail, or eroded rock buttresses ----------
    box(-2, 41.5, 207, 18, 42, 211, WOOD)
    box(-22, 41.5, 207, -5, 42, 211, WOOD)
    box(-5, 41.75, 210.75, -2, 42, 211, BEAM)    # surviving timber stringer
    for x in (-22, -12, 4, 16):
        box(x, 0, 207, x + .75, 41.5, 207.75, BEAM)
        box(x, 0, 210.25, x + .75, 41.5, 211, BEAM)
    # Irregular natural stepping rocks lie beside the bridge, never in a grid.
    for x, z, w, h in ((9, 218, 6, 41), (-1, 217, 7, 42), (-11, 216, 7, 41),
                        (-19, 216, 5, 41)):
        box(x, 0, z, x + w, h, z + 6, A)
    box(16, 41.5, 211, 19, 42, 219, WOOD)
    box(-22, 40.5, 211, -18, 41, 223, WOOD)

    # ---------- upper hamlet: roofs are a shortcut over the hillside footpath ----------
    box(-46, 0, 202, -22, 42, 238, ACCENT)
    L.cp(-42, 42, 204, -24, 211, 9)
    box(-41, 42, 214, -33, 45, 221, B)
    box(-31, 42, 221, -24, 44.5, 230, B)
    box(-42, 42, 225, -34, 46, 233, B)
    box(-40, 42, 213.75, -38.5, 45, 214, CLIMB)
    box(-31.25, 42, 224, -31, 44.5, 225.5, CLIMB)
    P(-40, 221, 42, 2, 2, 1)
    box(-42, 45, 218, -41, 51, 219, TRIM)        # settlement bell support
    box(-45, 42, 211, -44.5, 47, 211.5, BEAM)
    box(-45, 46.75, 211, -22, 47, 211.25, SIGN, 2)
    box(-22.5, 42, 211, -22, 47, 211.5, BEAM)

    # ---------- north ridge: cliff path and facade cat leaps ----------
    box(-46, 0, 238, -30, 46, 274, A)
    box(-44, 42, 237.75, -42.5, 46, 238, CLIMB)
    box(-37, 42, 234, -32, 44, 238, A)
    box(-46, 46, 246, -40, 48.5, 251, A)
    box(-36, 46, 258, -30, 49, 264, A)
    box(-46, 47.25, 269, -30, 48, 270, WOOD)     # old low gate beam: slide
    for x in (-46, -30.5):
        box(x, 46, 269, x + .5, 47.25, 270, BEAM)
    L.cp(-44, 46, 260, -38, 268, 10)

    # ---------- eastward suspension bridge and the bell-tower ascent ----------
    box(-30, 45.5, 270, -8, 46, 274, WOOD)
    box(-5, 45.5, 270, 14, 46, 274, WOOD)
    box(-8, 45.75, 273.75, -5, 46, 274, BEAM)
    for x in (-30, -19, 2, 12):
        box(x, 0, 270, x + .75, 45.5, 270.75, BEAM)
        box(x, 0, 273.25, x + .75, 45.5, 274, BEAM)
    box(14, 0, 262, 32, 46, 290, A)
    box(17, 46, 262, 23, 50, 270, B)
    box(19, 46, 270, 20.5, 50, 270.25, CLIMB)
    box(23, 46, 262, 28, 54, 270, B)
    box(22.75, 50, 264, 23, 54, 265.5, CLIMB)
    box(23, 46, 270, 30, 58, 282, B)
    box(25, 54, 269.75, 26.5, 58, 270, CLIMB)
    # Alternate ledge chain hugs the same tower, with broad enough landings.
    box(28, 46, 263, 32, 48.5, 267, A)
    box(28, 48.5, 267, 32, 51, 270, A)
    box(30, 51, 270, 33, 53.5, 273, WOOD)
    box(30, 53.5, 273, 33, 56, 276, WOOD)
    box(25, 58, 279, 26, 63, 280, BEAM)
    box(27, 58, 279, 28, 63, 280, BEAM)
    box(25, 62, 279, 28, 63, 280, WOOD)
    L.cp(14, 46, 271, 21, 281, 11)
    L.goal(23, 58, 272, 30, 278)

    # ---------- far peaks ----------
    box(-50, 0, 40, -30, 50, 70, A)
    box(-46, 50, 46, -34, 56, 64, GLASS)
    box(34, 0, 80, 56, 46, 110, A)
    box(38, 46, 86, 52, 52, 104, GLASS)
    box(-40, 0, 150, -16, 60, 180, A)
    box(20, 0, 160, 44, 40, 184, A)
    return L
