"""One module per level; build.py packs them into cart memory."""
ORDER = ["l1_oldcity", "l2_construction", "l3_factory", "l4_underground",
         "l5_downtown", "l6_neon", "l7_cliffs", "l8_mega"]
CAMPAIGN = [0, 4, 3, 1, 2, 5, 6, 7]

CARTRIDGES = ["old_city", "construction", "factory", "subway", "downtown",
              "neon", "mountain", "megastructure"]
