"""LEVEL 6 - NEON DISTRICT

Night. Dark facades with lit windows, neon billboards, steel service walks;
roofs stay light so every surface reads against the navy fog. Style:
SPEED - a long descending rooftop line where a good run never stops:
long runways, long wallruns, big gaps.

  launch    roof at 24: speed vault, slide, 6m gap down to 22 (or the
            hanging sign bridge)
  alley     14m gap: wallrun the billboard | its maintenance balconies |
            balance the beam
  highway   wide roof at 20; the bar kiosk bounces you onto the high
            roof (23) for the expert line
  big gap   6.5m: full-speed long jump | from the high roof with a roll |
            lower shop annex roofs
  rail      elevated track: sprint the deck (vault, slide) | wallrun the
            train | run its roof
  finale    leap from the train roof to the tower | run up the sign
            block and the tower face | ladders
  hotel     turn east through a sign court, then north along alley roofs
  interior  turn west through the service hall | upper plant-room shortcut
  escape    switchback fire escape | facade ventilation cat leaps
  return    west across a high skybridge, south along technical roofs,
            then climb the hotel roof: the actual finish
"""
from .common import *

NAME = "neon district"
PALETTE = {11: 139, 6: 134, 9: 136}
SKY = (0, 1, 2, 1, 0, 7, 1, 32, 39, 192, 18)
MATS = {
    A: (13, 1, 2, 0xa1),      # roofs, lit windows (yellow)
    B: (13, 2, 1, 0xe1),      # roofs, lit windows (pink)
    PROP: (6, 13, 5, 0x55),   # AC units, kiosks
    BEAM: (6, 5, 1, 0),       # structural steel, restrained highlights
    TRIM: (6, 13, 13, 0),     # pipes, gantries
    CLIMB: (6, 5, 5, 0x02),
    SIGN: (13, 1, 1, 0xe5),  # dark sign housings with small neon insets
    BOUNCE: (14, 14, 2, 0x78),
    WOOD: (4, 4, 2, 0),       # water tanks
    GLASS: (12, 1, 1, 0xc1),  # glass tower, skylights
    DARK: (5, 0, 0, 0),       # pillars, poles
    ACCENT: (6, 1, 13, 0xc5),   # train, lit windows
}


def build():
    L = Level()
    box, P = L.box, L.prop
    # ---------- launch: roof R1 at 24 ----------
    box(-2, 0, -6, 14, 24, 32, A)
    L.cp(4, 24, -5, 8, -2, 0)
    L.hint(-2, 24, -6, 14, 2, 0)
    P(2, 8, 24, 8, 1.5, 1)                            # AC: speed vault
    box(-2, 25.25, 18, 14, 25.75, 18.5, TRIM)         # pipe: slide
    for x in (-2, 13.75):
        box(x, 24, 18, x + .25, 25.25, 18.5, TRIM)
    L.tank(9.5, 24, 24)
    box(14, 14, 6, 14.75, 22, 7.5, SIGN, 1)           # blade signs
    box(-2.75, 12, 20, -2, 21, 21.5, SIGN, 2)
    box(-1, 21, 32, 1, 22, 38, B)                     # enclosed bridge between facades
    box(12.5, 24, 2, 13.5, 31, 3, SIGN, 1)            # rooftop blade sign

    # ---------- R2 at 22 ----------
    box(-2, 0, 38, 14, 22, 70, B)
    L.cp(-2, 22, 38, 14, 41, 1)
    box(3, 22, 44, 9, 22.75, 48, GLASS)               # skylight: vault
    box(-2, 23.25, 60, 8, 26, 60.25, SIGN, 3)         # billboard: slide
    for x in (-2, 7.75):
        box(x, 22, 60, x + .25, 23.25, 60.25, BEAM)
    L.hint(-2, 22, 62, 14, 70, 1)
    box(-2, 22, 40, -1.75, 27, 52, SIGN, 2)           # side billboard
    # alley gap z 70..84
    box(12, 19, 70, 12.5, 25, 84, SIGN)               # wallrun billboard
    box(12, 0, 76.5, 12.5, 19, 77.5, DARK)
    # Billboard maintenance balconies attach to its structural face.
    # One three-metre gap, with room to prepare and recover on either side.
    box(8, 21.25, 70, 12, 21.5, 75, BEAM)
    box(8, 20.25, 78, 12, 20.5, 84, BEAM)
    box(0, 21.75, 70, .5, 22, 84, BEAM)               # beam: balance

    # ---------- highway: R3 at 20 ----------
    box(-6, 0, 84, 14, 20, 130, A)
    L.cp(-6, 20, 84, 14, 87, 2)
    box(8, 20, 97, 14, 20.75, 100, PROP)              # bar kiosk
    box(8, 20.75, 97, 14, 21, 100, BOUNCE)            # its awning
    box(8, 20, 100, 14, 23, 130, B)                   # high roof (23)
    box(13.75, 23, 112, 14, 26, 112.25, TRIM)         # antenna
    box(-6, 20, 96, -5.75, 25, 108, SIGN, 3)          # side billboard
    P(-4, 92, 20, 3, 2, 1)                            # AC units
    P(0, 104, 20, 2, 3, 1.25)
    P(-5, 114, 20, 2, 2, 1)
    L.tank(-3, 120, 20)
    box(1, 20, 108, 3, 20.75, 112, GLASS)
    L.hint(-6, 20, 86, 14, 92, 2)
    # Street gap z 130..136.5: visible landing, reachable at full running speed.
    box(-4, 0, 130, 0, 19.5, 134.5, B)              # shop annex roofs under the express line
    box(-4, 0, 136, 0, 19.25, 139, B)

    # ---------- R4 at 19, then the elevated rail ----------
    box(-6, 0, 136.5, 14, 19, 160, B)
    L.cp(-6, 19, 136.5, 14, 139.5, 3)
    P(6, 148, 19, 4, 1.5, 1)
    box(-6, 20.25, 154, 0, 20.75, 154.5, TRIM)
    for x in (-6, -.25):
        box(x, 19, 154, x + .25, 20.25, 154.5, TRIM)
    L.hint(-6, 19, 152, 14, 160, 3)
    box(12.5, 19, 141, 13.5, 26, 142, SIGN, 2)
    box(0, 15.5, 160, 8, 16, 200, A)                  # track deck (16)
    for z in (172, 188):
        box(3, 0, z, 5, 15.5, z + 2, DARK)            # pillars
    # A short two-car urban tram follows the elevated guideway. The outer
    # inspection walk stays open: riding is an express choice, never a timer.
    tram_a = box(.5, 16, 164, 3.5, 19, 176, ACCENT)
    tram_b = box(.5, 16, 178, 3.5, 19, 190, ACCENT)
    for car in (tram_a, tram_b):
        L.event(car, 1, axis=3, travel=6, duration=5, dwell=2,
                radius=255, delay=1)
    for x in (1, 3):
        box(x, 15.75, 160, x + .25, 16, 200, BEAM)
    box(5, 16, 176, 7, 17, 177.5, PROP, 4)            # signal box: vault
    box(3.5, 17.25, 186, 8, 17.75, 186.5, TRIM)       # gantry: slide
    box(7.75, 16, 186, 8, 17.25, 186.5, TRIM)
    L.cp(0, 16, 160, 8, 163, 4)

    # ---------- finale: neon tower ----------
    box(-4, 0, 200, 12, 22, 220, GLASS)               # tower, top 22
    box(3, 16, 197, 8, 19, 200, SIGN, 3)              # sign block (19)
    box(5, 16, 196.75, 6.5, 19, 197, CLIMB)           # ladders
    box(4, 19, 199.75, 5.5, 22, 200, CLIMB)
    L.hint(0, 16, 190, 8, 196, 4)
    L.cp(-2, 22, 201, 10, 209, 5)

    # ---------- sign court: turn east off the former finish ----------
    # Low shopping roofs connect real tower bases. Their north parapet line
    # points across the street to the tall vertical hotel sign.
    box(12, 0, 210, 38, 22, 224, B)
    box(42, 0, 208, 76, 21, 236, A)
    box(37, 16, 219, 43, 20, 224, B)             # lower shop canopy alternative
    box(37, 20, 221, 38, 22, 223, CLIMB)
    P(21, 213, 22, 1.25, 7, 1)
    box(31, 23.25, 210, 31.5, 23.75, 224, TRIM)
    box(31, 22, 210, 31.5, 23.25, 210.25, BEAM)
    box(31, 22, 223.75, 31.5, 23.25, 224, BEAM)
    hotel_sign = box(47, 21, 230, 49, 37, 231, SIGN, 2)
    # The hotel advertising circuit dips for three seconds. Roof, window
    # and street lighting stay on: this is atmosphere, not a blind jump.
    L.event(hotel_sign, 7, duration=3, dwell=0, radius=24, delay=.75)
    box(50, 21, 232, 65, 24, 236, B)              # projecting hotel plant room
    L.cp(44, 21, 209, 54, 221, 6)

    # ---------- alley: north along densely packed service roofs ----------
    # A fast three-metre roof gap runs beside the hotel wall. A narrow
    # maintenance walk on the opposite facade is the slower balance route.
    box(60, 0, 236, 62, 27, 280, B)
    box(70, 0, 236, 76, 26, 280, A)
    box(62, 0, 236, 70, 18, 251, B)
    box(62, 0, 254, 70, 18, 280, B)
    box(60, 17.75, 251, 62.75, 18, 254, BEAM)
    P(63, 260, 18, 5, 1.25, 1)
    box(62, 19.25, 268, 70, 19.75, 268.5, TRIM)
    box(62, 18, 268, 62.25, 19.25, 268.5, TRIM)
    box(69.75, 18, 268, 70, 19.25, 268.5, TRIM)
    box(70, 24, 249, 71, 34, 251, SIGN, 1)
    L.cp(63, 18, 272, 69, 279, 7)

    # ---------- high-rise office: window, desks, corridor, conference room ----------
    # North-facing office windows open onto the alley roofs. Opposite west
    # windows lead directly to the fire escape, with control throughout.
    box(24, 0, 280, 76, 18, 294, A)
    box(24, 18, 293, 76, 25, 294, DARK)
    box(24, 18, 280, 61, 25, 281, DARK)
    box(24, 24.5, 280, 76, 25, 294, B)
    for x in (30, 56):
        box(x, 21.5, 292.75, x + 7, 22, 293, SIGN, 1)
    # Glass partitions flank a four-metre corridor; their openings align
    # with the opposite window, so the exit is visible at running speed.
    for x in (40, 48):
        box(x, 18, 281, x + .25, 22, 284, GLASS)
        box(x, 18, 288, x + .25, 22, 293, GLASS)
        box(x, 21.5, 284, x + .25, 22, 288, BEAM)
    for x in (24, 75.75):
        box(x, 18, 281, x + .25, 24.5, 284, GLASS)
        box(x, 18, 289, x + .25, 24.5, 293, GLASS)
        box(x, 21.5, 284, x + .25, 24.5, 289, GLASS)
    box(62, 18, 280, 70, 18.5, 280.25, BEAM)     # open window sill: jump in
    box(62, 21.5, 280, 70, 24.5, 280.25, GLASS)
    box(43, 19.25, 281, 43.5, 19.75, 293, TRIM)
    box(43, 18, 281, 43.5, 19.25, 281.25, TRIM)
    box(43, 18, 292.75, 43.5, 19.25, 293, TRIM)
    P(52, 283, 18, 1.25, 7, 1)                   # long office desk
    P(31, 284, 18, 1.25, 5, 1)                   # conference table
    P(58, 290, 18, 5, 1.25, .75)                 # side desks frame the route
    # Optional upper plant-room shortcut enters through a fixed side ladder.
    box(68, 18, 293.75, 69.5, 25, 294, CLIMB)
    box(30, 25, 287, 31, 34, 288, SIGN, 3)

    # ---------- external fire escape: 18 -> 30, with a visible landing ----------
    box(12, 0, 278, 18, 30, 300, B)
    box(18, 17.5, 280, 24, 18, 294, BEAM)
    box(18, 18, 280, 24, 22, 284, A)
    box(20, 18, 284, 21.5, 22, 284.25, CLIMB)
    box(18, 22, 278, 24, 26, 280, A)
    box(20, 22, 280, 21.5, 26, 280.25, CLIMB)
    box(18, 26, 278, 18.25, 30, 279.5, CLIMB)
    # Cat-leap choice on facade-mounted ventilation housings.
    box(18, 18, 289, 21, 20.5, 292, PROP)
    box(18, 20.5, 289, 20.5, 23, 292, PROP)
    box(18, 23, 287, 20.5, 25.5, 290, PROP)
    box(18, 25.5, 284.5, 20.5, 28, 287.5, PROP)
    L.cp(12, 30, 280, 18, 288, 8)

    # ---------- skybridge: west across the same alley, much higher ----------
    box(-4, 29.5, 280, 12, 30, 286, BEAM)
    box(-30, 29.5, 280, -7, 30, 286, BEAM)
    box(-7, 29.75, 285, -4, 30, 286, TRIM)        # flange leaves shoulder clearance beside glazing
    for x in (-28, -16, 2):
        box(x, 0, 280, x + 1, 29.5, 281, DARK)
        box(x, 0, 285, x + 1, 29.5, 286, DARK)
    box(-30, 30, 286, 12, 32, 286.5, GLASS)        # northern glazing is also wallrun surface
    P(-18, 281, 30, 1.25, 3, 1)

    # ---------- roof return: south, overlooking the original rail line ----------
    box(-42, 0, 252, -30, 28, 286, A)
    box(-42, 0, 220, -30, 28, 249, B)
    box(-42, 25.5, 249, -40, 26, 252, B)          # service ledge alternate, fixed to facade
    box(-42, 26, 248.75, -40.5, 28, 249, CLIMB)
    P(-39, 266, 28, 6, 1.25, 1)
    box(-42, 29.25, 260, -30, 29.75, 260.5, TRIM)
    for x in (-42, -30.25):
        box(x, 28, 260, x + .25, 29.25, 260.5, TRIM)
    L.cp(-41, 28, 272, -31, 279, 9)
    box(-48, 0, 208, -30, 36, 220, GLASS)
    box(-36, 28, 220, -34.5, 36, 220.25, CLIMB)
    box(-42, 28, 222, -39, 30.5, 225, PROP)
    box(-42, 30.5, 220, -39, 33, 222, PROP)
    box(-48, 36, 210, -47, 47, 212, SIGN, 2)
    L.goal(-46, 36, 210, -32, 218)

    # Short neutral parapet caps frame takeoffs; neon stays on actual signs.
    for x0, x1, y, z0, z1, m in ((-2, 14, 24, -6, 32, BEAM), (-2, 14, 22, 38, 70, SIGN),
                                 (-6, 14, 20, 84, 130, BEAM), (-6, 14, 19, 139, 160, SIGN)):
        box(x0, y, z1 - 6, x0 + .25, y + .25, z1, TRIM)
        box(x1 - .25, y, z1 - 6, x1, y + .25, z1, TRIM)
    # ---------- skyline ----------
    box(-30, 0, 20, -18, 40, 32, B)
    box(26, 0, 50, 38, 45, 62, A)
    box(-28, 0, 100, -16, 36, 114, GLASS)
    box(28, 0, 120, 40, 50, 132, B)
    box(-24, 0, 170, -12, 42, 182, A)
    box(24, 0, 196, 36, 38, 208, GLASS)
    return L
