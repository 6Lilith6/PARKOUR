"""Cross-level release checks: safe restart, route direction, visual contrast.

This runs the actual distributed carts. It does not replace route replays or
claim a human playthrough, native PICO-8 frame rate, or subjective play duration.
"""
from math import dist
from cartpaths import NAMES, cart_path
from sim import Pico


def luminance(rgb):
    channels = [v / 255 for v in rgb]
    channels = [v / 12.92 if v <= .04045 else ((v + .055) / 1.055) ** 2.4 for v in channels]
    return sum(a*b for a, b in zip(channels, (.2126, .7152, .0722)))


def check():
    failures = []
    for level, name in enumerate(NAMES):
        pc = Pico(cart_path(level))
        checkpoints = sorted([b for b in pc.g.trig.values() if b.m == 11], key=lambda b: b.k)
        ids = sorted({b.k for b in checkpoints})  # alternate paths may share a section ID
        assert ids == list(range(len(ids))), name + ': checkpoint numbering'
        assert sum(b.m == 12 for b in pc.g.trig.values()) == 1, name + ': unique finish'
        for b in checkpoints:
            x, y, z = (b[1]+b[4])/2, b[2], (b[3]+b[6])/2
            pc.L.execute('cp={%s,%s,%s,.75} mode="play" respawn()' % (x, y, z))
            pc.run(45)
            if abs(pc.g.py-y) > .1 or pc.g.phit():
                failures.append((name, int(b.k), (x,y,z), pc.state()))
        pc.g.restart()
        pc.g.mode = 'play'
        pc.run(3600, ['up'])
        assert pc.g.mode != 'done', name + ': finished by only holding forward'
        print('PASS', name, len(checkpoints), 'checkpoints; forward alone does not finish')
    assert not failures, 'Unsafe checkpoint centres: ' + repr(failures)

    pc = Pico(cart_path(1))
    void = pc.rgb(int(pc.g.sk[5]))
    tops = {m: pc.rgb(int(pc.g.mats[m][1])) for m in (1, 4, 9)}
    for material, top in tops.items():
        ratio = (luminance(top)+.05)/(luminance(void)+.05)
        assert ratio > 4, ('construction depth contrast', material, ratio)
    assert dist(tops[1], tops[4]) > 150, 'steel blends into concrete'
    assert luminance(pc.rgb(int(pc.g.mats[1][1]))) > luminance(pc.rgb(int(pc.g.mats[1][2]))), 'flat concrete shading'
    print('PASS construction: bright concrete, ochre beams, timber and dark depth are separated')
    for level in (2, 3):
        pc = Pico(cart_path(level))
        floor = pc.rgb(int(pc.g.mats[1][1]))
        steel = pc.rgb(int(pc.g.mats[4][1]))
        assert dist(floor, steel) > 100, NAMES[level] + ': steel blends into concrete'
    print('PASS factory/subway: beam top colour remains distinct from floor colour')


if __name__ == '__main__':
    check()
