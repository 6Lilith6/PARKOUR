"""Render reproducible, in-engine views of all eight redesigned routes."""
from pathlib import Path
from PIL import Image, ImageDraw
from sim import Pico
from cartpaths import cart_path

ROOT = Path(__file__).resolve().parents[1]
SPOTS = [
    ("OLD CITY / ROOF FLOW", 10, 14, 25, .75),
    ("CONSTRUCTION / SCAFFOLDS", 17, 17, 27, 0),
    ("FACTORY / CONTAINER YARD", 75, 7, 17.25, 0),
    ("SUBWAY / CARRIAGE ROOFS", 11, 5.5, 21, .75),
    ("DOWNTOWN / BUS TO CANOPY", 11, 5.5, 37, .75),
    ("NEON / BILLBOARD BALCONIES", 10, 21.5, 73, .75),
    ("MOUNTAIN / ROCK BUTTRESSES", 11.75, 18.25, 66, .75),
    ("MEGASTRUCTURE / CORE", 20, 26, 32, .25),
]

EXPANDED_SPOTS = [
    ("OLD CITY / REAR COURTYARD", 110, 8, 220, .75),
    ("CONSTRUCTION / UPPER TRUSS", 28, 38, 62, .5),
    ("FACTORY / PACKING HALL", 194, 6, 89, .75),
    ("SUBWAY / SECOND STATION", 80.75, 9.25, 232, .75),
    ("DOWNTOWN / OFFICE CROSSING", 23, 19, 174.5, .5),
    ("NEON / SERVICE ROOFS", 66, 18, 260, .75),
    ("MOUNTAIN / UPPER GORGE", 16, 42, 209, .5),
    ("MEGASTRUCTURE / HIGH RETURN", -25, 78, 118, 0),
]


def build_preview(spots=SPOTS, name="levels.png"):
    sheet = Image.new("RGB", (1024, 560), (17, 22, 31))
    labels = ImageDraw.Draw(sheet)
    for level, (title, x, y, z, heading) in enumerate(spots):
        pc = Pico(cart_path(level))
        pc.g.mode = "play"
        pc.teleport(x, y, z, heading)
        pc.L.execute("bang=ang fade=0 hint=nil shy=py for i=1,30 do anim() camupd() end")
        pc.g.render()
        shot = pc.image(2)
        xx, yy = (level % 4) * 256, (level // 4) * 280
        sheet.paste(shot, (xx, yy + 24))
        labels.text((xx + 7, yy + 7), title, fill=(223, 230, 238))
        if level == 3 and name == "levels.png":
            pc.image(4).save(ROOT / "docs" / "subway.png")
    sheet.save(ROOT / "docs" / name)
    return ROOT / "docs" / name


if __name__ == "__main__":
    print(build_preview())
    print(build_preview(EXPANDED_SPOTS, "expanded-levels.png"))
