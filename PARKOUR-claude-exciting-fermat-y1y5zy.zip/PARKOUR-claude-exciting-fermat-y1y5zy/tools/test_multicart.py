"""Validate isolated level data, launcher transitions and section scores.

Run after tools/build.py. Use --draft for .tools/draft iteration artifacts.
Native cart budget validation is performed by the builder itself.
"""
import argparse
import importlib
from pathlib import Path
import struct

import p8mem
from build import CARTRIDGES, ROOT, ORDER, level_blob
from music import score
from sim import Pico


def check(draft=False):
    root = Path(ROOT, ".tools", "draft") if draft else Path(ROOT)
    soundtrack_hashes = set()
    for i, name in enumerate(CARTRIDGES):
        text = (root / (name + ".p8")).read_text(encoding="utf-8")
        rom = p8mem.sections_to_rom(text)
        address = struct.unpack_from("<H", rom)[0]
        module = importlib.import_module("levels." + ORDER[i])
        blob, box_count = level_blob(module)
        assert address == 0x10 and rom[address:address + len(blob)] == blob, name
        assert not any(rom[address + len(blob):0x3100]), "other geometry leaked into " + name
        sounds, patterns = score(i)
        assert len(sounds) == 52 and set(sounds) == set(range(12, 64))
        assert len(patterns) == 32
        for act in range(4):
            assert patterns[act * 8][0] == 1
            assert patterns[act * 8 + 7][0] == 2
        for p, (flags, channels) in enumerate(patterns):
            packed = bytes(sid | ((flags >> channel) & 1) << 7
                           for channel, sid in enumerate(channels))
            assert rom[p8mem.MUSIC + p * 4:p8mem.MUSIC + p * 4 + 4] == packed
        soundtrack_hashes.add(bytes(rom[p8mem.MUSIC:]))

        pc = Pico(root / (name + ".p8"))
        assert pc.g.lv == i and pc.g.cart_lv == i
        assert len(pc.g.boxes) + len(pc.g.trig) == box_count
        assert pc.g.mode == "title"
        pc.step(["z"])
        assert pc.g.mode == "play", name + ": start button did not start standalone cart"
        pc.step([])
        pc.g.setlv((i + 1) % 8)
        assert pc.g.lv == i, "standalone unexpectedly loaded a different level"
        played = []
        for checkpoint in range(int(pc.g.cart_cp) + 1):
            pc.g.cpi = checkpoint
            pc.g.scoremusic()
            if not played or played[-1] != pc.g.musphase:
                played.append(pc.g.musphase)
        assert played == [0, 8, 16, 24], (name, played)
        assert all(call[3] == 7 for call in pc.music_calls)
        pc.g.restart()
        assert pc.g.musphase == 0 and pc.g.cpi == 0
        pc.g.mode, pc.g.started, pc.g.tm = "play", True, 600
        pc.run(1)
        assert pc.g.tm > 600, "timer still has the old nine-minute ceiling"
        pc.g.mode, pc.g.jzp = "done", True
        pc.g.menu()
        expected = CARTRIDGES[i + 1] + ".p8" if i < 7 else "parkour_menu.p8"
        assert pc.loaded_cart == expected, (name, pc.loaded_cart)
        assert pc.g.dget(i) == 0  # playback/score progression never writes records
        print("PASS", name, box_count, "boxes; isolated data, score, continuation")

    assert len(soundtrack_hashes) == 8, "levels share the same soundtrack"
    menu = Pico(root / "parkour_menu.p8")
    menu.g._draw()
    for i, name in enumerate(CARTRIDGES):
        menu.g.sel = i + 1
        menu.g.launch()
        assert menu.loaded_cart == name + ".p8"
    if not draft:
        assert (root / "parkour.p8").read_bytes() == (root / "parkour_menu.p8").read_bytes()
        assert (root / "parkour.p8.png").read_bytes() == (root / "parkour_menu.p8.png").read_bytes()
    print("PASS menu: eight local destinations; compatibility entry point")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--draft", action="store_true")
    check(parser.parse_args().draft)
