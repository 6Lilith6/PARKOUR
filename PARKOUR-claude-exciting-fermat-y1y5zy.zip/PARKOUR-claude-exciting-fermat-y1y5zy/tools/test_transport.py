"""Integration checks for authored transport, using the shipped cartridge."""
import unittest
from pathlib import Path
from sim import Pico
from cartpaths import cart_path

ROOT = Path(__file__).resolve().parents[1]


class TransportTests(unittest.TestCase):
    def setup_level(self, level, kind):
        self.pc = Pico(cart_path(level))
        self.pc.g.mode = "play"
        self.body = next(b for b in self.pc.g.movers.values() if b.k == kind)
        b = self.body
        self.pc.teleport((b[1] + b[4]) / 2, b[5], (b[3] + b[6]) / 2, .75)
        self.pc.step([])
        self.pc.g.started = True

    def test_service_train_carries_both_cars_without_drift(self):
        self.setup_level(3, 12)
        start = self.pc.g.pz
        cars = list(self.pc.g.movers.values())
        spacing = cars[1][3] - cars[0][3]
        self.pc.run(600)
        self.assertAlmostEqual(self.pc.g.pz - start, 12, places=3)
        self.assertEqual(self.pc.g.st, "ground")
        self.assertAlmostEqual(cars[1][3] - cars[0][3], spacing, places=4)
        self.pc.run(900)
        self.assertAlmostEqual(self.pc.g.pz, start, places=3)

    def test_jump_detaches_from_train(self):
        self.setup_level(3, 12)
        self.pc.run(240)
        self.pc.step(["z"])
        start = self.pc.g.pz
        self.assertEqual(self.pc.g.st, "air")
        self.assertIsNone(self.pc.g.gnd)
        self.pc.run(12)
        self.assertAlmostEqual(self.pc.g.pz, start, places=4)

    def test_construction_hoist_rises_and_returns_with_rider(self):
        self.setup_level(1, 13)
        start = self.pc.g.py
        self.pc.run(600)
        self.assertAlmostEqual(self.pc.g.py, start + 4, places=3)
        self.assertEqual(self.pc.g.st, "ground")
        self.pc.run(900)
        self.assertAlmostEqual(self.pc.g.py, start, places=3)

    def test_conveyor_moves_runner_not_structure(self):
        self.setup_level(2, 14)
        start, mesh = self.pc.g.px, self.body[1]
        self.pc.run(60)
        self.assertAlmostEqual(self.pc.g.px - start, 1.2, places=2)
        self.assertEqual(self.body[1], mesh)

    def test_downtown_bus_roof_carries_runner(self):
        self.setup_level(4, 15)
        start = self.pc.g.pz
        self.pc.run(600)
        self.assertAlmostEqual(self.pc.g.pz - start, 8, places=3)
        self.assertEqual(self.pc.g.st, "ground")

    def test_restart_rewinds_transport_and_title_freezes_it(self):
        self.setup_level(3, 12)
        initial = self.body[3]
        self.pc.run(600)
        self.pc.g.restart()
        self.assertAlmostEqual(self.body[3], initial, places=3)
        self.pc.g.mode = "title"
        self.pc.run(300)
        self.assertAlmostEqual(self.body[3], initial, places=3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
