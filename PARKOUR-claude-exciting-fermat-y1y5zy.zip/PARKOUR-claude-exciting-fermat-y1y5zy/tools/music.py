"""Eight original four-movement scores, using all 64 sound slots per cart.

Slots 0..11 are gameplay effects. Each movement contains eight different
melodic phrases, four bass phrases and one percussion phrase. Music uses
channels 0..2, leaving channel 3 for footsteps, grabs and landing feedback.
"""

# root, modal scale, four chord degrees, melodic motif, lead, bass, speed
# These are separate arrangements, not transpositions of a single loop.
SCORES = [
    (24, (0, 2, 3, 5, 7, 9, 10), (0, 5, 3, 4), (0, 2, 4, 6, 4, 2, 1, 3), 0, 1, 20),
    (21, (0, 2, 3, 5, 7, 8, 10), (0, 2, 5, 4), (0, 4, 1, 5, 2, 6, 3, 4), 2, 1, 21),
    (19, (0, 2, 3, 5, 7, 8, 10), (0, 0, 5, 3), (0, 0, 4, 2, 0, 5, 4, 1), 3, 2, 16),
    (22, (0, 1, 3, 5, 7, 8, 10), (0, 3, 1, 4), (0, 1, 4, 3, 1, 0, 6, 4), 1, 2, 19),
    (26, (0, 2, 4, 5, 7, 9, 11), (0, 5, 1, 4), (4, 2, 0, 1, 4, 6, 5, 2), 0, 1, 18),
    (24, (0, 2, 3, 5, 7, 8, 10), (0, 5, 2, 6), (0, 4, 6, 4, 2, 5, 3, 1), 5, 2, 15),
    (26, (0, 2, 4, 7, 9), (0, 3, 1, 2), (0, 1, 3, 2, 4, 3, 1, 0), 0, 0, 26),
    (19, (0, 2, 3, 5, 6, 8, 10), (0, 4, 2, 5), (0, 3, 1, 5, 4, 2, 6, 3), 5, 1, 22),
]


def score(level):
    """Return sound slot definitions and 32 PICO-8 music patterns."""
    root, scale, progression, motif, lead, bass, tempo = SCORES[level]
    sounds, patterns = {}, []

    def pitch(degree, octave=0):
        return min(63, max(0, root + scale[degree % len(scale)]
                           + 12 * (degree // len(scale) + octave)))

    for act in range(4):
        speed = max(12, tempo - (0, 1, 0, 2)[act])
        for chord, degree in enumerate(progression):
            notes = []
            for tick in range(32):
                pulse = tick % (8 if act == 0 else 4) == 0
                passing = act == 3 and tick in (14, 30)
                tone = pitch(degree + (4 if tick % 16 == 8 else 0), -1)
                notes.append((tone, bass, 3 if pulse or passing else 0, 5))
            sounds[12 + act * 4 + chord] = (speed, notes)

        drums = []
        for tick in range(32):
            kick = tick % 8 == 0 or act == 3 and tick == 27
            snare = tick % 16 == 8
            hat = tick % (4 if act < 2 else 2) == 2
            if kick:
                drums.append((18, 0, 3 if act > 0 else 2, 3))
            elif snare:
                drums.append((34, 6, 2, 5))
            elif hat:
                drums.append((52, 6, 1, 5))
            else:
                drums.append((0, 0, 0, 0))
        sounds[60 + act] = (speed, drums)

        for phrase in range(8):
            degree = progression[phrase % 4]
            melody = []
            for tick in range(32):
                # Long opening phrases yield to syncopation, an airy middle
                # section, then a denser final variation of the same motif.
                rhythm = ((0, 8, 12, 20, 24), (0, 6, 8, 14, 18, 24, 28),
                          (0, 10, 16, 22, 28), (0, 4, 6, 12, 16, 20, 26, 28))[act]
                index = (tick // 4 + phrase + act * 2) % len(motif)
                note = degree + motif[index]
                if phrase >= 4:
                    note += 2 if tick < 16 else -1
                note = pitch(note, 1 if act == 2 else 0)
                melody.append((note, lead, 2 if tick in rhythm else 0, 5))
            sid = 28 + act * 8 + phrase
            sounds[sid] = (speed, melody)
            # Each movement is a full eight-phrase cycle. A major section
            # checkpoint selects the next movement without stealing input.
            flags = 1 if phrase == 0 else 2 if phrase == 7 else 0
            patterns.append((flags, [sid, 12 + act * 4 + phrase % 4,
                                     60 + act, 0x40]))
    return sounds, patterns
