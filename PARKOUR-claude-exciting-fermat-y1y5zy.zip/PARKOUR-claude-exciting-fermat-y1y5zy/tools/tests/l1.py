"""Old City's second half: every test replays movement buttons, no state injection."""
N, E, S, W = .75, 0, .25, .5
SCENARIOS = {
    "hospital_bridge": ((56, 21, 210.5, E), [(345, "up")], lambda s, tr: s["x"] > 86 and s["y"] == 21 and "vault" in tr["states"]),
    "courtyard_descent": ((91, 21, 214, E), [(230, "up+rl")], lambda s, tr: s["x"] > 103 and s["y"] == 8),
    "attic_ladder_slide": ((109.75, 8, 232, N), [(370, "up+ax")], lambda s, tr: s["z"] > 250 and s["y"] == 12 and "slide" in tr["states"]),
    "attic_west_window": ((110, 12, 252, W), [(350, "up")], lambda s, tr: s["x"] < 91 and s["y"] == 12),
    "clock_drainpipe": ((82, 12, 261.75, W), [(300, "up")], lambda s, tr: s["y"] == 22 and "climb" in tr["states"]),
    "market_roof_drop": ((48, 22, 272, N), [(300, "up+ej+rl+ax")], lambda s, tr: s["z"] > 291 and s["y"] == 19 and "slide" in tr["states"]),
    "warehouse_gap": ((80, 18, 293, E), [(205, "up+ej")], lambda s, tr: s["x"] > 94 and s["y"] == 17 and "air" in tr["states"] and "vault" not in tr["states"]),
    "school_ascent": ((98.75, 17, 302, N), [(340, "up")], lambda s, tr: s["z"] > 322 and s["y"] == 21),
    "bell_tower_finish": ((64, 21, 329.75, W), [(450, "up")], lambda s, tr: tr["mode"] == "done"),
}
