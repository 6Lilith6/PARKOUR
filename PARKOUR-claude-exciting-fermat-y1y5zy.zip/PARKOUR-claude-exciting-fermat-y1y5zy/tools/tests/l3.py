"""Level 3 (factory) route checks."""
N, E, S, W = .75, 0, .25, .5
SCENARIOS = {
    "vault_machine_guard": ((6, 2, -6, E), [(130, "up")], lambda s, tr: s["x"] > 14 and "vault" in " ".join(tr["pops"])),
    "slide_pipe": ((14.5, 2, -6, E), [(150, "up+ax")], lambda s, tr: s["x"] > 24),
    "catwalk_ladder": ((1.5, 2, 17.25, E), [(140, "up")], lambda s, tr: tr.get("gy", 0) >= 6),
    "catwalk_crates": ((15, 2, 8, N), [(30, 'up+z'), (10, 'up')] * 5, lambda s, tr: tr.get("gy", 0) >= 6),
    "catwalk_to_containers": ((5, 6, 17.25, E), [(1, "flow=.6"), (700, "up+ej")], lambda s, tr: tr.get("gx", 0) > 90 and tr.get("gy", 0) >= 7 and not any("vault" in p for p in tr["pops"])),
    "singles_to_double": ((52, 2, 12.25, E), [(200, "up+az")], lambda s, tr: tr.get("gy", 0) >= 4.5),
    "tank_wallrun": ((84, 7, 18.1, E), [(1, "flow=.8"), (1, "spd=8"), (80, "up"), (1, "up+z"), (150, "up+z"), (90, "up")], lambda s, tr: "wallrun" in tr["pops"] and tr.get("gx", 0) >= 106 and tr.get("gy", 0) >= 7),
    "rack_ladder": ((102, 2, 17, E), [(250, "up")], lambda s, tr: tr.get("gy", 0) >= 7),
    "rack_run": ((109, 7, 17, E), [(1, "flow=.8"), (420, "up+ax")], lambda s, tr: tr.get("gx", 0) > 145),
    "plank_bridge": ((147, 2, 6.25, E), [(400, "up+bal")], lambda s, tr: tr.get("gx", 0) > 165),
    "pump_service_pier": ((143, 7, 17, E), [(230, "up+ej")], lambda s, tr: tr.get("gx", 0) > 160 and tr.get("gy", 0) >= 7 and not any("vault" in p for p in tr["pops"])),
    "long_jump": ((112, 7, 17, E), [(1, "flow=1"), (1, "spd=8.5"), (430, "up+ax+ej")], lambda s, tr: tr.get("gx", 0) > 157 and "hard landing" not in tr["pops"]),
    "conveyor_ladder": ((166.75, 2, 10, N), [(200, "up")], lambda s, tr: tr.get("gy", 0) >= 7),
    "silo_checkpoint": ((176, 7, 16.5, E), [(30, "up+z"), (10, "up")] * 8, lambda s, tr: tr["cpi"] >= 4 and tr["mode"] != "done"),
}

SCENARIOS.update({
    "pump_bridge_chain": ((189, 10, 24, N), [(345, "up+ax")], lambda s, tr: s["z"] > 52 and s["y"] == 10 and "slide" in tr["states"] and "vault" in tr["states"]),
    "pump_loading_drop": ((189, 10, 59, E), [(90, "up+rl")], lambda s, tr: s["x"] > 193 and s["y"] == 6),
    "packing_hall_chain": ((194, 6, 80, N), [(300, "up+ax")], lambda s, tr: s["z"] > 102 and s["y"] == 6 and "slide" in tr["states"] and "vault" in tr["states"]),
    "receiving_dock_jump": ((188, 6, 105, W), [(390, "up+ej")], lambda s, tr: s["x"] < 153 and s["y"] == 6 and "air" in tr["states"]),
    "boiler_ladder": ((140.75, 6, 110, N), [(310, "up")], lambda s, tr: s["y"] == 12 and "climb" in tr["states"]),
    "treatment_pipe_chain": ((150, 12, 136.5, E), [(450, "up+ax")], lambda s, tr: s["x"] > 184 and "slide" in tr["states"] and "vault" in tr["states"]),
    "outbound_container_jump": ((220, 10, 135, E), [(220, "up+ej")], lambda s, tr: s["x"] > 237 and s["y"] == 7 and "air" in tr["states"] and "vault" not in tr["states"]),
    "loading_roof_ascent": ((238.75, 7, 138.7, N), [(295, "up")], lambda s, tr: s["y"] == 11 and s["z"] > 153),
    "upper_return_bridge": ((240, 11, 158, W), [(310, "up")], lambda s, tr: s["x"] < 225 and s["y"] == 15),
    "control_tower_finish": ((200, 15, 158.75, W), [(400, "up")], lambda s, tr: tr["mode"] == "done"),
})
