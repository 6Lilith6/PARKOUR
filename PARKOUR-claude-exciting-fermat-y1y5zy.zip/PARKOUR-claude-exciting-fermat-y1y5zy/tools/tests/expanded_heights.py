"""Structural seam and itinerary audit for the three expanded height levels.

The design spines below measure authored journeys, not completion times and not
an automatic solver. Playable movement is separately replayed in l6/l7/l8.py.
Every seam probe must have a real supporting face and standing body clearance.
"""
from math import dist

from levels import l6_neon, l7_cliffs, l8_mega
from test_architecture import unsupported


ITINERARIES = {
    "neon": [
        (6, 24, -3), (6, 22, 50), (10, 20, 88), (6, 19, 148),
        (5, 16, 190), (6, 22, 208), (66, 21, 216), (66, 18, 286),
        (21, 18, 286), (21, 26, 279), (15, 30, 283), (-36, 28, 283),
        (-36, 28, 224), (-36, 36, 216),
    ],
    "mountain": [
        (2, 6, -5), (2, 6, 28), (6, 18, 38), (1, 18, 56),
        (1, 20, 88), (-2, 28, 120), (-2, 34, 134), (7, 34, 148),
        (55, 30, 150), (55, 34, 196), (44, 38, 200), (32, 42, 207),
        (-37, 42, 209), (-43, 46, 271), (19, 46, 272),
        (19, 50, 266), (26, 54, 266), (26, 58, 276),
    ],
    "megastructure": [
        (3, 2, -4), (5, 10, 51), (26, 10, 51), (26, 18, -5),
        (8, 18, -5), (8, 26, 51), (20, 26, 51), (20, 34, -5),
        (16, 42, 3), (14, 42, 45), (59, 42, 45), (59, 50, -16),
        (76, 50, -16), (76, 58, 46), (55, 58, 46), (55, 66, 105),
        (-9, 60, 103), (-9, 60, 50), (-43, 73, 50),
        (-43, 78, 116), (17, 78, 118), (34, 90, 118), (34, 90, 125),
    ],
}

SEAMS = {
    "neon": [(11, 22, 216), (13, 22, 216), (46, 21, 216),
             (66, 18, 238), (66, 18, 283), (25, 18, 286),
             (22, 18, 286), (21, 26, 279), (16, 30, 283),
             (-35, 28, 283), (-36, 28, 230), (-35, 36, 216)],
    "mountain": [(9, 34, 148), (12, 30, 148), (24, 30, 150),
                 (55, 30, 160), (55, 34, 200), (44, 38, 200),
                 (32, 42, 207), (17, 42, 209), (-23, 42, 209),
                 (-43, 42, 233), (-43, 46, 240), (-31, 46, 272),
                 (16, 46, 272), (20, 50, 267), (25, 54, 266),
                 (26, 58, 276)],
    "megastructure": [(20, 42, 45), (59, 42, 30), (59, 50, -16),
                      (76, 50, 0), (76, 58, 46), (55, 58, 70),
                      (55, 66, 105), (6, 66, 103), (-8, 60, 103),
                      (-9, 60, 60), (-25, 70, 49), (-43, 73, 70),
                      (-35, 78, 116), (-10, 78, 118), (34, 90, 116)],
}


def clear_standing_seam(boxes, p):
    x, y, z = p
    solids = [b for b in boxes if b[6] not in (11, 12, 13)]
    floor = any(abs(b[4] - y) < .01 and b[0] <= x <= b[3]
                and b[2] <= z <= b[5] for b in solids)
    blockers = [b for b in solids if b[0] < x + .28 and b[3] > x - .28
                and b[1] < y + 1.78 and b[4] > y + .02
                and b[2] < z + .28 and b[5] > z - .28]
    assert floor and not blockers, (p, floor, blockers)


def run():
    for name, module, summit in (("neon", l6_neon, 36),
                                ("mountain", l7_cliffs, 58),
                                ("megastructure", l8_mega, 90)):
        boxes = module.build().boxes
        assert not unsupported(boxes), name
        assert all(0 < b[k + 3] - b[k] <= 63.75
                   for b in boxes for k in range(3)), name
        checkpoints = sorted(b[7] for b in boxes if b[6] == 11)
        assert checkpoints == list(range(len(checkpoints))) and len(checkpoints) <= 16
        goals = [b for b in boxes if b[6] == 12]
        assert len(goals) == 1 and goals[0][1] == summit
        for p in SEAMS[name]:
            clear_standing_seam(boxes, p)
        spine = ITINERARIES[name]
        length = sum(dist(a, b) for a, b in zip(spine, spine[1:]))
        print(f"{name}: {len(SEAMS[name])} clear route seams; "
              f"{length:.0f} m authored spine; summit {summit} m; "
              f"{len(checkpoints)} checkpoints")


if __name__ == "__main__":
    run()
