"""Authored route design facts for the four expanded inhabited places.

The polyline is a design itinerary, NOT a computed shortest path or proof of
full traversal. Ordinary-input segment replays live in l1/l3/l4/l5.py. This
audit catches missing endings, checkpoint regressions, unsupported architecture,
resource overflow and accidental replacement by another straight corridor.
"""
import importlib
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from levels import ORDER
from build import level_blob
from test_architecture import unsupported

# (section name, checkpoint, chosen waypoint (x,y,z), ordinary route mechanics)
SECTIONS = {
    0: [
        ("hospital lookout", 7, (52,21.25,210), ("vault",)),
        ("rear fire escape and courtyard", 8, (109,8,214), ("drop", "roll", "slide")),
        ("timber attic", 9, (110,12,240), ("climb", "slide", "vault")),
        ("clock house and market roofs", 10, (74,22,265), ("climb", "cat leap", "balance")),
        ("market alleys", 11, (48,19,283), ("jump", "roll", "slide")),
        ("canal warehouses", 12, (99,17,294), ("vault", "slide", "precision jump")),
        ("school terrace and bell tower", 13, (78,21,327), ("climb", "vault", "slide")),
    ],
    2: [
        ("silo lookout", 4, (192,10,17), ("climb",)),
        ("pump yard and loading mezzanine", 5, (194,6,70), ("slide", "vault", "roll")),
        ("packing hall", 6, (186,6,106), ("vault", "slide", "climb")),
        ("receiving dock and boiler deck", 7, (145,12,121), ("precision jump", "climb", "cat leap")),
        ("treatment basin and outbound belt", 8, (218,10,135), ("balance", "vault", "slide")),
        ("cargo and loading roof", 9, (242,11,147), ("long jump", "roll", "climb")),
        ("high return and control tower", 10, (201,15,160), ("climb", "slide", "vault")),
    ],
    3: [
        ("old station transfer", 6, (11,14,189), ("climb",)),
        ("east concourse", 7, (59,14,197), ("vault", "slide")),
        ("second station and carriage roofs", 8, (72,7,220), ("drop", "cat leap", "precision jump")),
        ("technical wall and service gantry", 9, (72,9.25,249), ("wallrun", "wall jump", "climb")),
        ("west fan gallery and ventilation cut", 10, (31,9.25,274), ("vault", "slide", "precision jump")),
        ("pump hall upper balcony", 11, (41,14.25,310), ("climb", "cat leap")),
        ("high service crossing and rail descent", 12, (105,14.25,308), ("vault", "slide", "drop")),
    ],
    4: [
        ("office crown", 4, (10,23,128), ("climb",)),
        ("annex and occupied office", 5, (24,19,147), ("long jump", "roll", "vault", "slide")),
        ("residents garden and lower roof", 6, (-31,16,178), ("jump", "vault", "roll")),
        ("fire escape, street traffic and shops", 7, (-12,10,234), ("drop", "cat leap", "climb", "slide")),
        ("atrium gardens and high return", 8, (32,18,254), ("climb", "balance", "slide", "vault")),
        ("parking deck and transport plaza", 9, (61,12,282), ("long jump", "roll", "drop", "vault")),
    ],
}

# More detailed turns ensure measuring the authored journey rather than diagonal
# checkpoint-to-checkpoint chords through intervening walls.
ITINERARIES = {
    0: [(52,21.25,210),(89,21,210),(109,8,214),(110,8,233),
        (110,12,252),(88,12,252),(82,12,262),(74,22,265),(48,22,265),
        (48,19,294),(82,18,294),(99,17,294),(99,21,328),(50,28,330)],
    2: [(192,10,17),(189,10,59),(194,6,59),(194,6,106),(140,6,105),
        (141,12,122),(145,12,136),(189,12,136),(222,10,135),
        (239,7,135),(239,11,158),(221,15,158),(180,20,159)],
    3: [(11,14,189),(11,14,197),(71,14,197),(71,7,218),(81,9.25,218),
        (81,9.25,245),(72,9.25,249),(31,9.25,250),(31,9.25,300),
        (30,14.25,310),(104,14.25,308),(104,4,272)],
    4: [(10,23,128),(24,23,128),(24,19,174),(-12,19,174),(-31,16,178),
        (-32,2,216),(-21,2,235),(-12,10,235),(-14,14,254),
        (12,14,256),(49,18,256),(49,12,282),(88,2.5,282),(101,3,294)],
}


def run():
    for index, sections in SECTIONS.items():
        mod = importlib.import_module("levels." + ORDER[index])
        boxes = mod.build().boxes
        level_blob(mod)  # exact PICO-8 coordinate/dimension encoding
        assert len(boxes) <= 650, (mod.NAME, "geometry budget")
        assert not unsupported(boxes), (mod.NAME, "unattached architecture")
        assert len([b for b in boxes if b[6] == 12]) == 1, (mod.NAME, "one final destination")
        checkpoints = {b[7] for b in boxes if b[6] == 11}
        assert checkpoints == set(range(max(checkpoints)+1)), (mod.NAME, checkpoints)
        assert max(checkpoints) <= 15
        for name, checkpoint, (x,y,z), mechanics in sections:
            assert checkpoint in checkpoints, (mod.NAME, name)
            assert len(mechanics) >= 1
            assert any(b[6] not in (11,12,13) and b[0] <= x <= b[3]
                       and b[2] <= z <= b[5] and abs(b[4]-y) < .01 for b in boxes), (mod.NAME, name, "footing")
        points = ITINERARIES[index]
        vectors = [(b[0]-a[0], b[2]-a[2]) for a,b in zip(points, points[1:])]
        turns = sum(abs(a[0]*b[1]-a[1]*b[0]) > 1 for a,b in zip(vectors,vectors[1:]))
        length = sum(math.dist(a,b) for a,b in zip(points,points[1:]))
        assert length > 250, (mod.NAME, length)
        assert turns >= 6, (mod.NAME, turns)
        assert max(p[1] for p in points)-min(p[1] for p in points) >= 9
        print(f"{mod.NAME}: {len(sections)-1} new sections, {length:.0f}m extension itinerary, {turns} turns, {len(boxes)} boxes")


if __name__ == "__main__":
    run()
