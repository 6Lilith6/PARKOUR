"""Level 4 (underground) route checks."""
N, E, S, W = .75, 0, .25, .5
SCENARIOS = {
    "platform_run": ((4, 3.25, 3, N), [(420, "up")], lambda s, tr: s["z"] > 38),
    "train_roof": ((6, 3.25, 10, E), [(24, "up"), (1, "up+z"), (100, "up+z")], lambda s, tr: tr.get("gy", 0) >= 5.5 and "vault" not in tr["states"]),
    "car_gap_jump": ((11, 5.5, 11, N), [(1, "spd=6"), (18, "up"), (1, "up+z"), (50, "up")], lambda s, tr: s["z"] > 16 and s["y"] == 5.5 and "air" in tr["states"] and "vault" not in tr["states"]),
    "car_gap_requires_jump": ((11, 5.5, 11, N), [(1, "spd=6"), (80, "up")], lambda s, tr: s["y"] < 5.5 and "vault" not in tr["states"]),
    "roof_to_service_gantry": ((11, 5.5, 34, N), [(1, "spd=6"), (32, "up"), (1, "up+z"), (49, "up")], lambda s, tr: s["z"] > 41 and s["y"] == 5.5 and "vault" not in tr["states"]),
    "service_train_ride": ((19, 5.5, 8, N), [(1, "up"), (600, "")], lambda s, tr: s["z"] > 19.5 and s["y"] == 5.5 and s["st"] == "ground"),
    "board_moving_train": ((15, 3.25, 14, E), [(1, "up"), (240, ""), (24, "up"), (1, "up+z"), (65, "up+z")], lambda s, tr: s["y"] == 5.5 and s["z"] > 14.8 and "hang" in tr["states"] and "vault" not in tr["states"]),
    "platform_to_walkway": ((9.6, 3.25, 39, N), [(200, "up")], lambda s, tr: tr.get("gy", 0) >= 4.25 and s["z"] > 45 and "vault" not in tr["states"]),
    "island_service_door": ((15.5, 3.25, 46, N), [(100, "up")], lambda s, tr: s["z"] > 49 and tr.get("gy", 0) >= 4.25 and "vault" not in tr["states"]),
    "walkway_run": ((9.6, 4.25, 46, N), [(1, "flow=.5"), (500, "up+ej+ax")], lambda s, tr: s["z"] > 88 and "slide" in tr["states"]),
    "trackbed_run": ((11.5, 2, 42, N), [(600, "up+ax")], lambda s, tr: s["z"] > 88),
    "tunnel_zigzag": ((9.6, 4.25, 60, N), [(1, "flow=.8"), (1, "spd=8"), (10, "up"), (31, "up+z+right"), (30, "up+z"), (2, "up"), (1, "up+z"), (40, "up+z"), (2, "up"), (1, "up+z"), (50, "up+z"), (60, "up")], lambda s, tr: tr["pops"].count("wallrun") >= 2 and s["z"] > 75),
    "pump_housing_climb": ((9.6, 4.25, 98, N), [(1, "up+z"), (90, "up+z"), (2, "up"), (1, "up+z"), (80, "up+z"), (2, "up"), (1, "up+z"), (80, "up+z"), (2, "up"), (1, "up+z"), (80, "up+z")], lambda s, tr: tr.get("gy", 0) >= 9 and "vault" not in tr["states"]),
    "landing_ladder": ((0.75, 2, 105, N), [(250, "up")], lambda s, tr: tr.get("gy", 0) >= 9),
    "upper_tunnel": ((11.75, 9, 112, N), [(1, "flow=.5"), (700, "up+az+ax+bal")], lambda s, tr: s["z"] > 160),
    "transfer_checkpoint": ((11, 9, 168, N), [(400, "up+az")], lambda s, tr: tr["cpi"] >= 6 and tr["mode"] != "done"),
}

SCENARIOS.update({
    "east_transfer_chain": ((18, 14, 197, E), [(495, "up+ax")], lambda s, tr: s["x"] > 61 and "vault" in tr["states"] and "slide" in tr["states"]),
    "transfer_stairs_down": ((71, 14, 199, N), [(300, "up+rl")], lambda s, tr: s["z"] > 218 and s["y"] == 7),
    "second_station_train": ((76, 7, 215, E), [(24, "up"), (1, "up+z"), (85, "up+z")], lambda s, tr: tr.get("gy", 0) >= 9.25 and "vault" not in tr["states"]),
    "second_car_gap": ((80.75, 9.25, 220, N), [(150, "up+ej")], lambda s, tr: s["z"] > 229 and s["y"] == 9.25 and "air" in tr["states"] and "vault" not in tr["states"]),
    "second_roof_gantry": ((80.75, 9.25, 235, N), [(150, "up+ej")], lambda s, tr: s["z"] > 244 and s["y"] == 9.25 and "vault" not in tr["states"]),
    "technical_wall_jump": ((78.75, 9.25, 229, N), [(60, "up"), (1, "up+z"), (67, "up+z"), (2, "up"), (1, "up+z"), (80, "up+z")], lambda s, tr: s["z"] > 243 and s["y"] == 9.25 and "wallrun" in tr["states"] and "wall jump" in tr["pops"]),
    "west_fan_gallery": ((65, 9.25, 250, W), [(390, "up+ax")], lambda s, tr: s["x"] < 34 and "vault" in tr["states"] and "slide" in tr["states"]),
    "ventilation_precision": ((31, 9.25, 260, N), [(260, "up+ej+ax")], lambda s, tr: s["z"] > 280 and s["y"] == 9.25 and "air" in tr["states"] and "vault" not in tr["states"]),
    "pump_hall_balcony": ((29.75, 9.25, 301, N), [(310, "up")], lambda s, tr: s["y"] == 14.25 and "climb" in tr["states"]),
    "high_service_crossing": ((58, 14.25, 308, E), [(450, "up+ax")], lambda s, tr: s["x"] > 99 and s["y"] == 14.25 and "slide" in tr["states"]),
    "rail_descent_finish": ((104, 14.25, 307, S), [(400, "up+rl")], lambda s, tr: tr["mode"] == "done"),
})
